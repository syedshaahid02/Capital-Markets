import json
from typing import List, Dict, Any
from .llm_integration import LLMIntegration, Config
from datetime import datetime

class SimpleScenarioAgent:
    def __init__(self):
        self.llm = LLMIntegration()
        self.generated_scenarios = []
    
    def generate_multiple_scenarios(self, scenario_types: List[str], portfolio_type: str, count: int = 3) -> List[Dict[str, Any]]:
        """Generate multiple risk scenarios with simplified market context"""
        
        # Use simple, serializable market context
        market_context = {
            "current_conditions": "Normal market conditions with moderate volatility",
            "economic_outlook": "Stable growth with controlled inflation",
            "risk_sentiment": "Neutral",
            "analysis_date": datetime.now().strftime('%Y-%m-%d')
        }
        
        scenarios = []
        
        for scenario_type in scenario_types:
            for i in range(count):
                try:
                    scenario = self.llm.generate_scenario(
                        scenario_type, 
                        market_context, 
                        portfolio_type
                    )
                    scenario['id'] = f"{scenario_type.lower().replace(' ', '_')}_{i+1}"
                    scenario['portfolio_type'] = portfolio_type
                    scenario['severity'] = self._assess_scenario_severity(scenario)
                    scenarios.append(scenario)
                    
                    # Add to history
                    self.generated_scenarios.append(scenario)
                except Exception as e:
                    print(f"Error generating scenario {scenario_type}: {e}")
                    # Add fallback scenario
                    fallback_scenario = self._get_fallback_scenario(scenario_type, portfolio_type)
                    scenarios.append(fallback_scenario)
                    self.generated_scenarios.append(fallback_scenario)
        
        return scenarios
    
    def _assess_scenario_severity(self, scenario: Dict[str, Any]) -> str:
        """Assess scenario severity based on content"""
        risk_metrics = scenario.get('risk_metrics', {})
        
        var_estimate = str(risk_metrics.get('var_95', '15-25%')).lower()
        
        if any(term in var_estimate for term in ['30', '35', '40', '45', '50']):
            return "High"
        elif any(term in var_estimate for term in ['20', '25']):
            return "Medium"
        else:
            return "Low"
    
    def _get_fallback_scenario(self, scenario_type: str, portfolio_type: str) -> Dict[str, Any]:
        """Create fallback scenario"""
        return {
            "scenario_type": scenario_type,
            "portfolio_type": portfolio_type,
            "scenario_overview": f"Analysis of {scenario_type} risk for {portfolio_type} portfolio.",
            "market_context": "Standard market stress conditions",
            "timeline": "2-4 week event progression",
            "portfolio_impact": f"Moderate to high impact on {portfolio_type} portfolio.",
            "risk_metrics": {"var_95": "20-30%", "expected_shortfall": "25-35%"},
            "mitigation_strategies": ["Increase cash", "Implement hedging", "Diversify assets"],
            "monitoring_indicators": ["VIX", "Credit spreads", "Liquidity"],
            "generated_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "model_used": Config.LANGCHAIN_MODEL,
            "severity": "Medium",
            "fallback_used": True
        }
    

    