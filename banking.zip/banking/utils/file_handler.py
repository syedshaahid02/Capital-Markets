import os

class FileHandler:
    def __init__(self):
        pass
    
    def save_uploaded_file(self, file_data, filename, customer_id):
        return True, f"uploads/{customer_id}/{filename}", None