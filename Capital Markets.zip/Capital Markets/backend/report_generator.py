from fpdf import FPDF
import json
from datetime import datetime
import os
from typing import Dict, List, Any  # Add this import

class PDFReportGenerator:
    def __init__(self):
        self.report_dir = "reports"
        os.makedirs(self.report_dir, exist_ok=True)
    
    def generate_scenario_report(self, scenario: Dict, filename: str = None) -> str:
        """Generate PDF report for a single scenario"""
        
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"risk_scenario_{scenario['scenario_type'].replace(' ', '_')}_{timestamp}.pdf"
        
        filepath = os.path.join(self.report_dir, filename)
        
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        
        # Title
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(0, 10, f"Risk Scenario Analysis: {scenario['scenario_type']}", ln=True, align='C')
        pdf.ln(10)
        
        # Metadata
        pdf.set_font("Arial", size=10)
        pdf.cell(0, 8, f"Generated: {scenario.get('generated_at', 'N/A')}", ln=True)
        pdf.cell(0, 8, f"Severity: {scenario.get('severity', 'N/A')}", ln=True)
        pdf.ln(10)
        
        # Scenario Overview
        self._add_section(pdf, "Scenario Overview", scenario.get('scenario_overview', 'N/A'))
        
        # Market Context
        self._add_section(pdf, "Market Context", scenario.get('market_context', 'N/A'))
        
        # Timeline
        self._add_section(pdf, "Event Timeline", scenario.get('timeline', 'N/A'))
        
        # Portfolio Impact
        self._add_section(pdf, "Portfolio Impact", scenario.get('portfolio_impact', 'N/A'))
        
        # Risk Metrics
        risk_metrics = scenario.get('risk_metrics', {})
        if isinstance(risk_metrics, dict):
            metrics_text = "\n".join([f"{k}: {v}" for k, v in risk_metrics.items()])
        else:
            metrics_text = str(risk_metrics)
        self._add_section(pdf, "Risk Metrics", metrics_text)
        
        # Mitigation Strategies
        mitigation = scenario.get('mitigation_strategies', [])
        if isinstance(mitigation, list):
            mitigation_text = "\n".join([f"• {item}" for item in mitigation])
        else:
            mitigation_text = str(mitigation)
        self._add_section(pdf, "Mitigation Strategies", mitigation_text)
        
        # Monitoring Indicators
        monitoring = scenario.get('monitoring_indicators', [])
        if isinstance(monitoring, list):
            monitoring_text = "\n".join([f"• {item}" for item in monitoring])
        else:
            monitoring_text = str(monitoring)
        self._add_section(pdf, "Key Monitoring Indicators", monitoring_text)
        
        pdf.output(filepath)
        return filepath
    
    def _add_section(self, pdf, title: str, content: str):
        """Add a section to the PDF"""
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(0, 10, title, ln=True)
        pdf.set_font("Arial", size=10)
        
        # Handle long text with proper wrapping
        if content:
            pdf.multi_cell(0, 8, content)
        else:
            pdf.multi_cell(0, 8, "No information available")
        pdf.ln(5)
    
    def generate_comprehensive_report(self, scenarios: List[Dict]) -> str:
        """Generate comprehensive report for multiple scenarios"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"comprehensive_risk_analysis_{timestamp}.pdf"
        filepath = os.path.join(self.report_dir, filename)
        
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        
        # Title
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(0, 10, "Comprehensive Risk Scenario Analysis", ln=True, align='C')
        pdf.ln(10)
        
        # Summary
        pdf.set_font("Arial", 'B', 12)
        pdf.cell(0, 10, f"Total Scenarios Analyzed: {len(scenarios)}", ln=True)
        
        severity_count = {}
        for scenario in scenarios:
            severity = scenario.get('severity', 'Unknown')
            severity_count[severity] = severity_count.get(severity, 0) + 1
        
        pdf.cell(0, 10, f"Severity Distribution: {severity_count}", ln=True)
        pdf.ln(10)
        
        # Individual Scenarios
        for i, scenario in enumerate(scenarios, 1):
            if i > 1:  # Add new page for each scenario after the first
                pdf.add_page()
            
            pdf.set_font("Arial", 'B', 14)
            pdf.cell(0, 10, f"Scenario {i}: {scenario['scenario_type']}", ln=True)
            pdf.ln(5)
            
            self._add_section(pdf, "Overview", scenario.get('scenario_overview', 'N/A'))
            self._add_section(pdf, "Severity", scenario.get('severity', 'N/A'))
            self._add_section(pdf, "Key Impact", scenario.get('portfolio_impact', 'N/A'))
            
            # Add risk metrics if available
            risk_metrics = scenario.get('risk_metrics', {})
            if risk_metrics:
                if isinstance(risk_metrics, dict):
                    metrics_text = "\n".join([f"{k}: {v}" for k, v in risk_metrics.items()])
                else:
                    metrics_text = str(risk_metrics)
                self._add_section(pdf, "Risk Metrics", metrics_text)
        
        pdf.output(filepath)
        return filepath
    

    