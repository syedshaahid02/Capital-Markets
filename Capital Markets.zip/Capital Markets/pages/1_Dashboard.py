import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime

def dashboard_page():
    st.title("Risk Management Dashboard")
    
    # Market Overview
    st.subheader("Market Overview")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="S&P 500",
            value="4,500.00",
            delta="+1.2%"
        )
    
    with col2:
        st.metric(
            label="VIX Index",
            value="15.2",
            delta="-0.8"
        )
    
    with col3:
        scenario_count = len(st.session_state.get('scenarios', []))
        st.metric(
            label="Generated Scenarios",
            value=scenario_count
        )
    
    with col4:
        high_risk = len([s for s in st.session_state.get('scenarios', []) if s.get('severity') == 'High'])
        st.metric(
            label="High Risk Scenarios",
            value=high_risk
        )
    
    # Recent Scenarios
    st.subheader("Recent Risk Scenarios")
    scenarios = st.session_state.get('scenarios', [])
    if scenarios:
        scenario_df = pd.DataFrame([
            {
                'Type': s['scenario_type'],
                'Severity': s.get('severity', 'Unknown'),
                'Generated': s.get('generated_at', 'N/A'),
                'Overview': s.get('scenario_overview', '')[:100] + '...'
            }
            for s in scenarios[-5:]  # Last 5 scenarios
        ])
        st.dataframe(scenario_df, use_container_width=True)
    else:
        st.info("No scenarios generated yet. Visit the Scenario Generator page to create scenarios.")
    
    # Risk Distribution Chart
    if scenarios:
        st.subheader("Risk Scenario Distribution")
        severity_counts = pd.DataFrame([
            {'Severity': s.get('severity', 'Unknown'), 'Count': 1}
            for s in scenarios
        ]).groupby('Severity').count().reset_index()
        
        if not severity_counts.empty:
            fig = px.pie(severity_counts, values='Count', names='Severity', 
                        title="Scenario Severity Distribution")
            st.plotly_chart(fig, use_container_width=True)
    
    # Quick Actions
    st.subheader("Quick Actions")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Generate New Scenario", use_container_width=True):
            st.switch_page("pages/3_Scenario_Generator.py")
    
    with col2:
        if st.button("View Market Data", use_container_width=True):
            st.switch_page("pages/2_Market_Data.py")
    
    with col3:
        if st.button("Generate Reports", use_container_width=True):
            st.switch_page("pages/6_Report_Manager.py")

# Initialize session state if not exists
if 'scenarios' not in st.session_state:
    st.session_state.scenarios = []
if 'market_data' not in st.session_state:
    st.session_state.market_data = None

dashboard_page()


