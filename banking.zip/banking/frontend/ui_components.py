import streamlit as st
from datetime import datetime
import pandas as pd
from typing import Dict, List, Optional

def setup_page_config():
    """Setup Streamlit page configuration"""
    st.set_page_config(
        page_title="Banking KYC Verification",
        page_icon="🏦",
        layout="wide",
        initial_sidebar_state="expanded"
    )

def show_header():
    """Display application header"""
    st.title("🏦 Banking KYC Document Verification")
    st.markdown("---")

def login_form():
    """Display login form"""
    st.subheader("Login to Your Account")
    
    with st.form("login_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
        
        if submit:
            return {"email": email, "password": password}
    return None

def registration_form():
    """Display registration form"""
    st.subheader("Create New Account")
    
    with st.form("registration_form"):
        full_name = st.text_input("Full Name")
        email = st.text_input("Email")
        phone = st.text_input("Phone Number")
        password = st.text_input("Password", type="password")
        confirm_password = st.text_input("Confirm Password", type="password")
        submit = st.form_submit_button("Register")
        
        if submit:
            if password != confirm_password:
                st.error("Passwords do not match!")
                return None
            return {
                "full_name": full_name,
                "email": email,
                "phone": phone,
                "password": password
            }
    return None

def show_dashboard(customer_name: str, kyc_status: Dict):
    """Display customer dashboard"""
    st.sidebar.title(f"Welcome, {customer_name}!")
    
    # Display KYC status
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Account Status", "Active" if kyc_status.get('is_verified') else "Pending KYC")
    
    with col2:
        documents_uploaded = kyc_status.get('uploaded_docs', 0)
        total_required = kyc_status.get('total_required', 3)
        st.metric("Documents Uploaded", f"{documents_uploaded}/{total_required}")
    
    with col3:
        status_color = "🟢" if kyc_status.get('is_complete') else "🟡"
        st.metric("KYC Status", f"{status_color} {'Complete' if kyc_status.get('is_complete') else 'In Progress'}")
    
    st.markdown("---")

def document_upload_form(required_docs: List[Dict]):
    """Display document upload form"""
    st.subheader("Upload KYC Documents")
    
    selected_doc_type = st.selectbox(
        "Select Document Type",
        options=[doc['document_type'] for doc in required_docs],
        format_func=lambda x: x.replace('_', ' ').title()
    )
    
    # Get selected document details
    selected_doc = next((doc for doc in required_docs if doc['document_type'] == selected_doc_type), None)
    
    if selected_doc:
        st.info(f"**Requirements:** {selected_doc['description']}")
        st.info(f"**Allowed formats:** {selected_doc['allowed_formats']}")
        st.info(f"**Max size:** {selected_doc['max_size_mb']} MB")
    
    uploaded_file = st.file_uploader(
        "Choose a file",
        type=['jpg', 'jpeg', 'png', 'pdf'],
        key=f"upload_{selected_doc_type}"
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        preview = st.checkbox("Preview Document", value=False)
    
    with col2:
        upload_button = st.button("Upload Document", type="primary")
    
    if uploaded_file and preview:
        if uploaded_file.type.startswith('image/'):
            st.image(uploaded_file, caption="Document Preview", use_column_width=True)
        else:
            st.info("PDF preview not available")
    
    return selected_doc_type, uploaded_file, upload_button

def show_document_status(documents: List[Dict]):
    """Display document upload status"""
    st.subheader("Document Status")
    
    if not documents:
        st.info("No documents uploaded yet.")
        return
    
    data = []
    for doc in documents:
        status_icon = "✅" if doc['status'] == 'verified' else "⏳" if doc['status'] == 'pending' else "❌"
        data.append({
            "Document Type": doc['document_type'].replace('_', ' ').title(),
            "Status": f"{status_icon} {doc['status'].title()}",
            "Uploaded": doc['uploaded_at'].strftime("%Y-%m-%d %H:%M") if doc['uploaded_at'] else "N/A",
            "Message": doc.get('verification_result', '')
        })
    
    df = pd.DataFrame(data)
    st.dataframe(df, use_container_width=True, hide_index=True)

def show_verification_result(result: Dict):
    """Display verification result"""
    if result['is_valid']:
        st.success("✅ " + result['message'])
        
        if result.get('extracted_data'):
            with st.expander("View Extracted Information"):
                extracted = result['extracted_data']
                for key, value in extracted.items():
                    if key != 'issues' and value:
                        st.write(f"**{key.replace('_', ' ').title()}:** {value}")
    else:
        st.error("❌ " + result['message'])
        
        if result.get('issues'):
            st.warning("**Issues found:**")
            for issue in result['issues']:
                st.write(f"• {issue}")

def show_audit_logs(logs: List[Dict]):
    """Display audit logs"""
    st.subheader("Activity Log")
    
    if not logs:
        st.info("No activity logs found.")
        return
    
    for log in logs:
        with st.container():
            cols = st.columns([1, 3, 2])
            with cols[0]:
                st.text(log['created_at'].strftime("%H:%M"))
            with cols[1]:
                st.text(log['action'].replace('_', ' ').title())
            with cols[2]:
                st.text(log.get('details', '')[:50] + "..." if len(log.get('details', '')) > 50 else log.get('details', ''))
        st.divider()

def show_verification_result(result: Dict):
    """Display verification result with AI insights"""
    if result['is_valid']:
        st.success("✅ " + result['message'])
        
        # Show AI confidence if available
        if result.get('extracted_data') and 'ai_result' in result['extracted_data']:
            ai_result = result['extracted_data']['ai_result']
            if 'confidence' in ai_result:
                cols = st.columns([3, 1])
                with cols[0]:
                    st.progress(ai_result['confidence'])
                with cols[1]:
                    st.metric("AI Confidence", f"{ai_result['confidence']:.2%}")
        
        if result.get('extracted_data'):
            with st.expander("🔍 View Detailed Analysis"):
                extracted = result['extracted_data']
                
                # Show OCR results
                if 'ocr_result' in extracted:
                    st.subheader("OCR Results")
                    ocr_data = extracted['ocr_result']
                    for key, value in ocr_data.items():
                        if key != 'issues' and value and key != 'extracted_text':
                            st.write(f"**{key.replace('_', ' ').title()}:** {value}")
                
                # Show AI results
                if 'ai_result' in extracted:
                    st.subheader("🤖 AI Analysis")
                    ai_data = extracted['ai_result']
                    if 'extracted_info' in ai_data:
                        st.write("**Extracted Information:**")
                        for key, value in ai_data['extracted_info'].items():
                            if value:
                                st.write(f"- {key.replace('_', ' ').title()}: {value}")
                    
                    if 'analysis' in ai_data:
                        st.write("**Analysis:**")
                        st.info(ai_data['analysis'])
    else:
        st.error("❌ " + result['message'])
        
        if result.get('issues'):
            st.warning("**Issues found:**")
            for issue in result['issues']:
                st.write(f"• {issue}")
        
        # Show partial extraction if available
        if result.get('extracted_data') and 'ai_result' in result['extracted_data']:
            ai_result = result['extracted_data']['ai_result']
            if 'extracted_info' in ai_result:
                with st.expander("View Partial Extraction"):
                    for key, value in ai_result['extracted_info'].items():
                        if value:
                            st.write(f"**{key.replace('_', ' ').title()}:** {value}")