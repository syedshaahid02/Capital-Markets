"""
Notification system for KYC status updates
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from decouple import config
from typing import Dict, List
import logging

logger = logging.getLogger(__name__)

class NotificationManager:
    """Manage customer notifications"""
    
    def __init__(self):
        self.smtp_server = config('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = config('SMTP_PORT', 587, cast=int)
        self.smtp_username = config('SMTP_USERNAME', '')
        self.smtp_password = config('SMTP_PASSWORD', '')
        self.from_email = config('FROM_EMAIL', 'kyc@bank.com')
        
    def send_kyc_status_update(self, customer_email: str, 
                              customer_name: str, 
                              status_data: Dict) -> bool:
        """Send KYC status update to customer"""
        try:
            subject = f"KYC Status Update - {status_data.get('status', 'Pending')}"
            
            # Create email content
            if status_data['status'] == 'document_rejected':
                template = self._create_rejection_email(customer_name, status_data)
            elif status_data['status'] == 'document_verified':
                template = self._create_verification_email(customer_name, status_data)
            elif status_data['status'] == 'document_missing':
                template = self._create_missing_docs_email(customer_name, status_data)
            elif status_data['status'] == 'kyc_completed':
                template = self._create_completion_email(customer_name, status_data)
            else:
                template = self._create_status_update_email(customer_name, status_data)
            
            # Send email
            return self._send_email(customer_email, subject, template)
            
        except Exception as e:
            logger.error(f"Failed to send notification: {e}")
            return False
    
    def _create_rejection_email(self, name: str, data: Dict) -> str:
        """Create email template for rejected documents"""
        return f"""
        <html>
        <body>
            <h2>Dear {name},</h2>
            
            <p>Your KYC document has been <strong>rejected</strong>.</p>
            
            <h3>Document Details:</h3>
            <ul>
                <li><strong>Document Type:</strong> {data.get('document_type', 'Unknown')}</li>
                <li><strong>Upload Date:</strong> {data.get('upload_date', 'N/A')}</li>
            </ul>
            
            <h3>Rejection Reasons:</h3>
            <ul>
        """
        + "\n".join([f"<li>{issue}</li>" for issue in data.get('issues', [])]) + \
        """
            </ul>
            
            <h3>Next Steps:</h3>
            <ol>
                <li>Please upload a clear, valid document</li>
                <li>Ensure the document is not expired</li>
                <li>Make sure all information is clearly visible</li>
                <li>Re-upload the corrected document</li>
            </ol>
            
            <p>For assistance, contact our support team.</p>
            
            <p>Best regards,<br>
            KYC Verification Team<br>
            Your Bank Name</p>
        </body>
        </html>
        """
    
    def _create_verification_email(self, name: str, data: Dict) -> str:
        """Create email template for verified documents"""
        return f"""
        <html>
        <body>
            <h2>Dear {name},</h2>
            
            <p>Your document has been <strong>successfully verified</strong> ✅</p>
            
            <h3>Document Details:</h3>
            <ul>
                <li><strong>Document Type:</strong> {data.get('document_type', 'Unknown')}</li>
                <li><strong>Verification Date:</strong> {data.get('verification_date', 'N/A')}</li>
                <li><strong>Status:</strong> Verified</li>
            </ul>
            
            <h3>Next Steps:</h3>
            <p>Please continue with the remaining KYC documents.</p>
            
            <p>Best regards,<br>
            KYC Verification Team<br>
            Your Bank Name</p>
        </body>
        </html>
        """
    
    def _create_missing_docs_email(self, name: str, data: Dict) -> str:
        """Create email for missing documents"""
        docs_list = "\n".join([f"<li>{doc}</li>" for doc in data.get('missing_docs', [])])
        
        return f"""
        <html>
        <body>
            <h2>Dear {name},</h2>
            
            <p>Your KYC process requires additional documents.</p>
            
            <h3>Missing Documents:</h3>
            <ul>
                {docs_list}
            </ul>
            
            <h3>Required Action:</h3>
            <p>Please upload the missing documents through your banking portal.</p>
            
            <p>Best regards,<br>
            KYC Verification Team<br>
            Your Bank Name</p>
        </body>
        </html>
        """
    
    def _create_completion_email(self, name: str, data: Dict) -> str:
        """Create email for KYC completion"""
        return f"""
        <html>
        <body>
            <h2>Congratulations {name}! 🎉</h2>
            
            <p>Your KYC verification has been <strong>successfully completed</strong>!</p>
            
            <h3>Account Details:</h3>
            <ul>
                <li><strong>KYC Status:</strong> Completed</li>
                <li><strong>Completion Date:</strong> {data.get('completion_date', 'N/A')}</li>
                <li><strong>Account Activation:</strong> Within 24 hours</li>
            </ul>
            
            <h3>Next Steps:</h3>
            <ol>
                <li>Your account will be activated within 24 hours</li>
                <li>You will receive your account details via SMS</li>
                <li>Access online banking immediately</li>
                <li>Debit card will be dispatched within 5-7 working days</li>
            </ol>
            
            <p>Welcome to our banking family! 🏦</p>
            
            <p>Best regards,<br>
            Customer Service Team<br>
            Your Bank Name</p>
        </body>
        </html>
        """
    
    def _send_email(self, to_email: str, subject: str, html_content: str) -> bool:
        """Send email using SMTP"""
        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = self.from_email
            msg['To'] = to_email
            
            # Attach HTML content
            html_part = MIMEText(html_content, 'html')
            msg.attach(html_part)
            
            # Send email
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.send_message(msg)
            
            logger.info(f"Email sent to {to_email}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send email: {e}")
            return False
    
    def send_sms_notification(self, phone_number: str, message: str) -> bool:
        """Send SMS notification (placeholder for SMS gateway integration)"""
        # Implement SMS gateway integration here
        # Example: Twilio, MessageBird, etc.
        logger.info(f"SMS to {phone_number}: {message}")
        return True