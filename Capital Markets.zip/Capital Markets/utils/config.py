import os
from datetime import datetime
from typing import List, Dict, Any  # Add this import

class Config:
    # LangChain Configuration for DeepSeek-V3
    LANGCHAIN_MODEL = "azure_ai/genailab-maas-DeepSeek-V3-0324"
    LANGCHAIN_BASE_URL = "https://genailab.tcs.in"
    LANGCHAIN_API_KEY = "sk-nbpzhqeCWDjNbBW5RssHWA"
    
    # Data Sources
    MARKET_DATA_SOURCES = {
        "yahoo_finance": "yfinance",
        "alpha_vantage": "alpha_vantage"
    }
    
    # Scenario Types
    SCENARIO_TYPES: List[str] = [
        "Market Crash",
        "Interest Rate Shock",
        "Geopolitical Crisis",
        "Currency Devaluation",
        "Commodity Price Spike",
        "Liquidity Crisis",
        "Cyber Attack on Financial Systems"
    ]
    
    # Portfolio Types
    PORTFOLIO_TYPES: List[str] = [
        "Equity Heavy",
        "Fixed Income",
        "Balanced",
        "Hedge Fund",
        "Retirement Portfolio"
    ]
    
    # Historical Crisis Events
    HISTORICAL_CRISES: List[Dict[str, Any]] = [
        {"name": "2008 Financial Crisis", "year": 2008, "severity": "High"},
        {"name": "2020 COVID-19 Crash", "year": 2020, "severity": "High"},
        {"name": "2000 Dot-com Bubble", "year": 2000, "severity": "Medium"},
        {"name": "1987 Black Monday", "year": 1987, "severity": "High"},
        {"name": "1997 Asian Financial Crisis", "year": 1997, "severity": "Medium"},
        {"name": "2010 European Debt Crisis", "year": 2010, "severity": "Medium"}
    ]

    