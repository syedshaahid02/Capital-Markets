import json
import pandas as pd
from datetime import datetime, timedelta
import numpy as np

def validate_scenario_data(scenario_data):
    """Validate generated scenario data structure"""
    required_fields = ['scenario_type', 'scenario_overview', 'portfolio_impact']
    
    for field in required_fields:
        if field not in scenario_data:
            return False, f"Missing required field: {field}"
    
    return True, "Valid"

def format_currency(value):
    """Format numeric value as currency"""
    try:
        return f"${float(value):,.2f}"
    except (ValueError, TypeError):
        return value

def calculate_portfolio_metrics(scenarios, portfolio_value=1000000):
    """Calculate portfolio risk metrics from scenarios"""
    if not scenarios:
        return {}
    
    # Extract VaR estimates
    var_values = []
    for scenario in scenarios:
        risk_metrics = scenario.get('risk_metrics', {})
        var_estimate = risk_metrics.get('var_95', '15-25%')
        
        # Parse VaR range
        if '-' in str(var_estimate):
            try:
                var_low, var_high = map(float, str(var_estimate).replace('%', '').split('-'))
                var_avg = (var_low + var_high) / 2
                var_values.append(var_avg)
            except:
                var_values.append(20)  # Default
        else:
            var_values.append(20)  # Default
    
    if var_values:
        avg_var = np.mean(var_values)
        max_var = np.max(var_values)
        min_var = np.min(var_values)
    else:
        avg_var = max_var = min_var = 0
    
    return {
        'average_var': f"{avg_var:.1f}%",
        'worst_case_var': f"{max_var:.1f}%",
        'best_case_var': f"{min_var:.1f}%",
        'estimated_max_loss': format_currency(portfolio_value * (max_var / 100)),
        'scenario_count': len(scenarios)
    }

def generate_timestamp():
    """Generate consistent timestamp format"""
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def save_scenarios_to_file(scenarios, filename=None):
    """Save scenarios to JSON file"""
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"scenarios_backup_{timestamp}.json"
    
    try:
        with open(filename, 'w') as f:
            json.dump(scenarios, f, indent=2)
        return True, filename
    except Exception as e:
        return False, str(e)

def load_scenarios_from_file(filename):
    """Load scenarios from JSON file"""
    try:
        with open(filename, 'r') as f:
            scenarios = json.load(f)
        return True, scenarios
    except Exception as e:
        return False, str(e)
    

    