from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, SystemMessage
import httpx
import json
from typing import Dict, List, Any  # Add this import
import time

class Config:
    # LangChain Configuration for DeepSeek-V3
    LANGCHAIN_MODEL = "azure_ai/genailab-maas-DeepSeek-V3-0324"
    LANGCHAIN_BASE_URL = "https://genailab.tcs.in"
    LANGCHAIN_API_KEY = "sk-nbpzhqeCWDjNbBW5RssHWA"
    
    # Scenario Types
    SCENARIO_TYPES = [
        "Market Crash",
        "Interest Rate Shock",
        "Geopolitical Crisis",
        "Currency Devaluation",
        "Commodity Price Spike",
        "Liquidity Crisis",
        "Cyber Attack on Financial Systems"
    ]
    
    # Portfolio Types
    PORTFOLIO_TYPES = [
        "Equity Heavy",
        "Fixed Income",
        "Balanced",
        "Hedge Fund",
        "Retirement Portfolio"
    ]

class LLMIntegration:
    def __init__(self):
        try:
            self.client = httpx.Client(verify=False)
            self.llm = ChatOpenAI(
                base_url=Config.LANGCHAIN_BASE_URL,
                model=Config.LANGCHAIN_MODEL,
                api_key=Config.LANGCHAIN_API_KEY,
                http_client=self.client
            )
            self.connection_working = True
        except Exception as e:
            print(f"LLM initialization failed: {e}")
            self.connection_working = False
    
    def generate_scenario(self, scenario_type: str, market_context: Dict, portfolio_type: str) -> Dict[str, Any]:
        """Generate risk scenario using DeepSeek-V3 via LangChain"""
        
        if not self.connection_working:
            return self._get_fallback_scenario(scenario_type)
        
        prompt = self._build_scenario_prompt(scenario_type, market_context, portfolio_type)
        
        try:
            response = self.llm.invoke([
                SystemMessage(content="You are a senior risk management analyst at a major financial institution. Provide structured, data-driven risk analysis in JSON format."),
                HumanMessage(content=prompt)
            ])
            
            scenario_content = response.content
            return self._parse_scenario_response(scenario_content, scenario_type)
            
        except Exception as e:
            print(f"Error generating scenario: {e}")
            return self._get_fallback_scenario(scenario_type)
    
    def _build_scenario_prompt(self, scenario_type: str, market_context: Dict, portfolio_type: str) -> str:
        """Build detailed prompt for scenario generation"""
        
        return f"""
        Generate a detailed financial risk scenario analysis in JSON format.
        
        SCENARIO TYPE: {scenario_type}
        PORTFOLIO TYPE: {portfolio_type}
        CURRENT MARKET CONTEXT: {json.dumps(market_context, indent=2)}
        
        Provide a structured JSON analysis with these exact keys:
        
        {{
            "scenario_overview": "Brief description of the risk event",
            "market_context": "Detailed market conditions and triggers",
            "timeline": "Event progression timeline",
            "portfolio_impact": "Specific impacts on the portfolio type",
            "risk_metrics": {{
                "var_95": "Value at Risk at 95% confidence",
                "expected_shortfall": "Expected shortfall estimate",
                "volatility_spike": "Volatility impact",
                "liquidity_impact": "Liquidity impact assessment"
            }},
            "mitigation_strategies": ["List", "of", "mitigation", "strategies"],
            "monitoring_indicators": ["Key", "indicators", "to", "watch"]
        }}
        
        Make the scenario realistic, data-driven, and actionable for risk managers.
        Focus on plausible market movements and their cascading effects.
        
        Return ONLY valid JSON format, no additional text.
        """
    
    def _parse_scenario_response(self, response: str, scenario_type: str) -> Dict[str, Any]:
        """Parse LLM response into structured scenario"""
        try:
            # Extract JSON from response
            start_idx = response.find('{')
            end_idx = response.rfind('}') + 1
            
            if start_idx != -1 and end_idx != -1:
                json_str = response[start_idx:end_idx]
                scenario_data = json.loads(json_str)
            else:
                # If JSON extraction fails, create from text
                scenario_data = self._create_structured_from_text(response, scenario_type)
            
            scenario_data['scenario_type'] = scenario_type
            scenario_data['generated_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
            scenario_data['model_used'] = Config.LANGCHAIN_MODEL
            
            return scenario_data
            
        except json.JSONDecodeError as e:
            print(f"JSON parsing error: {e}")
            return self._get_fallback_scenario(scenario_type)
    
    def _create_structured_from_text(self, text: str, scenario_type: str) -> Dict[str, Any]:
        """Create structured data from text response"""
        return {
            "scenario_overview": text[:300] + "..." if len(text) > 300 else text,
            "market_context": "Market stress conditions with elevated volatility",
            "timeline": "Event unfolds over 2-4 weeks with peak impact in first week",
            "portfolio_impact": f"Significant impact on portfolio requiring active risk management",
            "risk_metrics": {
                "var_95": "20-30%",
                "expected_shortfall": "25-35%",
                "volatility_spike": "2-3x normal levels",
                "liquidity_impact": "High"
            },
            "mitigation_strategies": [
                "Increase cash positions to 10-15%",
                "Implement protective hedging strategies",
                "Diversify across uncorrelated assets"
            ],
            "monitoring_indicators": [
                "VIX levels above 30",
                "Credit spread widening",
                "Market depth indicators"
            ]
        }
    
    def _get_fallback_scenario(self, scenario_type: str) -> Dict[str, Any]:
        """Provide fallback scenario if LLM fails"""
        return {
            "scenario_type": scenario_type,
            "scenario_overview": f"Standard {scenario_type} scenario for stress testing",
            "market_context": "Market stress conditions with elevated volatility and reduced liquidity",
            "timeline": "Event progression over 2-4 weeks",
            "portfolio_impact": "Significant drawdown expected across asset classes",
            "risk_metrics": {
                "var_95": "15-25%",
                "expected_shortfall": "20-30%",
                "volatility_spike": "2-3x normal levels",
                "liquidity_impact": "Medium to High"
            },
            "mitigation_strategies": [
                "Increase cash positions",
                "Hedge with options strategies",
                "Diversify across uncorrelated assets",
                "Review and adjust leverage"
            ],
            "monitoring_indicators": [
                "VIX levels",
                "Credit spreads", 
                "Market liquidity metrics",
                "Economic indicators"
            ],
            "generated_at": time.strftime('%Y-%m-%d %H:%M:%S'),
            "model_used": Config.LANGCHAIN_MODEL,
            "fallback_used": True
        }
    
    def test_connection(self):
        """Test the LLM connection"""
        try:
            response = self.llm.invoke("Hello, please respond with 'Connection successful' if you can read this.")
            return True, response.content
        except Exception as e:
            return False, str(e)
        
