from PIL import Image, ImageDraw, ImageFont
import os

def create_test_files():
    """Create test KYC documents that should be rejected"""
    
    # Create test directory
    os.makedirs('test_reject_docs', exist_ok=True)
    
    # 1. Fake Aadhaar
    create_fake_aadhaar()
    
    # 2. Expired Passport
    create_expired_passport()
    
    # 3. Old Utility Bill
    create_old_utility_bill()
    
    # 4. Chair Photo
    create_chair_photo()
    
    # 5. Blurry Document
    create_blurry_document()
    
    print("\n✅ Created test rejection documents in 'test_reject_docs/' folder")
    print("\n📋 Expected Rejection Reasons:")
    print("1. fake_aadhaar.jpg - Invalid format, no photo")
    print("2. expired_passport.jpg - Document expired")
    print("3. old_utility_bill.jpg - Too old (>3 months)")
    print("4. chair_photo.jpg - No face detected")
    print("5. blurry_document.jpg - Unreadable text")

def create_fake_aadhaar():
    img = Image.new('RGB', (800, 500), color='lightblue')
    draw = ImageDraw.Draw(img)
    
    # Draw fake aadhaar
    draw.rectangle([10, 10, 790, 490], outline='red', width=3)
    draw.text((50, 50), "FAKE AADHAAR CARD (REJECT)", fill='red')
    draw.text((50, 100), "Name: TEST USER", fill='black')
    draw.text((50, 130), "Aadhaar No: 9999-9999-9999", fill='black')
    draw.text((50, 160), "DOB: 99-99-9999 (INVALID)", fill='black')
    draw.text((50, 190), "Address: Fake Address", fill='black')
    draw.text((50, 220), "NO PHOTO PRESENT", fill='red')
    draw.text((50, 280), "⚠️ SHOULD BE REJECTED ⚠️", fill='red')
    draw.text((50, 310), "Reasons: Invalid format, No photo", fill='red')
    
    img.save('test_reject_docs/fake_aadhaar.jpg')

def create_expired_passport():
    img = Image.new('RGB', (800, 500), color='beige')
    draw = ImageDraw.Draw(img)
    
    draw.rectangle([10, 10, 790, 490], outline='blue', width=2)
    draw.text((50, 50), "EXPIRED PASSPORT (REJECT)", fill='red')
    draw.text((50, 100), "Passport No: A0000000", fill='black')
    draw.text((50, 130), "Issue Date: 01-01-2010", fill='black')
    draw.text((50, 160), "Expiry Date: 01-01-2015 ⚠️", fill='red')
    draw.text((50, 190), "Status: EXPIRED 9 YEARS AGO", fill='red')
    draw.text((50, 250), "RBI Guideline: Max 10 years validity", fill='black')
    draw.text((50, 280), "Photo: Too old (10+ years)", fill='black')
    
    img.save('test_reject_docs/expired_passport.jpg')

def create_old_utility_bill():
    img = Image.new('RGB', (800, 500), color='white')
    draw = ImageDraw.Draw(img)
    
    draw.text((50, 50), "OLD UTILITY BILL (REJECT)", fill='red')
    draw.text((50, 100), "Electricity Bill", fill='black')
    draw.text((50, 130), "Customer: Test User", fill='black')
    draw.text((50, 160), "Billing Period: Jan-Feb 2020", fill='black')
    draw.text((50, 190), "Issue Date: 15-02-2020", fill='red')
    draw.text((50, 220), "Age: 4+ years old", fill='red')
    draw.text((50, 280), "RBI Guideline: Address proof max 3 months", fill='black')
    draw.text((50, 310), "REJECTION: Document too old", fill='red')
    
    img.save('test_reject_docs/old_utility_bill.jpg')

def create_chair_photo():
    img = Image.new('RGB', (400, 500), color='white')
    draw = ImageDraw.Draw(img)
    
    # Draw a simple chair
    draw.rectangle([150, 200, 250, 300], outline='brown', width=3)  # Seat
    draw.line([200, 300, 200, 400], fill='brown', width=3)  # Leg
    draw.line([150, 400, 250, 400], fill='brown', width=3)  # Base
    
    draw.text((100, 50), "CHAIR PHOTO (REJECT)", fill='red')
    draw.text((100, 420), "⚠️ NO FACE DETECTED ⚠️", fill='red')
    draw.text((80, 450), "This is a chair, not a person", fill='red')
    
    img.save('test_reject_docs/chair_photo.jpg')

def create_blurry_document():
    img = Image.new('RGB', (800, 500), color='gray')
    draw = ImageDraw.Draw(img)
    
    # Simulate blurry text
    draw.text((50, 50), "BLURRY DOCUMENT (REJECT)", fill='white')
    
    # Unreadable text
    for i in range(100, 300, 30):
        draw.text((50, i), "#" * 40, fill='darkgray')
    
    draw.text((50, 350), "TEXT CANNOT BE EXTRACTED", fill='red')
    draw.text((50, 380), "OCR FAILURE - POOR QUALITY", fill='red')
    draw.text((50, 410), "REJECTED: Unreadable document", fill='red')
    
    img.save('test_reject_docs/blurry_document.jpg')

if __name__ == "__main__":
    create_test_files()