import pytesseract
from PIL import Image
import cv2
import numpy as np
import io
from pdf2image import convert_from_bytes
import tempfile
import os
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)

class OCRProcessor:
    def __init__(self):
        # Configure Tesseract path if needed (for Windows)
        # pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
        pass
    
    def extract_text_from_image(self, image_data: bytes) -> str:
        """Extract text from image bytes"""
        try:
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to grayscale
            if image.mode != 'L':
                image = image.convert('L')
            
            # Use pytesseract to extract text
            text = pytesseract.image_to_string(image)
            return text.strip()
        except Exception as e:
            logger.error(f"Error extracting text from image: {e}")
            return ""
    
    def extract_text_from_pdf(self, pdf_data: bytes) -> str:
        """Extract text from PDF using OCR"""
        try:
            # Convert PDF to images
            images = convert_from_bytes(pdf_data)
            
            extracted_text = []
            for image in images:
                text = self.extract_text_from_image(self._pil_to_bytes(image))
                extracted_text.append(text)
            
            return "\n".join(extracted_text)
        except Exception as e:
            logger.error(f"Error extracting text from PDF: {e}")
            return ""
    
    def process_document(self, file_data: bytes, filename: str) -> str:
        """Process document based on file type"""
        file_extension = filename.lower().split('.')[-1]
        
        if file_extension in ['jpg', 'jpeg', 'png']:
            return self.extract_text_from_image(file_data)
        elif file_extension == 'pdf':
            return self.extract_text_from_pdf(file_data)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")
    
    def validate_id_proof(self, extracted_text: str) -> Dict[str, Any]:
        """Validate ID proof document"""
        validation_result = {
            'is_valid': False,
            'document_type': None,
            'document_number': None,
            'name': None,
            'dob': None,
            'issues': []
        }
        
        text_lower = extracted_text.lower()
        
        # Check for common ID types
        if 'aadhaar' in text_lower or 'aadhar' in text_lower or 'uidai' in text_lower:
            validation_result['document_type'] = 'Aadhaar'
        elif 'passport' in text_lower:
            validation_result['document_type'] = 'Passport'
        elif 'driving' in text_lower and 'license' in text_lower:
            validation_result['document_type'] = 'Driving License'
        elif 'pan' in text_lower and 'card' in text_lower:
            validation_result['document_type'] = 'PAN Card'
        else:
            validation_result['issues'].append('Could not identify document type')
        
        # Extract document number (simplified pattern matching)
        import re
        
        # Look for patterns like XXXXX-XXXX-XXXX or similar
        patterns = [
            r'\d{4}[-\s]?\d{4}[-\s]?\d{4}',  # Aadhaar like
            r'[A-Z]{5}\d{4}[A-Z]{1}',  # PAN
            r'[A-Z]{1}\d{7}',  # Passport
            r'[A-Z]{2}\d{2}\s?\d{11}'  # DL
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, extracted_text.upper())
            if matches:
                validation_result['document_number'] = matches[0]
                break
        
        if not validation_result['document_number']:
            validation_result['issues'].append('Could not extract document number')
        
        # Basic validation
        if validation_result['document_type'] and validation_result['document_number']:
            validation_result['is_valid'] = True
        
        return validation_result
    
    def validate_address_proof(self, extracted_text: str) -> Dict[str, Any]:
        """Validate address proof document"""
        validation_result = {
            'is_valid': False,
            'address_found': False,
            'date_found': False,
            'issues': []
        }
        
        text_lower = extracted_text.lower()
        
        # Check for address indicators
        address_indicators = ['house', 'street', 'road', 'lane', 'avenue', 'plot', 
                             'flat', 'apartment', 'building', 'floor', 'sector']
        
        for indicator in address_indicators:
            if indicator in text_lower:
                validation_result['address_found'] = True
                break
        
        # Check for date (utility bills have dates)
        import re
        date_patterns = [
            r'\d{2}[-/]\d{2}[-/]\d{4}',
            r'\d{2}[-/]\d{2}[-/]\d{2}',
            r'(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{1,2},? \d{4}',
            r'\d{1,2} (jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{4}'
        ]
        
        for pattern in date_patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                validation_result['date_found'] = True
                break
        
        if validation_result['address_found']:
            validation_result['is_valid'] = True
        else:
            validation_result['issues'].append('No valid address found in document')
        
        return validation_result
    
    def _pil_to_bytes(self, image: Image.Image) -> bytes:
        """Convert PIL Image to bytes"""
        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        return img_byte_arr.getvalue()