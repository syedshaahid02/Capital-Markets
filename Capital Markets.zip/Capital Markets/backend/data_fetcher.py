import yfinance as yf
import pandas as pd
import requests
import numpy as np
from datetime import datetime, timedelta
import time
from typing import Dict, Any  # Add this import

class MarketDataFetcher:
    def __init__(self):
        self.cache = {}
    
    def get_stock_data(self, symbol, period="1y"):
        """Fetch stock data from Yahoo Finance"""
        try:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period=period)
            return data
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return None
    
    def get_multiple_stocks(self, symbols, period="1y"):
        """Fetch multiple stock data"""
        data = {}
        for symbol in symbols:
            stock_data = self.get_stock_data(symbol, period)
            if stock_data is not None:
                data[symbol] = stock_data
            time.sleep(0.1)  # Rate limiting
        return data
    
    def get_market_indices(self) -> Dict[str, Any]:
        """Fetch major market indices"""
        indices = {
            "SPY": "S&P 500",
            "QQQ": "NASDAQ 100",
            "IWM": "Russell 2000",
            "EFA": "EAFE Index",
            "EEM": "Emerging Markets"
        }
        return self.get_multiple_stocks(list(indices.keys()))
    
    def get_volatility_data(self) -> Dict[str, Any]:
        """Fetch volatility indices"""
        vix_data = self.get_stock_data("^VIX", "6mo")
        return {"VIX": vix_data}
    
    def get_economic_indicators(self):
        """Simulate economic indicators data"""
        dates = pd.date_range(start='2023-01-01', end=datetime.now(), freq='M')
        indicators = {
            'GDP_Growth': np.random.normal(2.5, 1, len(dates)),
            'Inflation': np.random.normal(3.0, 0.5, len(dates)),
            'Unemployment': np.random.normal(4.0, 0.3, len(dates)),
            'Interest_Rate': np.random.normal(2.0, 0.2, len(dates))
        }
        
        econ_data = pd.DataFrame(indicators, index=dates)
        return econ_data
    
    def get_current_market_snapshot(self) -> Dict[str, Any]:
        """Get current market overview"""
        try:
            spy = yf.Ticker("SPY")
            info = spy.info
            current_price = info.get('regularMarketPrice', 0)
            previous_close = info.get('regularMarketPreviousClose', 0)
            change = ((current_price - previous_close) / previous_close) * 100
            
            vix = yf.Ticker("^VIX")
            vix_price = vix.info.get('regularMarketPrice', 0)
            
            return {
                "sp500_price": current_price,
                "sp500_change": change,
                "vix_level": vix_price,
                "market_sentiment": "Bullish" if change > 0 else "Bearish",
                "timestamp": datetime.now()
            }
        except Exception as e:
            print(f"Error getting market snapshot: {e}")
            return None
        

        