import sys
import os
import hashlib
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from backend.database import SessionLocal, Customer

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

# Test users to add
test_users = [
    {
        'email': 'john.doe@example.com',
        'password': 'password123',
        'full_name': 'John Doe',
        'phone': '9876543210'
    },
    {
        'email': 'alice.williams@example.com',
        'password': 'alicepass789',
        'full_name': 'Alice Williams',
        'phone': '9123456780'
    },
    {
        'email': 'bob.miller@example.com',
        'password': 'bobpassword456',
        'full_name': 'Bob Miller',
        'phone': '9988776655'
    }
]

db = SessionLocal()

try:
    for user_data in test_users:
        # Check if user exists
        existing = db.query(Customer).filter_by(email=user_data['email']).first()
        
        if not existing:
            new_user = Customer(
                email=user_data['email'],
                password=hash_password(user_data['password']),
                full_name=user_data['full_name'],
                phone=user_data['phone'],
                created_at=datetime.utcnow()
            )
            db.add(new_user)
            print(f"✅ Added user: {user_data['email']}")
        else:
            print(f"ℹ️ User already exists: {user_data['email']}")
    
    db.commit()
    print("\n🎯 Test users added successfully!")
    
except Exception as e:
    db.rollback()
    print(f"❌ Error: {e}")
    
finally:
    db.close()