from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from decouple import config

DATABASE_URL = config('DATABASE_URL', default='sqlite:///banking_kyc.db')

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    phone = Column(String(20))
    created_at = Column(DateTime, default=datetime.utcnow)
    is_verified = Column(Boolean, default=False)

class KYCDocument(Base):
    __tablename__ = "kyc_documents"
    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, nullable=False)
    document_type = Column(String(100), nullable=False)
    file_path = Column(String(500), nullable=False)
    original_filename = Column(String(255), nullable=False)
    status = Column(String(50), default='pending')
    verification_result = Column(Text)
    extracted_data = Column(Text)
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    verified_at = Column(DateTime)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer)
    action = Column(String(255), nullable=False)
    details = Column(Text)
    ip_address = Column(String(50))
    user_agent = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)

class RequiredDocument(Base):
    __tablename__ = "required_documents"
    id = Column(Integer, primary_key=True, index=True)
    document_type = Column(String(100), unique=True, nullable=False)
    description = Column(String(500))
    is_required = Column(Boolean, default=True)
    max_size_mb = Column(Integer, default=5)
    allowed_formats = Column(String(255), default='jpg,jpeg,png,pdf')

def init_db():
    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    try:
        required_docs = [
            {'document_type': 'id_proof', 'description': 'Government issued ID'},
            {'document_type': 'address_proof', 'description': 'Utility bill'},
            {'document_type': 'photo', 'description': 'Passport photo'}
        ]
        
        for doc in required_docs:
            if not session.query(RequiredDocument).filter_by(document_type=doc['document_type']).first():
                session.add(RequiredDocument(**doc))
        
        session.commit()
    except:
        session.rollback()
    finally:
        session.close()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()