import os

# Path to database.py
db_path = os.path.join('backend', 'database.py')

print(f"🔍 Checking: {db_path}")

if os.path.exists(db_path):
    # Read the file
    with open(db_path, 'r') as f:
        content = f.read()
    
    print(f"📊 File size: {len(content)} characters")
    
    # Check for init_db function
    if 'def init_db()' in content or 'def init_db(' in content:
        print("✅ init_db() function FOUND")
        
        # Find and show the function
        lines = content.split('\n')
        found = False
        for i, line in enumerate(lines):
            if 'def init_db' in line:
                print(f"\n📍 Found at line {i+1}:")
                print(f"   {line}")
                # Show next 10 lines
                for j in range(i, min(i+11, len(lines))):
                    print(f"   {j+1}: {lines[j]}")
                found = True
                break
        
        if not found:
            print("❌ Could not find init_db definition")
    else:
        print("❌ init_db() function NOT FOUND in content")
        
        # Show first 200 characters
        print("\n📝 First 200 characters:")
        print(content[:200])
        
        # Show last 200 characters
        print("\n📝 Last 200 characters:")
        print(content[-200:] if len(content) > 200 else content)
        
else:
    print(f"❌ File does not exist: {db_path}")
    
    # List backend directory
    print("\n📁 Contents of backend directory:")
    backend_dir = 'backend'
    if os.path.exists(backend_dir):
        for item in os.listdir(backend_dir):
            print(f"  - {item}")
    else:
        print("  Backend directory doesn't exist!")