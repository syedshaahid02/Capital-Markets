"""
Banking KYC Document Upload and Verification System
Main Application File - STRICT VERSION
"""
import streamlit as st
import os
import sys
from datetime import datetime
import hashlib
from typing import Optional, Dict, List, Tuple
import tempfile

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# Initialize session state
def init_session_state():
    """Initialize session state variables"""
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'customer_id' not in st.session_state:
        st.session_state.customer_id = None
    if 'customer_name' not in st.session_state:
        st.session_state.customer_name = None
    if 'kyc_complete' not in st.session_state:
        st.session_state.kyc_complete = False
    if 'ai_enabled' not in st.session_state:
        st.session_state.ai_enabled = True
    if 'verification_history' not in st.session_state:
        st.session_state.verification_history = []

# Hash password function
def hash_password(password: str) -> str:
    """Simple password hashing"""
    return hashlib.sha256(password.encode()).hexdigest()

# Database functions
def init_database():
    """Initialize database"""
    try:
        from backend.database import init_db
        init_db()
        return True
    except Exception as e:
        st.error(f"Database error: {e}")
        return False

def authenticate_user(email: str, password: str) -> Optional[Dict]:
    """Authenticate user"""
    try:
        from backend.database import SessionLocal, Customer
        hashed_pw = hash_password(password)
        db = SessionLocal()
        customer = db.query(Customer).filter_by(email=email, password=hashed_pw).first()
        db.close()
        
        if customer:
            return {
                'id': customer.id,
                'email': customer.email,
                'full_name': customer.full_name,
                'is_verified': customer.is_verified
            }
        return None
    except Exception as e:
        st.error(f"Authentication error: {e}")
        return None

def register_user(user_data: Dict) -> Tuple[bool, str]:
    """Register new user"""
    try:
        from backend.database import SessionLocal, Customer, AuditLog
        
        db = SessionLocal()
        
        # Check if email exists
        existing = db.query(Customer).filter_by(email=user_data['email']).first()
        if existing:
            db.close()
            return False, "Email already registered"
        
        # Create new customer
        new_customer = Customer(
            email=user_data['email'],
            password=hash_password(user_data['password']),
            full_name=user_data['full_name'],
            phone=user_data.get('phone'),
            created_at=datetime.utcnow()
        )
        
        db.add(new_customer)
        db.commit()
        
        # Create audit log
        audit_log = AuditLog(
            customer_id=new_customer.id,
            action="user_registration",
            details=f"New user registered: {user_data['email']}",
            created_at=datetime.utcnow()
        )
        db.add(audit_log)
        db.commit()
        
        db.close()
        return True, "Registration successful"
        
    except Exception as e:
        return False, f"Registration failed: {str(e)}"

def get_required_documents() -> List[Dict]:
    """Get list of required documents"""
    try:
        from backend.database import SessionLocal, RequiredDocument
        db = SessionLocal()
        docs = db.query(RequiredDocument).filter_by(is_required=True).all()
        db.close()
        
        return [
            {
                'document_type': doc.document_type,
                'description': doc.description,
                'allowed_formats': doc.allowed_formats,
                'max_size_mb': doc.max_size_mb
            }
            for doc in docs
        ]
    except:
        return [
            {
                'document_type': 'id_proof',
                'description': 'Government issued ID',
                'allowed_formats': 'jpg,jpeg,png,pdf',
                'max_size_mb': 5
            },
            {
                'document_type': 'address_proof',
                'description': 'Utility bill or rental agreement',
                'allowed_formats': 'jpg,jpeg,png,pdf',
                'max_size_mb': 5
            },
            {
                'document_type': 'photo',
                'description': 'Recent passport size photograph',
                'allowed_formats': 'jpg,jpeg,png',
                'max_size_mb': 5
            }
        ]

def get_customer_documents(customer_id: int) -> List[Dict]:
    """Get customer's uploaded documents"""
    try:
        from backend.database import SessionLocal, KYCDocument
        db = SessionLocal()
        documents = db.query(KYCDocument).filter_by(customer_id=customer_id).all()
        db.close()
        
        return [
            {
                'document_type': doc.document_type,
                'status': doc.status,
                'uploaded_at': doc.uploaded_at,
                'verification_result': doc.verification_result,
                'extracted_data': doc.extracted_data
            }
            for doc in documents
        ]
    except:
        return []

def save_document_upload(customer_id: int, document_type: str, file_data: bytes,
                        filename: str, verification_result: Dict) -> bool:
    """Save document upload to database"""
    try:
        from backend.database import SessionLocal, KYCDocument, AuditLog
        import uuid
        
        db = SessionLocal()
        
        # Generate unique filename
        unique_filename = f"{customer_id}_{uuid.uuid4().hex}_{filename}"
        
        # Save file to uploads directory
        os.makedirs('uploads', exist_ok=True)
        filepath = os.path.join('uploads', unique_filename)
        with open(filepath, 'wb') as f:
            f.write(file_data)
        
        # Check if document exists
        existing = db.query(KYCDocument).filter_by(
            customer_id=customer_id,
            document_type=document_type
        ).first()
        
        status = 'verified' if verification_result.get('success') else 'rejected'
        
        if existing:
            # Update existing
            existing.file_path = filepath
            existing.status = status
            existing.verification_result = verification_result.get('message', '')
            existing.extracted_data = str(verification_result.get('extracted_data', {}))
            existing.verified_at = datetime.utcnow() if status == 'verified' else None
        else:
            # Create new
            new_doc = KYCDocument(
                customer_id=customer_id,
                document_type=document_type,
                file_path=filepath,
                original_filename=filename,
                status=status,
                verification_result=verification_result.get('message', ''),
                extracted_data=str(verification_result.get('extracted_data', {})),
                uploaded_at=datetime.utcnow(),
                verified_at=datetime.utcnow() if status == 'verified' else None
            )
            db.add(new_doc)
        
        # Create audit log
        audit_log = AuditLog(
            customer_id=customer_id,
            action=f"document_upload_{document_type}",
            details=f"Uploaded {document_type}: {status} - {verification_result.get('message', '')}",
            created_at=datetime.utcnow()
        )
        db.add(audit_log)
        
        db.commit()
        db.close()
        
        # Send notification if verification failed
        if status == 'rejected':
            send_notification(customer_id, 'document_rejected', {
                'document_type': document_type,
                'reasons': verification_result.get('issues', []),
                'message': verification_result.get('message', '')
            })
        elif status == 'verified':
            send_notification(customer_id, 'document_verified', {
                'document_type': document_type,
                'message': verification_result.get('message', '')
            })
            
        return True
        
    except Exception as e:
        st.error(f"Save document error: {e}")
        return False

def send_notification(customer_id: int, notification_type: str, data: Dict):
    """Send notification to customer"""
    try:
        from backend.database import SessionLocal, Customer
        from backend.notification import NotificationManager
        
        db = SessionLocal()
        customer = db.query(Customer).filter_by(id=customer_id).first()
        db.close()
        
        if customer:
            notifier = NotificationManager()
            
            if notification_type == 'document_rejected':
                notifier.send_kyc_status_update(
                    customer.email,
                    customer.full_name,
                    {
                        'status': 'document_rejected',
                        'document_type': data['document_type'],
                        'rejection_reasons': data['reasons'],
                        'message': data['message']
                    }
                )
            elif notification_type == 'document_verified':
                notifier.send_kyc_status_update(
                    customer.email,
                    customer.full_name,
                    {
                        'status': 'document_verified',
                        'document_type': data['document_type'],
                        'message': data['message']
                    }
                )
            elif notification_type == 'kyc_completed':
                notifier.send_kyc_status_update(
                    customer.email,
                    customer.full_name,
                    {
                        'status': 'kyc_completed',
                        'message': 'Your KYC verification is complete!'
                    }
                )
                
    except Exception as e:
        st.warning(f"Notification failed: {e}")

def get_audit_logs(customer_id: int, limit: int = 20) -> List[Dict]:
    """Get audit logs for customer"""
    try:
        from backend.database import SessionLocal, AuditLog
        db = SessionLocal()
        logs = db.query(AuditLog).filter_by(customer_id=customer_id)\
               .order_by(AuditLog.created_at.desc())\
               .limit(limit).all()
        db.close()
        
        return [
            {
                'timestamp': log.created_at,
                'action': log.action,
                'details': log.details
            }
            for log in logs
        ]
    except:
        return []

def check_kyc_completion(customer_id: int) -> bool:
    """Check if KYC is complete"""
    try:
        from backend.database import SessionLocal, KYCDocument, RequiredDocument
        
        db = SessionLocal()
        
        # Get required documents
        required_docs = db.query(RequiredDocument).filter_by(is_required=True).all()
        required_types = [doc.document_type for doc in required_docs]
        
        # Get verified documents
        verified_docs = db.query(KYCDocument).filter_by(
            customer_id=customer_id,
            status='verified'
        ).all()
        verified_types = [doc.document_type for doc in verified_docs]
        
        db.close()
        
        # Check if all required types are verified
        return all(doc_type in verified_types for doc_type in required_types)
        
    except:
        return False

# STRICT VERIFICATION FUNCTIONS
def verify_document_strict(file_data: bytes, filename: str, document_type: str) -> Dict:
    """Perform strict document verification"""
    try:
        # Check file size (5MB limit)
        file_size_mb = len(file_data) / (1024 * 1024)
        if file_size_mb > 5:
            return {
                'success': False,
                'status': 'rejected',
                'message': f'File size {file_size_mb:.1f}MB exceeds 5MB limit',
                'issues': ['File too large'],
                'confidence': 0.0
            }
        
        # Check file extension
        valid_extensions = ['jpg', 'jpeg', 'png', 'pdf']
        file_ext = filename.lower().split('.')[-1]
        if file_ext not in valid_extensions:
            return {
                'success': False,
                'status': 'rejected',
                'message': f'Invalid file type .{file_ext}. Allowed: {", ".join(valid_extensions)}',
                'issues': ['Invalid file format'],
                'confidence': 0.0
            }
        
        # Check if file is empty/corrupted
        if len(file_data) < 100:
            return {
                'success': False,
                'status': 'rejected',
                'message': 'File appears to be empty or corrupted',
                'issues': ['Empty/corrupted file'],
                'confidence': 0.0
            }
        
        # Try to import strict verifier
        try:
            from backend.strict_verifier import StrictKYCVerifier, VerificationStatus
            verifier = StrictKYCVerifier()
            
            # Map document type for verification
            verification_type = {
                'id_proof': 'id_document',
                'address_proof': 'address_document',
                'photo': 'photo'
            }.get(document_type, 'document')
            
            result = verifier.verify_document(file_data, filename, verification_type)
            
            # Convert to dict
            return {
                'success': result.status == VerificationStatus.APPROVED,
                'status': result.status.value,
                'message': result.recommendation,
                'issues': result.issues,
                'confidence': result.confidence,
                'compliance_checks': result.compliance_checks,
                'validation_details': result.validation_details,
                'extracted_data': result.extracted_data
            }
            
        except ImportError:
            # Fallback to basic OCR verification
            return verify_with_basic_ocr(file_data, filename, document_type)
            
    except Exception as e:
        return {
            'success': False,
            'status': 'error',
            'message': f'Verification error: {str(e)}',
            'issues': [str(e)],
            'confidence': 0.0
        }

def verify_with_basic_ocr(file_data: bytes, filename: str, document_type: str) -> Dict:
    """Basic OCR verification as fallback"""
    try:
        import pytesseract
        from PIL import Image
        import io
        
        # For PDF files
        if filename.lower().endswith('.pdf'):
            try:
                from pdf2image import convert_from_bytes
                images = convert_from_bytes(file_data)
                if not images:
                    return {
                        'success': False,
                        'status': 'rejected',
                        'message': 'PDF contains no readable pages',
                        'issues': ['Unreadable PDF'],
                        'confidence': 0.0
                    }
                text = pytesseract.image_to_string(images[0])
            except:
                return {
                    'success': False,
                    'status': 'rejected',
                    'message': 'Could not read PDF file',
                    'issues': ['PDF read error'],
                    'confidence': 0.0
                }
        else:
            # For image files
            try:
                image = Image.open(io.BytesIO(file_data))
                text = pytesseract.image_to_string(image)
            except:
                return {
                    'success': False,
                    'status': 'rejected',
                    'message': 'Could not read image file',
                    'issues': ['Image read error'],
                    'confidence': 0.0
                }
        
        # Check if text was extracted
        if not text or len(text.strip()) < 20:
            return {
                'success': False,
                'status': 'rejected',
                'message': 'No readable text found in document',
                'issues': ['OCR failed', 'No text extracted'],
                'confidence': 0.0
            }
        
        # Basic validation based on document type
        text_lower = text.lower()
        
        if document_type == 'id_proof':
            # Check for ID indicators
            id_indicators = ['aadhaar', 'aadhar', 'pan', 'passport', 'voter', 'driving', 'license']
            if not any(indicator in text_lower for indicator in id_indicators):
                return {
                    'success': False,
                    'status': 'rejected',
                    'message': 'Document does not appear to be a valid ID proof',
                    'issues': ['Invalid ID document'],
                    'confidence': 0.3,
                    'extracted_data': {'text_preview': text[:200]}
                }
        
        elif document_type == 'address_proof':
            # Check for address indicators
            address_indicators = ['address', 'street', 'road', 'lane', 'city', 'pincode', 'pin code']
            if not any(indicator in text_lower for indicator in address_indicators):
                return {
                    'success': False,
                    'status': 'rejected',
                    'message': 'Document does not appear to be a valid address proof',
                    'issues': ['Invalid address document'],
                    'confidence': 0.3,
                    'extracted_data': {'text_preview': text[:200]}
                }
        
        elif document_type == 'photo':
            # For photos, just check if it's a valid image
            try:
                image = Image.open(io.BytesIO(file_data))
                width, height = image.size
                if width < 300 or height < 300:
                    return {
                        'success': False,
                        'status': 'rejected',
                        'message': f'Photo resolution too low: {width}x{height}',
                        'issues': ['Low resolution'],
                        'confidence': 0.4
                    }
            except:
                return {
                    'success': False,
                    'status': 'rejected',
                    'message': 'Invalid image file',
                    'issues': ['Invalid image'],
                    'confidence': 0.0
                }
        
        return {
            'success': True,
            'status': 'approved',
            'message': 'Document verified (basic validation)',
            'issues': [],
            'confidence': 0.7,
            'extracted_data': {'text_preview': text[:500]}
        }
        
    except Exception as e:
        return {
            'success': False,
            'status': 'error',
            'message': f'OCR verification error: {str(e)}',
            'issues': [str(e)],
            'confidence': 0.0
        }

# UI Components
def show_login_page():
    """Show login/registration page"""
    st.title("🏦 Banking KYC Document Verification")
    st.markdown("---")
    
    tab1, tab2 = st.tabs(["Login", "Register"])
    
    with tab1:
        st.subheader("Login to Your Account")
        with st.form("login_form"):
            email = st.text_input("Email")
            password = st.text_input("Password", type="password")
            submit = st.form_submit_button("Login")
            
            if submit:
                if email and password:
                    user = authenticate_user(email, password)
                    if user:
                        st.session_state.logged_in = True
                        st.session_state.customer_id = user['id']
                        st.session_state.customer_name = user['full_name']
                        st.session_state.kyc_complete = user['is_verified']
                        st.success("Login successful!")
                        st.rerun()
                    else:
                        st.error("Invalid email or password")
                else:
                    st.warning("Please enter email and password")
    
    with tab2:
        st.subheader("Create New Account")
        with st.form("register_form"):
            full_name = st.text_input("Full Name")
            email = st.text_input("Email")
            phone = st.text_input("Phone Number")
            password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")
            submit = st.form_submit_button("Register")
            
            if submit:
                if password != confirm_password:
                    st.error("Passwords do not match!")
                elif not all([full_name, email, password]):
                    st.error("Please fill in all required fields")
                else:
                    user_data = {
                        'full_name': full_name,
                        'email': email,
                        'phone': phone,
                        'password': password
                    }
                    success, message = register_user(user_data)
                    if success:
                        st.success(message)
                        st.info("Please login with your credentials")
                    else:
                        st.error(message)
    
    # Show information
    st.markdown("---")
    st.subheader("⚠️ STRICT KYC VERIFICATION ACTIVE")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.error("**Strict Requirements:**\n• Clear, high-quality images\n• Valid, non-expired documents\n• No blur or tampering")
    with col2:
        st.warning("**Common Rejections:**\n• Blurry/unreadable\n• Expired documents\n• Invalid formats\n• Blank files")
    with col3:
        st.info("**Verification Process:**\n1. Upload documents\n2. Strict validation\n3. Instant feedback\n4. Account activation")

def show_dashboard():
    """Show main dashboard for logged-in users"""
    # Sidebar
    st.sidebar.title(f"Welcome, {st.session_state.customer_name}!")
    
    # Main content
    st.title("🏦 Banking KYC Document Verification")
    st.markdown("---")
    
    # Create tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "📄 Upload Documents", 
        "📋 Document Status", 
        "📊 KYC Progress",
        "📜 Audit Trail"
    ])
    
    with tab1:
        show_upload_tab_strict()
    
    with tab2:
        show_status_tab()
    
    with tab3:
        show_progress_tab()
    
    with tab4:
        show_audit_tab()
    
    # Logout button
    st.sidebar.markdown("---")
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.customer_id = None
        st.session_state.customer_name = None
        st.session_state.kyc_complete = False
        st.rerun()

def show_upload_tab_strict():
    """Show document upload tab with strict validation"""
    st.subheader("📄 Upload KYC Documents")
    
    # Warning about strict verification
    with st.expander("⚠️ **IMPORTANT: STRICT VERIFICATION ACTIVE**", expanded=True):
        st.error("""
        **Your documents will undergo strict validation:**
        
        ✅ **REQUIRED:**
        • Clear, high-quality images (min 800x600 pixels)
        • All text must be readable
        • No blur, glare, or obstructions
        • Valid, non-expired documents
        • Single document per upload
        • File size ≤ 5MB
        
        ❌ **WILL BE REJECTED:**
        • Blurry/unreadable images
        • Expired documents
        • Tampered/altered documents
        • Invalid formats
        • Blank/empty files
        • Multiple documents in one image
        """)
    
    required_docs = get_required_documents()
    customer_docs = get_customer_documents(st.session_state.customer_id)
    uploaded_types = [doc['document_type'] for doc in customer_docs]
    
    # Filter pending documents
    pending_docs = [doc for doc in required_docs if doc['document_type'] not in uploaded_types]
    
    if pending_docs:
        st.info(f"**You have {len(pending_docs)} document(s) remaining to upload.**")
        
        # Document selection
        selected_doc = st.selectbox(
            "Select Document Type",
            options=[doc['document_type'] for doc in pending_docs],
            format_func=lambda x: x.replace('_', ' ').title()
        )
        
        # Get selected document details
        doc_info = next((doc for doc in pending_docs if doc['document_type'] == selected_doc), None)
        
        if doc_info:
            with st.expander("📋 **Document Requirements**"):
                st.write(f"**Type:** {doc_info['description']}")
                st.write(f"**Allowed formats:** {doc_info['allowed_formats']}")
                st.write(f"**Max size:** {doc_info['max_size_mb']} MB")
                
                if selected_doc == 'id_proof':
                    st.write("**Valid Documents:** Aadhaar, PAN, Passport, Voter ID, Driving License")
                elif selected_doc == 'address_proof':
                    st.write("**Valid Documents:** Utility bill, Bank statement, Rental agreement (≤ 3 months old)")
                elif selected_doc == 'photo':
                    st.write("**Requirements:** Passport size, white background, clear face visible")
        
        # File upload
        uploaded_file = st.file_uploader(
            "Choose document file",
            type=['jpg', 'jpeg', 'png', 'pdf'],
            key=f"strict_upload_{selected_doc}",
            help="Upload a clear, high-quality document image"
        )
        
        if uploaded_file:
            # Show file info
            file_size_mb = len(uploaded_file.getvalue()) / 1024 / 1024
            file_info_col1, file_info_col2 = st.columns(2)
            with file_info_col1:
                st.info(f"**File:** {uploaded_file.name}")
            with file_info_col2:
                if file_size_mb > 5:
                    st.error(f"**Size:** {file_size_mb:.1f}MB ❌")
                else:
                    st.success(f"**Size:** {file_size_mb:.1f}MB ✅")
            
            # Preview for images
            if uploaded_file.type.startswith('image/'):
                st.image(uploaded_file, caption="Document Preview", use_column_width=True)
            elif uploaded_file.type == 'application/pdf':
                st.info("📄 PDF file uploaded")
        
        if uploaded_file and st.button("🚀 Submit for Strict Verification", type="primary"):
            with st.spinner("🔍 **Performing Strict Verification...**"):
                result = verify_document_strict(
                    uploaded_file.getvalue(),
                    uploaded_file.name,
                    selected_doc
                )
                
                # Store in verification history
                verification_entry = {
                    'timestamp': datetime.now(),
                    'document_type': selected_doc,
                    'filename': uploaded_file.name,
                    'result': result
                }
                st.session_state.verification_history.insert(0, verification_entry)
                
                # Display results
                st.markdown("---")
                st.subheader("📊 **Verification Results**")
                
                # Result badge
                if result['status'] == 'approved':
                    st.success(f"**✅ APPROVED**")
                    badge_color = "green"
                elif result['status'] == 'rejected':
                    st.error(f"**❌ REJECTED**")
                    badge_color = "red"
                elif result['status'] == 'suspicious':
                    st.warning(f"**⚠️ SUSPICIOUS**")
                    badge_color = "orange"
                else:
                    st.error(f"**🚨 ERROR**")
                    badge_color = "red"
                
                # Confidence score
                confidence = result.get('confidence', 0)
                st.metric("Confidence Score", f"{confidence:.1%}")
                
                # Issues if any
                if result.get('issues'):
                    with st.expander("📋 **Issues Found**", expanded=True):
                        for issue in result['issues']:
                            st.error(f"• {issue}")
                
                # Compliance checks
                if result.get('compliance_checks'):
                    with st.expander("🔒 **Compliance Checks**"):
                        checks = result['compliance_checks']
                        for key, value in checks.items():
                            if isinstance(value, bool):
                                if value:
                                    st.success(f"✅ {key}")
                                else:
                                    st.error(f"❌ {key}")
                            else:
                                st.info(f"📝 {key}: {value}")
                
                # Save to database
                if save_document_upload(
                    st.session_state.customer_id,
                    selected_doc,
                    uploaded_file.getvalue(),
                    uploaded_file.name,
                    result
                ):
                    # Check KYC completion
                    kyc_complete = check_kyc_completion(st.session_state.customer_id)
                    st.session_state.kyc_complete = kyc_complete
                    
                    if kyc_complete:
                        send_notification(st.session_state.customer_id, 'kyc_completed', {})
                        st.balloons()
                        st.success("🎉 **KYC VERIFICATION COMPLETE!**")
                    
                    st.success("Document status saved successfully!")
                    st.rerun()
                else:
                    st.error("Failed to save document status")
    
    else:
        st.success("✅ All required documents have been uploaded!")
        
        if st.session_state.kyc_complete:
            st.balloons()
            with st.expander("🎉 **KYC VERIFICATION COMPLETE!**", expanded=True):
                st.success("""
                **Congratulations! Your KYC verification is complete.**
                
                **Next Steps:**
                1. ✅ Account activation within 24 hours
                2. 📧 Welcome email with account details
                3. 📱 Access to mobile banking app
                4. 💳 Debit card dispatch (5-7 working days)
                5. 🏦 Full banking services access
                
                **You will receive notifications for each step.**
                """)
            
            if st.button("🏦 Proceed to Account Opening"):
                st.info("Redirecting to account opening portal...")
                # In production, redirect to account opening page
        else:
            st.info("📋 All documents uploaded. Final verification in progress.")

def show_status_tab():
    """Show document status tab"""
    st.subheader("Document Status")
    
    documents = get_customer_documents(st.session_state.customer_id)
    
    if not documents:
        st.info("No documents uploaded yet.")
        return
    
    # Create status cards
    for doc in documents:
        with st.container():
            col1, col2, col3 = st.columns([2, 1, 2])
            
            with col1:
                st.write(f"**{doc['document_type'].replace('_', ' ').title()}**")
                if doc.get('uploaded_at'):
                    st.caption(f"Uploaded: {doc['uploaded_at'].strftime('%Y-%m-%d %H:%M')}")
            
            with col2:
                if doc['status'] == 'verified':
                    st.success("✅ Verified")
                elif doc['status'] == 'rejected':
                    st.error("❌ Rejected")
                elif doc['status'] == 'pending':
                    st.warning("⏳ Pending")
                else:
                    st.info(doc['status'].title())
            
            with col3:
                if doc.get('verification_result'):
                    with st.expander("View Details"):
                        st.write(doc['verification_result'])
                        if doc.get('extracted_data'):
                            try:
                                import ast
                                data = ast.literal_eval(doc['extracted_data'])
                                if data:
                                    st.json(data, expanded=False)
                            except:
                                pass
            
            st.divider()

def show_progress_tab():
    """Show KYC progress tab"""
    st.subheader("KYC Progress Dashboard")
    
    required_docs = get_required_documents()
    customer_docs = get_customer_documents(st.session_state.customer_id)
    
    total = len(required_docs)
    uploaded = len(customer_docs)
    verified = sum(1 for doc in customer_docs if doc['status'] == 'verified')
    rejected = sum(1 for doc in customer_docs if doc['status'] == 'rejected')
    
    # Progress metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Required", total)
    
    with col2:
        st.metric("Uploaded", uploaded)
    
    with col3:
        st.metric("Verified", verified)
    
    with col4:
        st.metric("Rejected", rejected)
    
    # Overall progress bar
    progress = (verified / total) if total > 0 else 0
    st.progress(progress)
    st.write(f"**Overall Progress:** {progress:.0%}")
    
    # Document breakdown
    st.subheader("Document Details")
    
    for req_doc in required_docs:
        doc_type = req_doc['document_type']
        customer_doc = next((doc for doc in customer_docs if doc['document_type'] == doc_type), None)
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.write(f"**{doc_type.replace('_', ' ').title()}**")
            st.caption(req_doc['description'])
        
        with col2:
            if customer_doc:
                if customer_doc['status'] == 'verified':
                    st.success("✅ Verified")
                elif customer_doc['status'] == 'rejected':
                    st.error("❌ Rejected")
                    if customer_doc.get('verification_result'):
                        st.caption(customer_doc['verification_result'][:50] + "...")
                else:
                    st.info(customer_doc['status'].title())
            else:
                st.warning("📭 Not Uploaded")
    
    if verified == total:
        st.balloons()
        st.success("🎉 **All documents verified! KYC complete.**")

def show_audit_tab():
    """Show audit trail tab"""
    st.subheader("📜 Audit Trail")
    
    audit_logs = get_audit_logs(st.session_state.customer_id, limit=50)
    
    if not audit_logs:
        st.info("No audit logs available.")
        return
    
    # Display logs
    for log in audit_logs:
        with st.container():
            cols = st.columns([1, 3, 2])
            
            with cols[0]:
                if isinstance(log['timestamp'], datetime):
                    st.write(log['timestamp'].strftime("%H:%M"))
                else:
                    st.write("--:--")
            
            with cols[1]:
                action_display = log['action'].replace('_', ' ').title()
                st.write(f"**{action_display}**")
            
            with cols[2]:
                if log.get('details'):
                    st.caption(log['details'][:60] + "..." if len(log['details']) > 60 else log['details'])
        
        st.divider()
    
    # Export option
    if st.button("Export Audit Trail (CSV)"):
        import pandas as pd
        import io
        
        df = pd.DataFrame(audit_logs)
        csv = df.to_csv(index=False)
        
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name="audit_trail.csv",
            mime="text/csv"
        )

# Main application
def main():
    """Main application function"""
    # Setup page config MUST BE FIRST
    st.set_page_config(
        page_title="STRICT KYC Verification",
        page_icon="🔒",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session state
    init_session_state()
    
    # Initialize database (cached to run only once)
    @st.cache_resource
    def initialize_db():
        return init_database()
    
    if initialize_db():
        st.session_state.db_initialized = True
    
    # Check login status
    if not st.session_state.logged_in:
        show_login_page()
    else:
        show_dashboard()

if __name__ == "__main__":
    main()