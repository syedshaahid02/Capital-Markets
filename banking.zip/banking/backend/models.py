from pydantic import BaseModel, EmailStr, validator
from typing import Optional, List
from datetime import datetime

class CustomerCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: Optional[str] = None
    
    @validator('password')
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        return v

class CustomerLogin(BaseModel):
    email: EmailStr
    password: str

class DocumentUpload(BaseModel):
    document_type: str  # 'id_proof', 'address_proof', 'photo'
    customer_id: int

class VerificationResult(BaseModel):
    is_valid: bool
    message: str
    extracted_data: Optional[dict] = None
    issues: List[str] = []

class DocumentStatus(BaseModel):
    document_type: str
    status: str
    uploaded_at: Optional[datetime] = None
    verification_result: Optional[str] = None