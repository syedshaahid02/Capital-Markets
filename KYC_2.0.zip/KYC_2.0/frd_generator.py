import json
import pandas as pd
import streamlit as st
from datetime import datetime
import io

# ============= AI CONNECTION =============
from langchain_openai import ChatOpenAI
import httpx 
import os

# Configure AI client
client = httpx.Client(verify=False)
llm = ChatOpenAI(
    base_url='https://genailab.tcs.in',
    model='azure_ai/genailab-maas-DeepSeek-V3-0324',
    api_key='sk-J-1Za6zC1-ak3xnF0PfFRw',  # Add your API key here
    http_client=client,
    temperature=0.1,
    max_tokens=3000
)

# ============= CHROMADB INTEGRATION =============
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

CHROMA_DB_PATH = "chroma_frd"
COLLECTION_NAME = "frd_requirements"

class ChromaDBFrdManager:
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=CHROMA_DB_PATH,
            settings=Settings(anonymized_telemetry=False)
        )
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        try:
            self.collection = self.client.get_or_create_collection(
                name=COLLECTION_NAME,
                metadata={"hnsw:space": "cosine"}
            )
        except:
            self.collection = None
    
    def store_frd(self, frd_data):
        """Store FRD in ChromaDB"""
        try:
            if not self.collection:
                return False
            
            # Convert FRD to text for embedding
            frd_text = json.dumps(frd_data, indent=2)
            
            # Generate embedding
            embedding = self.embedding_model.encode(frd_text).tolist()
            
            # Store in ChromaDB
            self.collection.add(
                ids=[frd_data.get("document_id", "frd_1")],
                embeddings=[embedding],
                metadatas=[{
                    "type": "frd",
                    "version": frd_data.get("version", "1.0"),
                    "created": frd_data.get("created_date", datetime.now().isoformat()),
                    "project": frd_data.get("project", "KYC System")
                }],
                documents=[frd_text[:10000]]
            )
            return True
        except Exception as e:
            st.error(f"ChromaDB storage error: {str(e)}")
            return False
    
    def search_similar_frds(self, query, n_results=3):
        """Search for similar FRDs"""
        try:
            if not self.collection:
                return []
            
            query_embedding = self.embedding_model.encode(query).tolist()
            
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=n_results,
                include=["metadatas", "documents", "distances"]
            )
            
            return results
        except:
            return []

class FRDGenerator:
    def __init__(self):
        self.llm = llm
        self.chroma_db = ChromaDBFrdManager()
    
    def generate_frd_with_ai(self, project_details):
        """Generate FRD using AI with ChromaDB integration"""
        try:
            # Search for similar FRDs first
            similar_frds = []
            if self.chroma_db.collection:
                search_results = self.chroma_db.search_similar_frds(
                    f"KYC document verification system requirements {project_details['project_name']}"
                )
                
                if search_results and search_results['documents']:
                    similar_frds = search_results['documents'][0][:2]  # Get top 2
            
            prompt = f"""
            Generate a comprehensive Functional Requirements Document (FRD) for a Banking KYC Document Upload and Verification System with ChromaDB vector database integration.
            
            Project Details:
            {json.dumps(project_details, indent=2)}
            
            Similar FRDs for reference:
            {similar_frds}
            
            The FRD should include these NEW SECTIONS for ChromaDB:
            1. Vector Database Requirements
            2. Embedding Storage Specifications
            3. Semantic Search Capabilities
            4. Document Similarity Analysis
            5. Vector-based Fraud Detection
            6. ChromaDB Integration Architecture
            
            Format the response as a structured JSON document.
            Each requirement should have a unique ID starting with:
            - FR-VEC-xxx for vector database requirements
            - FR-AI-xxx for AI requirements
            - FR-DOC-xxx for document requirements
            
            Return ONLY valid JSON.
            """
            
            response = self.llm.invoke(prompt)
            ai_response = response.content
            
            try:
                start_idx = ai_response.find('{')
                end_idx = ai_response.rfind('}') + 1
                if start_idx != -1 and end_idx != 0:
                    json_str = ai_response[start_idx:end_idx]
                    frd = json.loads(json_str)
                    
                    # Store in ChromaDB
                    self.chroma_db.store_frd(frd)
                    
                    return frd
            except:
                pass
            
            return self.generate_frd_template()
            
        except Exception as e:
            st.error(f"AI Generation Error: {str(e)}")
            return self.generate_frd_template()
    
    def generate_frd_template(self):
        """Generate FRD template with ChromaDB sections"""
        frd = {
            "document_id": f"FRD-KYC-VECTOR-{datetime.now().strftime('%Y%m%d')}",
            "version": "2.0",
            "created_date": datetime.now().isoformat(),
            "project": "AI-Powered KYC with ChromaDB Vector Database",
            "ai_used": "DeepSeek-V3 via TCS GenAILab",
            "vector_db": "ChromaDB with SentenceTransformer embeddings",
            
            "1_INTRODUCTION": {
                "1.1_Purpose": "To automate KYC document verification using AI/OCR with ChromaDB vector storage",
                "1.2_Scope": "End-to-end KYC process with vector-based document analysis and semantic search",
                "1.3_Objectives": [
                    "Implement ChromaDB for document vector storage",
                    "Enable semantic search across KYC documents",
                    "Detect fraud patterns using vector similarity",
                    "Provide real-time document similarity analysis",
                    "Achieve 99.5% accuracy in document verification"
                ]
            },
            
            "2_VECTOR_DATABASE_REQUIREMENTS": {
                "FR-VEC-001": "System shall store document embeddings in ChromaDB vector database",
                "FR-VEC-002": "System shall use SentenceTransformer for document embeddings",
                "FR-VEC-003": "System shall enable semantic search across all KYC documents",
                "FR-VEC-004": "System shall calculate document similarity scores",
                "FR-VEC-005": "System shall cluster similar documents using vector embeddings",
                "FR-VEC-006": "System shall detect anomalies using vector distance analysis"
            },
            
            "3_AI_Powered_Verification": {
                "FR-AI-001": "System shall use DeepSeek AI for document analysis and validation",
                "FR-AI-002": "System shall extract text from documents using OCR with AI enhancement",
                "FR-AI-003": "System shall calculate confidence scores for document verification",
                "FR-AI-004": "System shall detect anomalies and fraud patterns using AI",
                "FR-AI-005": "System shall provide AI-generated verification reports"
            },
            
            "4_Document_Processing": {
                "FR-DOC-001": "System shall accept PDF, JPG, PNG formats up to 5MB",
                "FR-DOC-002": "System shall validate file format and size before upload",
                "FR-DOC-003": "System shall generate unique document IDs with AI analysis tracking",
                "FR-DOC-004": "System shall calculate file hash for integrity verification",
                "FR-DOC-005": "System shall store extracted text in ChromaDB as vectors"
            },
            
            "5_Semantic_Search_Capabilities": {
                "FR-SEM-001": "System shall provide semantic search across document content",
                "FR-SEM-002": "System shall find similar documents using vector similarity",
                "FR-SEM-003": "System shall enable customer-specific document search",
                "FR-SEM-004": "System shall provide similarity scores for search results",
                "FR-SEM-005": "System shall support fuzzy matching for document queries"
            },
            
            "6_ChromaDB_Integration": {
                "6.1_Architecture": {
                    "Vector Storage": "ChromaDB with persistent storage",
                    "Embedding Model": "SentenceTransformer all-MiniLM-L6-v2",
                    "Vector Dimension": "384 dimensions",
                    "Similarity Metric": "Cosine similarity",
                    "Collection Management": "Automatic collection creation and maintenance"
                },
                "6.2_Performance": {
                    "Query Speed": "< 100ms for vector searches",
                    "Storage Efficiency": "Compressed vector storage",
                    "Scalability": "Support for 1M+ document vectors",
                    "Concurrency": "100+ simultaneous vector queries"
                },
                "6.3_Security": {
                    "Data Encryption": "Vectors stored with encryption",
                    "Access Control": "Role-based access to vector DB",
                    "Audit Trail": "Log all vector operations",
                    "Data Isolation": "Customer data isolation in vectors"
                }
            },
            
            "7_Compliance_Requirements": {
                "7.1_Data_Protection": {
                    "GDPR compliance for EU customer vectors",
                    "Data retention policies for vector storage",
                    "Right to erasure for vector data",
                    "Data portability for embeddings"
                },
                "7.2_Audit_Trail": {
                    "Log all vector search operations",
                    "Track document similarity analyses",
                    "Record fraud detection triggers",
                    "Maintain vector operation history"
                }
            }
        }
        
        # Store template in ChromaDB
        self.chroma_db.store_frd(frd)
        
        return frd
    
    def display_frd_ui(self):
        """Display FRD in Streamlit UI with ChromaDB features"""
        st.title("📋 AI-Powered FRD with Vector Database")
        st.subheader("KYC Document Verification System with ChromaDB")
        
        # ChromaDB status
        chroma_status = "✅ Active" if self.chroma_db.collection else "❌ Inactive"
        st.sidebar.info(f"ChromaDB: {chroma_status}")
        
        # Project details input
        with st.expander("⚙️ Project Configuration", expanded=False):
            col1, col2 = st.columns(2)
            
            with col1:
                project_name = st.text_input("Project Name", 
                                           value="AI-Powered KYC with ChromaDB")
                project_version = st.text_input("Version", value="2.0")
                vector_db = st.selectbox("Vector Database", 
                                       ["ChromaDB", "Weaviate", "Pinecone", "Qdrant"],
                                       index=0)
            
            with col2:
                embedding_model = st.selectbox("Embedding Model",
                                             ["all-MiniLM-L6-v2", "BERT", "GPT Embeddings"],
                                             index=0)
                vector_dimension = st.number_input("Vector Dimension", value=384)
                similarity_metric = st.selectbox("Similarity Metric",
                                               ["Cosine", "Euclidean", "Dot Product"],
                                               index=0)
        
        # Generate FRD with AI
        if st.button("🤖 Generate FRD with AI & ChromaDB", type="primary"):
            with st.spinner("AI is generating FRD with vector database integration..."):
                project_details = {
                    "project_name": project_name,
                    "version": project_version,
                    "vector_database": vector_db,
                    "embedding_model": embedding_model,
                    "vector_dimension": vector_dimension,
                    "similarity_metric": similarity_metric,
                    "generation_date": datetime.now().isoformat()
                }
                
                frd = self.generate_frd_with_ai(project_details)
                st.session_state.frd = frd
                st.success("✅ FRD Generated & Stored in ChromaDB!")
        
        # Display FRD if available
        if 'frd' in st.session_state:
            frd = st.session_state.frd
            
            # Tabs for different views
            tabs = st.tabs([
                "Overview", "Vector DB Requirements", "AI Requirements",
                "Search FRDs", "Export"
            ])
            
            with tabs[0]:
                self.display_frd_overview(frd)
            
            with tabs[1]:
                self.display_vector_requirements(frd)
            
            with tabs[2]:
                self.display_ai_requirements(frd)
            
            with tabs[3]:
                self.search_frds_ui()
            
            with tabs[4]:
                self.export_frd_ui(frd)
    
    def display_frd_overview(self, frd):
        """Display FRD overview"""
        st.header("📄 Document Overview")
        
        overview_col1, overview_col2 = st.columns(2)
        
        with overview_col1:
            st.metric("Document ID", frd.get("document_id", "N/A"))
            st.metric("Version", frd.get("version", "2.0"))
            st.metric("Vector DB", frd.get("vector_db", "ChromaDB"))
        
        with overview_col2:
            st.metric("AI Provider", frd.get("ai_used", "DeepSeek-V3"))
            st.metric("Generated", frd.get("created_date", datetime.now().isoformat())[:10])
            st.metric("Project", frd.get("project", "KYC System"))
        
        # Introduction
        if "1_INTRODUCTION" in frd:
            st.subheader("Introduction")
            intro = frd["1_INTRODUCTION"]
            for key, value in intro.items():
                st.markdown(f"**{key.replace('_', '. ')}**")
                if isinstance(value, list):
                    for item in value:
                        st.write(f"• {item}")
                else:
                    st.write(value)
    
    def display_vector_requirements(self, frd):
        """Display vector database requirements"""
        st.header("🗄️ Vector Database Requirements")
        
        # Show all vector-related sections
        vector_sections = [key for key in frd.keys() if any(x in key.lower() for x in ['vec', 'sem', 'chroma'])]
        
        for section in vector_sections:
            if isinstance(frd[section], dict):
                with st.expander(f"{section.replace('_', ' ')}", expanded=True):
                    for req_id, req_desc in frd[section].items():
                        if isinstance(req_desc, dict):
                            # Handle nested dictionaries
                            for sub_key, sub_value in req_desc.items():
                                st.write(f"**{sub_key.replace('_', ' ')}**")
                                if isinstance(sub_value, list):
                                    for item in sub_value:
                                        st.write(f"• {item}")
                                else:
                                    st.write(sub_value)
                        else:
                            # Handle string requirements
                            st.write(f"**{req_id}**")
                            st.write(f"{req_desc}")
                        st.write("---")
    
    def display_ai_requirements(self, frd):
        """Display AI requirements"""
        st.header("🤖 AI & ML Requirements")
        
        # Show all AI-related sections
        ai_sections = [key for key in frd.keys() if 'ai' in key.lower()]
        
        for section in ai_sections:
            if isinstance(frd[section], dict):
                with st.expander(f"{section.replace('_', ' ')}", expanded=True):
                    for req_id, req_desc in frd[section].items():
                        st.write(f"**{req_id}**")
                        st.write(f"{req_desc}")
                        st.write("---")
    
    def search_frds_ui(self):
        """UI for searching FRDs in ChromaDB"""
        st.header("🔍 Search FRDs in Vector Database")
        
        search_query = st.text_area("Search for similar FRDs:",
                                  placeholder="e.g., 'KYC document verification requirements with vector database'",
                                  height=100)
        
        if st.button("Search ChromaDB", type="primary"):
            if search_query and self.chroma_db.collection:
                with st.spinner("Searching vector database..."):
                    results = self.chroma_db.search_similar_frds(search_query, n_results=3)
                    
                    if results and results['documents']:
                        st.success(f"✅ Found {len(results['documents'][0])} similar FRDs")
                        
                        for i, doc in enumerate(results['documents'][0]):
                            with st.expander(f"Similar FRD {i+1} (Similarity: {1-results['distances'][0][i]:.2%})"):
                                st.json(json.loads(doc[:2000] + "..."))
                    else:
                        st.info("No similar FRDs found.")
            else:
                st.warning("Please enter a search query.")
        
        # Show stored FRDs
        if st.button("Show All Stored FRDs", type="secondary"):
            if self.chroma_db.collection:
                try:
                    all_docs = self.chroma_db.collection.get()
                    if all_docs['ids']:
                        st.write(f"**Total FRDs in ChromaDB:** {len(all_docs['ids'])}")
                        
                        for i, doc_id in enumerate(all_docs['ids'][:5]):
                            with st.expander(f"FRD: {doc_id}"):
                                metadata = all_docs['metadatas'][i] if all_docs['metadatas'] else {}
                                st.write(f"**Project:** {metadata.get('project', 'N/A')}")
                                st.write(f"**Version:** {metadata.get('version', 'N/A')}")
                                st.write(f"**Created:** {metadata.get('created', 'N/A')}")
                except:
                    st.error("Error accessing ChromaDB")
            else:
                st.warning("ChromaDB not initialized")
    
    def export_frd_ui(self, frd):
        """UI for exporting FRD"""
        st.header("📥 Export FRD")
        
        # Export options
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # JSON Export
            json_str = json.dumps(frd, indent=2)
            st.download_button(
                label="Download JSON",
                data=json_str,
                file_name=f"kyc_frd_vector_{datetime.now().strftime('%Y%m%d')}.json",
                mime="application/json",
                use_container_width=True
            )
        
        with col2:
            # Markdown Export
            md_content = self.convert_to_markdown(frd)
            st.download_button(
                label="Download Markdown",
                data=md_content,
                file_name=f"kyc_frd_vector_{datetime.now().strftime('%Y%m%d')}.md",
                mime="text/markdown",
                use_container_width=True
            )
        
        with col3:
            # Requirements CSV
            requirements = self.extract_requirements(frd)
            if not requirements.empty:
                csv_data = requirements.to_csv(index=False)
                st.download_button(
                    label="Download Requirements CSV",
                    data=csv_data,
                    file_name=f"kyc_requirements_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv",
                    use_container_width=True
                )
        
        # AI Summary
        st.markdown("---")
        st.subheader("🤖 AI-Generated Summary")
        
        if st.button("Generate AI Summary"):
            with st.spinner("AI is generating summary..."):
                try:
                    summary_prompt = f"""
                    Provide a concise executive summary of this FRD with focus on vector database integration:
                    {json.dumps(frd, indent=2)}
                    
                    Include:
                    1. Key objectives for vector database integration
                    2. ChromaDB implementation details
                    3. Semantic search capabilities
                    4. AI and vector analytics synergy
                    5. Implementation roadmap highlights
                    
                    Keep it under 300 words.
                    """
                    
                    response = self.llm.invoke(summary_prompt)
                    st.info(response.content)
                except Exception as e:
                    st.error(f"AI Summary Error: {str(e)}")
    
    def extract_requirements(self, frd):
        """Extract requirements from FRD"""
        requirements = []
        
        for section_key, section_value in frd.items():
            if isinstance(section_value, dict) and any(x in section_key for x in ['FR-', 'REQ', 'VEC', 'AI', 'DOC']):
                for req_id, req_desc in section_value.items():
                    if req_id.startswith('FR-'):
                        requirements.append({
                            "Requirement_ID": req_id,
                            "Section": section_key.replace('_', ' '),
                            "Description": req_desc,
                            "Type": "Vector" if 'VEC' in req_id else "AI" if 'AI' in req_id else "Document",
                            "Priority": "High" if 'VEC' in req_id else "Medium"
                        })
        
        return pd.DataFrame(requirements)
    
    def convert_to_markdown(self, frd):
        """Convert FRD to Markdown format"""
        md = f"""# {frd.get('project', 'KYC Verification System')}
        
**Document ID:** {frd.get('document_id', 'N/A')}
**Version:** {frd.get('version', '2.0')}
**Vector Database:** {frd.get('vector_db', 'ChromaDB')}
**AI Provider:** {frd.get('ai_used', 'DeepSeek-V3')}
**Generated:** {frd.get('created_date', datetime.now().isoformat())}

## 1. Introduction

"""
        
        if "1_INTRODUCTION" in frd:
            intro = frd["1_INTRODUCTION"]
            for key, value in intro.items():
                md += f"### {key.replace('_', '. ')}\n\n"
                if isinstance(value, list):
                    for item in value:
                        md += f"- {item}\n"
                else:
                    md += f"{value}\n"
                md += "\n"
        
        # Add vector database section
        md += "## 2. Vector Database Integration\n\n"
        md += "### 2.1 ChromaDB Implementation\n\n"
        md += "- Document vector storage and retrieval\n"
        md += "- Semantic search capabilities\n"
        md += "- Similarity analysis and clustering\n"
        md += "- Fraud detection using vector patterns\n\n"
        
        return md

# Run FRD Generator
if __name__ == "__main__":
    generator = FRDGenerator()
    generator.display_frd_ui()