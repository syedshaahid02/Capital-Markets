import streamlit as st
import os
import pandas as pd
from datetime import datetime
from backend.report_generator import PDFReportGenerator

def report_manager_page():
    st.title("Report Manager")
    st.markdown("Generate and download comprehensive risk analysis reports in PDF format.")
    
    scenarios = st.session_state.get('scenarios', [])
    report_generator = PDFReportGenerator()
    
    if not scenarios:
        st.info("No scenarios available for reporting. Generate scenarios first on the Scenario Generator page.")
        st.markdown("[Go to Scenario Generator](/?page=3_Scenario_Generator)")
        return
    
    # Report generation options
    st.subheader("Report Generation Options")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Individual Scenario Reports")
        st.write("Generate detailed PDF reports for specific scenarios")
        
        # Scenario selection for individual reports
        scenario_options = [
            f"{s['scenario_type']} ({s.get('severity', 'Unknown')}) - {s.get('generated_at', '')}" 
            for s in scenarios
        ]
        
        selected_scenario_index = st.selectbox(
            "Select Scenario for Individual Report",
            options=range(len(scenario_options)),
            format_func=lambda x: scenario_options[x],
            help="Choose a scenario to generate a detailed PDF report"
        )
        
        report_style = st.selectbox(
            "Report Style",
            ["Detailed Analysis", "Executive Summary", "Technical Deep Dive"],
            help="Choose the style and depth of the report"
        )
        
        if st.button("Generate Individual Report", type="primary", use_container_width=True):
            with st.spinner("Generating PDF report..."):
                try:
                    selected_scenario = scenarios[selected_scenario_index]
                    report_path = report_generator.generate_scenario_report(selected_scenario)
                    
                    # Display download button
                    with open(report_path, "rb") as file:
                        st.download_button(
                            label="📥 Download Individual Report",
                            data=file,
                            file_name=os.path.basename(report_path),
                            mime="application/pdf",
                            use_container_width=True
                        )
                    st.success("Individual report generated successfully!")
                    
                except Exception as e:
                    st.error(f"Error generating individual report: {e}")
    
    with col2:
        st.markdown("#### Comprehensive Reports")
        st.write("Generate comprehensive reports covering all scenarios")
        
        comprehensive_type = st.selectbox(
            "Comprehensive Report Type",
            ["Full Analysis", "Executive Summary", "Risk Dashboard"],
            help="Choose the type of comprehensive report"
        )
        
        include_appendices = st.checkbox("Include Detailed Appendices", value=True)
        include_charts = st.checkbox("Include Charts and Visualizations", value=True)
        
        if st.button("Generate Comprehensive Report", type="primary", use_container_width=True):
            with st.spinner("Generating comprehensive report... This may take a few moments."):
                try:
                    report_path = report_generator.generate_comprehensive_report(scenarios)
                    
                    with open(report_path, "rb") as file:
                        st.download_button(
                            label="📥 Download Comprehensive Report",
                            data=file,
                            file_name=os.path.basename(report_path),
                            mime="application/pdf",
                            use_container_width=True
                        )
                    st.success("Comprehensive report generated successfully!")
                    
                except Exception as e:
                    st.error(f"Error generating comprehensive report: {e}")
    
    # Batch reporting
    st.subheader("Batch Reporting")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Selective Scenario Reports")
        st.write("Generate reports for selected scenarios only")
        
        # Multi-select for scenarios
        selected_scenarios_indices = st.multiselect(
            "Select Scenarios for Batch Report",
            options=range(len(scenarios)),
            format_func=lambda x: f"{scenarios[x]['scenario_type']} ({scenarios[x].get('severity', 'Unknown')})",
            help="Select multiple scenarios to include in a batch report"
        )
        
        if st.button("Generate Batch Report", use_container_width=True) and selected_scenarios_indices:
            with st.spinner("Generating batch report..."):
                try:
                    selected_scenarios_data = [scenarios[i] for i in selected_scenarios_indices]
                    report_path = report_generator.generate_comprehensive_report(selected_scenarios_data)
                    
                    with open(report_path, "rb") as file:
                        st.download_button(
                            label=f"📥 Download Batch Report ({len(selected_scenarios_data)} scenarios)",
                            data=file,
                            file_name=f"batch_report_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf",
                            mime="application/pdf",
                            use_container_width=True
                        )
                    st.success("Batch report generated successfully!")
                    
                except Exception as e:
                    st.error(f"Error generating batch report: {e}")
    
    with col2:
        st.markdown("#### Quick Reports")
        st.write("Generate quick summary reports")
        
        report_format = st.radio(
            "Quick Report Format",
            ["PDF Summary", "CSV Export", "Text Summary"],
            horizontal=True
        )
        
        if st.button("Generate Quick Report", use_container_width=True):
            with st.spinner("Generating quick report..."):
                try:
                    if report_format == "CSV Export":
                        csv_data = generate_scenario_csv(scenarios)
                        st.download_button(
                            label="📥 Download CSV Report",
                            data=csv_data,
                            file_name=f"scenarios_export_{datetime.now().strftime('%Y%m%d')}.csv",
                            mime="text/csv",
                            use_container_width=True
                        )
                    elif report_format == "Text Summary":
                        text_data = generate_text_summary(scenarios)
                        st.download_button(
                            label="📥 Download Text Summary",
                            data=text_data,
                            file_name=f"scenarios_summary_{datetime.now().strftime('%Y%m%d')}.txt",
                            mime="text/plain",
                            use_container_width=True
                        )
                    else:
                        # For PDF, use the comprehensive generator but with fewer scenarios for speed
                        quick_scenarios = scenarios[:3]  # First 3 scenarios for quick report
                        report_path = report_generator.generate_comprehensive_report(quick_scenarios)
                        
                        with open(report_path, "rb") as file:
                            st.download_button(
                                label="📥 Download Quick PDF",
                                data=file,
                                file_name=f"quick_report_{datetime.now().strftime('%Y%m%d')}.pdf",
                                mime="application/pdf",
                                use_container_width=True
                            )
                    st.success("Quick report generated successfully!")
                    
                except Exception as e:
                    st.error(f"Error generating quick report: {e}")
    
    # Report history and management
    st.subheader("Generated Reports History")
    
    reports_dir = "reports"
    if os.path.exists(reports_dir):
        reports = [f for f in os.listdir(reports_dir) if f.endswith('.pdf')]
        reports.sort(key=lambda x: os.path.getctime(os.path.join(reports_dir, x)), reverse=True)
        
        if reports:
            st.write(f"Found {len(reports)} generated reports:")
            
            # Display recent reports
            for i, report in enumerate(reports[:5]):  # Show last 5 reports
                report_path = os.path.join(reports_dir, report)
                report_time = datetime.fromtimestamp(os.path.getctime(report_path))
                
                col1, col2, col3 = st.columns([3, 1, 1])
                
                with col1:
                    st.write(f"**{report}**")
                    st.caption(f"Generated: {report_time.strftime('%Y-%m-%d %H:%M')}")
                
                with col2:
                    with open(report_path, "rb") as file:
                        st.download_button(
                            label="Download",
                            data=file,
                            file_name=report,
                            mime="application/pdf",
                            key=f"dl_{i}"
                        )
                
                with col3:
                    if st.button("Delete", key=f"del_{i}"):
                        try:
                            os.remove(report_path)
                            st.rerun()
                        except Exception as e:
                            st.error(f"Error deleting report: {e}")
            
            # Show total count
            if len(reports) > 5:
                st.info(f"... and {len(reports) - 5} more reports. Check the reports directory for full history.")
        else:
            st.info("No reports generated yet. Use the options above to create your first report.")
    else:
        st.info("Reports directory not found. Generate a report to create the directory.")
    
    # Report statistics
    st.subheader("Reporting Statistics")
    
    if scenarios:
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_scenarios = len(scenarios)
            st.metric("Total Scenarios", total_scenarios)
        
        with col2:
            high_severity = len([s for s in scenarios if s.get('severity') == 'High'])
            st.metric("High Severity", high_severity)
        
        with col3:
            report_count = len(reports) if 'reports' in locals() else 0
            st.metric("Generated Reports", report_count)
        
        with col4:
            latest_scenario = max(scenarios, key=lambda x: x.get('generated_at', ''))
            st.metric("Latest Scenario", latest_scenario['scenario_type'])
    
    # Cleanup options
    st.markdown("---")
    st.subheader("Report Management")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Clear All Generated Reports", use_container_width=True):
            if os.path.exists(reports_dir):
                for file in os.listdir(reports_dir):
                    if file.endswith('.pdf'):
                        os.remove(os.path.join(reports_dir, file))
                st.success("All reports cleared successfully!")
                st.rerun()
    
    with col2:
        if st.button("Open Reports Directory", use_container_width=True):
            if os.path.exists(reports_dir):
                st.info(f"Reports are stored in: {os.path.abspath(reports_dir)}")
            else:
                st.warning("Reports directory does not exist yet.")

def generate_scenario_csv(scenarios):
    """Generate CSV data from scenarios"""
    import io
    
    output = io.StringIO()
    
    # Create flattened data for CSV
    csv_data = []
    for scenario in scenarios:
        row = {
            'scenario_type': scenario['scenario_type'],
            'severity': scenario.get('severity', 'Unknown'),
            'generated_at': scenario.get('generated_at', ''),
            'scenario_overview': scenario.get('scenario_overview', ''),
            'portfolio_impact': scenario.get('portfolio_impact', '')
        }
        
        # Flatten risk metrics
        risk_metrics = scenario.get('risk_metrics', {})
        for key, value in risk_metrics.items():
            row[f'risk_metric_{key}'] = value
        
        csv_data.append(row)
    
    df = pd.DataFrame(csv_data)
    df.to_csv(output, index=False)
    
    return output.getvalue()

def generate_text_summary(scenarios):
    """Generate text summary from scenarios"""
    summary = "RISK SCENARIOS SUMMARY REPORT\n"
    summary += "=" * 40 + "\n\n"
    summary += f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
    summary += f"Total Scenarios: {len(scenarios)}\n\n"
    
    for i, scenario in enumerate(scenarios, 1):
        summary += f"SCENARIO {i}: {scenario['scenario_type']}\n"
        summary += f"Severity: {scenario.get('severity', 'Unknown')}\n"
        summary += f"Overview: {scenario.get('scenario_overview', '')}\n"
        summary += f"Impact: {scenario.get('portfolio_impact', '')}\n"
        
        risk_metrics = scenario.get('risk_metrics', {})
        if risk_metrics:
            summary += "Risk Metrics:\n"
            for metric, value in risk_metrics.items():
                summary += f"  - {metric}: {value}\n"
        
        summary += "\n" + "-" * 30 + "\n\n"
    
    return summary

# Initialize session state if not exists
if 'scenarios' not in st.session_state:
    st.session_state.scenarios = []

report_manager_page()


