import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from utils.config import Config

def historical_analysis_page():
    st.title("Historical Crisis Analysis")
    st.markdown("Analyze past financial crises to inform future risk scenarios and stress testing.")
    
    # Historical crises data
    crises_data = Config.HISTORICAL_CRISES
    
    # Overview section
    st.subheader("Major Historical Financial Crises")
    
    # Convert to DataFrame for better display
    crises_df = pd.DataFrame(crises_data)
    st.dataframe(crises_df, use_container_width=True, hide_index=True)
    
    # Crisis comparison visualization
    st.subheader("Crisis Severity & Impact Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Severity distribution
        severity_counts = crises_df['severity'].value_counts().reset_index()
        severity_counts.columns = ['Severity', 'Count']
        
        fig_severity = px.pie(severity_counts, values='Count', names='Severity',
                             title="Crisis Severity Distribution")
        st.plotly_chart(fig_severity, use_container_width=True)
    
    with col2:
        # Timeline visualization
        fig_timeline = go.Figure()
        
        for crisis in crises_data:
            year = crisis['year']
            severity = crisis['severity']
            
            # Map severity to marker size and color
            size_map = {"High": 20, "Medium": 15, "Low": 10}
            color_map = {"High": "red", "Medium": "orange", "Low": "green"}
            
            fig_timeline.add_trace(go.Scatter(
                x=[year],
                y=[1],
                mode='markers+text',
                marker=dict(
                    size=size_map.get(severity, 12),
                    color=color_map.get(severity, 'gray')
                ),
                name=crisis['name'],
                text=crisis['name'],
                textposition="middle right"
            ))
        
        fig_timeline.update_layout(
            title="Historical Crises Timeline",
            xaxis_title="Year",
            yaxis=dict(showticklabels=False, showgrid=False),
            height=300,
            showlegend=False
        )
        st.plotly_chart(fig_timeline, use_container_width=True)
    
    # Detailed crisis analysis
    st.subheader("Detailed Crisis Analysis")
    
    selected_crisis = st.selectbox(
        "Select Crisis for Detailed Analysis",
        options=[crisis['name'] for crisis in crises_data],
        help="Choose a historical crisis to examine in detail"
    )
    
    if selected_crisis:
        crisis = next((c for c in crises_data if c['name'] == selected_crisis), None)
        
        if crisis:
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### Crisis Details")
                
                # Create a details table
                details_data = {
                    "Attribute": ["Name", "Year", "Severity", "Duration", "Global Impact"],
                    "Value": [
                        crisis['name'],
                        crisis['year'],
                        crisis['severity'],
                        "1-2 years",  # Placeholder
                        "High" if crisis['severity'] == 'High' else "Medium"
                    ]
                }
                
                details_df = pd.DataFrame(details_data)
                st.dataframe(details_df, use_container_width=True, hide_index=True)
                
                # Key statistics
                st.markdown("#### Market Impact Statistics")
                
                stats_data = {
                    "Metric": ["S&P 500 Decline", "VIX Peak", "Recovery Time", "GDP Impact"],
                    "Value": get_crisis_stats(crisis['name'])
                }
                
                stats_df = pd.DataFrame(stats_data)
                st.dataframe(stats_df, use_container_width=True, hide_index=True)
            
            with col2:
                st.markdown("#### Crisis Narrative")
                narrative = get_crisis_narrative(crisis['name'])
                st.write(narrative)
                
                st.markdown("#### Key Triggers & Events")
                triggers = get_crisis_triggers(crisis['name'])
                for trigger in triggers:
                    st.write(f"• {trigger}")
                
                st.markdown("#### Regulatory Response")
                responses = get_regulatory_responses(crisis['name'])
                for response in responses:
                    st.write(f"• {response}")
    
    # Lessons learned section
    st.subheader("Key Risk Management Lessons")
    
    lessons = [
        "Diversification alone cannot prevent systemic risk losses",
        "Liquidity can disappear rapidly during crises",
        "Correlation between asset classes increases during stress periods",
        "Traditional risk models often fail to capture tail risks",
        "Counterparty risk becomes critical during market stress",
        "Regulatory changes often follow major financial crises"
    ]
    
    for i, lesson in enumerate(lessons, 1):
        st.write(f"{i}. {lesson}")
    
    # Comparative analysis
    st.subheader("Comparative Crisis Analysis")
    
    selected_crises = st.multiselect(
        "Compare Multiple Crises",
        options=[crisis['name'] for crisis in crises_data],
        default=[crises_data[0]['name'], crises_data[1]['name']],
        max_selections=3
    )
    
    if len(selected_crises) >= 2:
        comparison_data = []
        
        for crisis_name in selected_crises:
            crisis = next((c for c in crises_data if c['name'] == crisis_name), None)
            if crisis:
                stats = get_crisis_stats(crisis_name)
                comparison_data.append({
                    'Crisis': crisis_name,
                    'Year': crisis['year'],
                    'Severity': crisis['severity'],
                    'Market_Decline': stats[0],
                    'VIX_Peak': stats[1],
                    'Recovery_Time': stats[2]
                })
        
        if comparison_data:
            comparison_df = pd.DataFrame(comparison_data)
            st.dataframe(comparison_df, use_container_width=True, hide_index=True)
            
            # Create comparison chart
            fig_comparison = px.bar(comparison_df, x='Crisis', y='Market_Decline',
                                   color='Severity', title="Market Decline Comparison")
            st.plotly_chart(fig_comparison, use_container_width=True)
    
    # Application to current scenarios
    st.subheader("Applying Historical Lessons")
    
    st.markdown("""
    **How to use historical analysis in current risk management:**
    
    1. **Pattern Recognition**: Identify recurring themes across different crises
    2. **Stress Testing**: Use historical worst-case scenarios as baseline stress tests
    3. **Early Warning**: Monitor for conditions that preceded past crises
    4. **Liquidity Planning**: Ensure adequate liquidity for crisis conditions
    5. **Hedge Effectiveness**: Test hedging strategies against historical scenarios
    """)
    
    # Download historical data
    st.markdown("---")
    if st.button("Download Crisis Analysis Report"):
        # Create a simple report
        report_text = generate_crisis_report(crises_data)
        st.download_button(
            label="Download Historical Analysis",
            data=report_text,
            file_name="historical_crisis_analysis.txt",
            mime="text/plain"
        )

def get_crisis_stats(crisis_name):
    """Get statistics for specific crises"""
    stats_map = {
        "2008 Financial Crisis": ["-57%", "89.53", "4 years", "-4.3%"],
        "2020 COVID-19 Crash": ["-34%", "82.69", "6 months", "-3.4%"],
        "2000 Dot-com Bubble": ["-49%", "48.47", "7 years", "-0.3%"],
        "1987 Black Monday": ["-34%", "150+", "2 years", "+0.2%"],
        "1997 Asian Financial Crisis": ["-60%", "N/A", "3 years", "-2.0%"],
        "2010 European Debt Crisis": ["-21%", "48.00", "2 years", "-0.8%"]
    }
    return stats_map.get(crisis_name, ["N/A", "N/A", "N/A", "N/A"])

def get_crisis_narrative(crisis_name):
    """Get narrative description for crises"""
    narratives = {
        "2008 Financial Crisis": """
        The 2008 Financial Crisis was triggered by the collapse of the subprime mortgage market 
        in the United States, which exposed excessive leverage and risk-taking in the global 
        financial system. The crisis led to the failure of major financial institutions, 
        government bailouts, and a severe global recession.
        """,
        "2020 COVID-19 Crash": """
        The COVID-19 market crash was caused by global economic shutdowns in response to the 
        pandemic. Unlike previous crises, this was a health crisis that triggered economic 
        collapse, with unprecedented fiscal and monetary policy responses worldwide.
        """,
        "2000 Dot-com Bubble": """
        The Dot-com Bubble burst after excessive speculation in internet-related companies 
        with unsustainable business models. The NASDAQ composite lost nearly 80% of its value 
        from peak to trough over two and a half years.
        """
    }
    return narratives.get(crisis_name, "Detailed narrative not available.")

def get_crisis_triggers(crisis_name):
    """Get key triggers for crises"""
    triggers_map = {
        "2008 Financial Crisis": [
            "Subprime mortgage defaults",
            "Lehman Brothers bankruptcy", 
            "Credit market freeze",
            "Over-leveraged financial institutions"
        ],
        "2020 COVID-19 Crash": [
            "Global pandemic declaration",
            "Economic shutdowns",
            "Supply chain disruptions",
            "Oil price war"
        ],
        "2000 Dot-com Bubble": [
            "Excessive tech stock valuations",
            "Internet company failures",
            "Fed interest rate hikes",
            "Y2K-related spending pullback"
        ]
    }
    return triggers_map.get(crisis_name, ["Trigger information not available"])

def get_regulatory_responses(crisis_name):
    """Get regulatory responses to crises"""
    responses_map = {
        "2008 Financial Crisis": [
            "Dodd-Frank Act",
            "Troubled Asset Relief Program (TARP)",
            "Basel III capital requirements",
            "Stress testing requirements"
        ],
        "2020 COVID-19 Crash": [
            "CARES Act stimulus",
            "Federal Reserve emergency lending",
            "Paycheck Protection Program",
            "Enhanced unemployment benefits"
        ]
    }
    return responses_map.get(crisis_name, ["Response information not available"])

def generate_crisis_report(crises_data):
    """Generate a text report of crisis analysis"""
    report = "HISTORICAL FINANCIAL CRISIS ANALYSIS REPORT\n"
    report += "=" * 50 + "\n\n"
    
    for crisis in crises_data:
        report += f"CRISIS: {crisis['name']}\n"
        report += f"Year: {crisis['year']} | Severity: {crisis['severity']}\n"
        report += f"Narrative: {get_crisis_narrative(crisis['name'])}\n"
        report += "Key Triggers:\n"
        for trigger in get_crisis_triggers(crisis['name']):
            report += f"  - {trigger}\n"
        report += "\n" + "-" * 30 + "\n\n"
    
    return report

historical_analysis_page()


