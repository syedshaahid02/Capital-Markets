import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

def portfolio_impact_page():
    st.title("Portfolio Impact Analysis")
    st.markdown("Analyze the potential impact of generated risk scenarios on different portfolio types.")
    
    scenarios = st.session_state.get('scenarios', [])
    
    if not scenarios:
        st.info("No scenarios available for analysis. Please generate scenarios first on the Scenario Generator page.")
        st.markdown("[Go to Scenario Generator](/?page=3_Scenario_Generator)")
        return
    
    # Portfolio configuration
    st.subheader("Portfolio Configuration")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        portfolio_size = st.number_input(
            "Portfolio Value ($)",
            min_value=100000,
            max_value=1000000000,
            value=1000000,
            step=100000,
            help="Total value of the portfolio for impact calculation"
        )
    
    with col2:
        portfolio_type = st.selectbox(
            "Portfolio Type",
            options=["Equity Heavy", "Fixed Income", "Balanced", "Hedge Fund", "Retirement Portfolio"],
            index=2,
            help="Select the portfolio type for impact analysis"
        )
    
    with col3:
        risk_tolerance = st.select_slider(
            "Risk Tolerance",
            options=["Conservative", "Moderate", "Aggressive"],
            value="Moderate",
            help="Investor risk tolerance level"
        )
    
    # Asset allocation based on portfolio type
    st.subheader("Current Asset Allocation")
    
    allocation = get_portfolio_allocation(portfolio_type)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Allocation pie chart
        allocation_df = pd.DataFrame({
            'Asset': list(allocation.keys()),
            'Allocation': list(allocation.values())
        })
        
        fig_pie = px.pie(allocation_df, values='Allocation', names='Asset',
                        title=f"{portfolio_type} - Asset Allocation")
        st.plotly_chart(fig_pie, use_container_width=True)
    
    with col2:
        # Allocation table
        st.dataframe(allocation_df, use_container_width=True, hide_index=True)
        
        # Portfolio metrics
        st.metric("Total Value", f"${portfolio_size:,.2f}")
        st.metric("Number of Scenarios", len(scenarios))
    
    # Impact analysis
    st.subheader("Scenario Impact Analysis")
    
    # Create impact comparison table
    impact_data = []
    for scenario in scenarios:
        impact_metrics = calculate_scenario_impact(scenario, allocation, portfolio_type, portfolio_size)
        impact_data.append({
            'Scenario Type': scenario['scenario_type'],
            'Severity': scenario.get('severity', 'Unknown'),
            'VaR Estimate': scenario.get('risk_metrics', {}).get('var_95', 'N/A'),
            'Expected Shortfall': scenario.get('risk_metrics', {}).get('expected_shortfall', 'N/A'),
            'Estimated Loss': impact_metrics['estimated_loss'],
            'Loss Amount': impact_metrics['dollar_loss'],
            'Recovery Time': impact_metrics['recovery_time']
        })
    
    impact_df = pd.DataFrame(impact_data)
    
    # Display impact table
    st.dataframe(impact_df, use_container_width=True)
    
    # Impact visualization
    st.subheader("Impact Visualization")
    
    tab1, tab2, tab3 = st.tabs(["Loss Analysis", "Severity Distribution", "Recovery Timeline"])
    
    with tab1:
        # Loss Analysis
        if not impact_df.empty:
            # Convert loss amounts to numeric for plotting
            impact_df['Loss_Numeric'] = impact_df['Loss Amount'].apply(
                lambda x: parse_currency_to_float(x)
            )
            
            fig_loss = px.bar(impact_df, x='Scenario Type', y='Loss_Numeric',
                             color='Severity', 
                             title="Estimated Dollar Loss by Scenario",
                             labels={'Loss_Numeric': 'Estimated Loss ($)'})
            st.plotly_chart(fig_loss, use_container_width=True)
    
    with tab2:
        # Severity vs Loss scatter plot
        if not impact_df.empty:
            # Create numeric severity for plotting
            severity_map = {'Low': 1, 'Medium': 2, 'High': 3, 'Unknown': 0}
            impact_df['Severity_Num'] = impact_df['Severity'].map(severity_map)
            
            fig_scatter = px.scatter(impact_df, x='Severity_Num', y='Loss_Numeric',
                                   size='Loss_Numeric', color='Scenario Type',
                                   title="Loss vs Severity Analysis",
                                   labels={'Severity_Num': 'Severity', 'Loss_Numeric': 'Loss Amount'})
            st.plotly_chart(fig_scatter, use_container_width=True)
    
    with tab3:
        # Recovery timeline
        if not impact_df.empty:
            impact_df['Recovery_Numeric'] = impact_df['Recovery Time'].apply(
                lambda x: parse_recovery_time_to_months(x)
            )
            
            fig_recovery = px.bar(impact_df, x='Scenario Type', y='Recovery_Numeric',
                                 color='Severity',
                                 title="Estimated Recovery Time by Scenario",
                                 labels={'Recovery_Numeric': 'Recovery Time (months)'})
            st.plotly_chart(fig_recovery, use_container_width=True)
    
    # Worst-case scenario analysis
    st.subheader("Worst-Case Scenario Analysis")
    
    if not impact_df.empty:
        # Find worst scenarios
        worst_scenarios = impact_df.nlargest(3, 'Loss_Numeric')
        
        for idx, (_, scenario) in enumerate(worst_scenarios.iterrows(), 1):
            with st.expander(f"Worst-Case #{idx}: {scenario['Scenario Type']} - Loss: {scenario['Loss Amount']}"):
                original_scenario = next(
                    (s for s in scenarios 
                     if s['scenario_type'] == scenario['Scenario Type'] 
                     and s.get('severity') == scenario['Severity']),
                    scenarios[0]
                )
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Impact Details:**")
                    st.write(original_scenario.get('portfolio_impact', 'No impact details available.'))
                    
                    st.write("**Risk Metrics:**")
                    risk_metrics = original_scenario.get('risk_metrics', {})
                    for metric, value in risk_metrics.items():
                        st.write(f"- {metric}: {value}")
                
                with col2:
                    st.write("**Mitigation Strategies:**")
                    mitigation = original_scenario.get('mitigation_strategies', [])
                    if isinstance(mitigation, list):
                        for strategy in mitigation:
                            st.write(f"• {strategy}")
                    else:
                        st.write(mitigation)
    
    # Stress testing results
    st.subheader("Stress Testing Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        max_loss = impact_df['Loss_Numeric'].max() if not impact_df.empty else 0
        st.metric("Maximum Loss", f"${max_loss:,.0f}")
    
    with col2:
        avg_loss = impact_df['Loss_Numeric'].mean() if not impact_df.empty else 0
        st.metric("Average Loss", f"${avg_loss:,.0f}")
    
    with col3:
        high_risk_count = len(impact_df[impact_df['Severity'] == 'High'])
        st.metric("High Risk Scenarios", high_risk_count)
    
    with col4:
        portfolio_after_worst = portfolio_size - max_loss
        st.metric("Portfolio After Worst Case", f"${portfolio_after_worst:,.0f}")
    
    # Recommendations
    st.subheader("Risk Management Recommendations")
    
    if not impact_df.empty:
        recommendations = generate_recommendations(impact_df, portfolio_type, risk_tolerance, max_loss, portfolio_size)
        
        for i, rec in enumerate(recommendations, 1):
            st.write(f"{i}. {rec}")
    
    # Export impact analysis
    st.markdown("---")
    if st.button("Export Impact Analysis Report"):
        report_data = generate_impact_report(impact_df, portfolio_size, portfolio_type)
        st.download_button(
            label="Download Impact Analysis",
            data=report_data,
            file_name="portfolio_impact_analysis.txt",
            mime="text/plain"
        )

def get_portfolio_allocation(portfolio_type):
    """Get asset allocation based on portfolio type"""
    allocations = {
        "Equity Heavy": {
            "US Stocks": 70,
            "International Stocks": 20,
            "Bonds": 5,
            "Cash": 3,
            "Alternatives": 2
        },
        "Fixed Income": {
            "Government Bonds": 50,
            "Corporate Bonds": 30,
            "Stocks": 15,
            "Cash": 5
        },
        "Balanced": {
            "US Stocks": 50,
            "International Stocks": 20,
            "Bonds": 25,
            "Cash": 5
        },
        "Hedge Fund": {
            "Equities": 40,
            "Fixed Income": 20,
            "Derivatives": 25,
            "Alternatives": 10,
            "Cash": 5
        },
        "Retirement Portfolio": {
            "Stocks": 60,
            "Bonds": 30,
            "Real Estate": 5,
            "Cash": 5
        }
    }
    return allocations.get(portfolio_type, allocations["Balanced"])

def calculate_scenario_impact(scenario, allocation, portfolio_type, portfolio_size):
    """Calculate financial impact of a scenario"""
    # Extract VaR from risk metrics or estimate based on severity
    risk_metrics = scenario.get('risk_metrics', {})
    var_estimate = risk_metrics.get('var_95', '15-25%')
    
    # Parse VaR estimate
    if '-' in str(var_estimate):
        try:
            var_low, var_high = map(float, str(var_estimate).replace('%', '').split('-'))
            var_avg = (var_low + var_high) / 2
        except:
            var_avg = 20  # Default 20%
    else:
        var_avg = 20  # Default 20%
    
    # Adjust based on severity
    severity_multiplier = {
        'High': 1.2,
        'Medium': 1.0,
        'Low': 0.8,
        'Unknown': 1.0
    }.get(scenario.get('severity', 'Unknown'), 1.0)
    
    # Adjust based on portfolio type vulnerability
    portfolio_vulnerability = {
        'Equity Heavy': 1.3,
        'Fixed Income': 0.8,
        'Balanced': 1.0,
        'Hedge Fund': 1.1,
        'Retirement Portfolio': 1.0
    }.get(portfolio_type, 1.0)
    
    estimated_loss_pct = var_avg * severity_multiplier * portfolio_vulnerability
    dollar_loss = portfolio_size * (estimated_loss_pct / 100)
    
    # Estimate recovery time
    recovery_time = {
        'High': '12-24 months',
        'Medium': '6-12 months', 
        'Low': '3-6 months',
        'Unknown': '6-12 months'
    }.get(scenario.get('severity', 'Unknown'), '6-12 months')
    
    return {
        'estimated_loss': f"{estimated_loss_pct:.1f}%",
        'dollar_loss': f"${dollar_loss:,.0f}",
        'recovery_time': recovery_time
    }

def parse_currency_to_float(currency_str):
    """Convert currency string to float"""
    if currency_str == 'N/A':
        return 0.0
    try:
        # Remove $ and commas, then convert to float
        return float(str(currency_str).replace('$', '').replace(',', ''))
    except:
        return 0.0

def parse_recovery_time_to_months(recovery_str):
    """Convert recovery time string to numeric months"""
    if recovery_str == 'N/A':
        return 0.0
    
    try:
        if '-' in recovery_str:
            # Handle ranges like "6-12 months"
            parts = recovery_str.split('-')
            if len(parts) == 2:
                low = float(parts[0].strip())
                high = float(parts[1].split()[0].strip())  # Get first number before space
                return (low + high) / 2  # Return average
            else:
                return 0.0
        else:
            # Handle single values like "12 months"
            return float(recovery_str.split()[0].strip())
    except:
        return 0.0

def generate_recommendations(impact_df, portfolio_type, risk_tolerance, max_loss, portfolio_size):
    """Generate risk management recommendations"""
    recommendations = []
    
    max_loss_pct = (max_loss / portfolio_size) * 100 if portfolio_size > 0 else 0
    high_risk_count = len(impact_df[impact_df['Severity'] == 'High'])
    
    if max_loss_pct > 30:  # More than 30% loss
        recommendations.append("Consider implementing protective puts or collar strategies to limit downside risk.")
    
    if high_risk_count >= 3:
        recommendations.append("Diversify into non-correlated assets to reduce concentration risk.")
    
    if portfolio_type == "Equity Heavy" and risk_tolerance == "Conservative":
        recommendations.append("Reduce equity exposure and increase fixed income allocation for better risk-adjusted returns.")
    
    if max_loss_pct > 20:
        recommendations.append("Maintain adequate cash reserves (15-20%) for liquidity during market stress.")
    else:
        recommendations.append("Maintain adequate cash reserves (10-15%) for liquidity during market stress.")
    
    recommendations.append("Regularly rebalance portfolio to maintain target asset allocation.")
    recommendations.append("Consider tail risk hedging strategies for extreme market events.")
    recommendations.append("Review and stress test portfolio quarterly against new risk scenarios.")
    
    return recommendations

def generate_impact_report(impact_df, portfolio_size, portfolio_type):
    """Generate a text report of impact analysis"""
    report = "PORTFOLIO IMPACT ANALYSIS REPORT\n"
    report += "=" * 40 + "\n\n"
    report += f"Portfolio Type: {portfolio_type}\n"
    report += f"Portfolio Value: ${portfolio_size:,.2f}\n"
    report += f"Analysis Date: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}\n\n"
    
    report += "SCENARIO IMPACTS:\n"
    report += "-" * 30 + "\n"
    
    for _, row in impact_df.iterrows():
        report += f"\nScenario: {row['Scenario Type']}\n"
        report += f"Severity: {row['Severity']}\n"
        report += f"Estimated Loss: {row['Estimated Loss']} ({row['Loss Amount']})\n"
        report += f"Recovery Time: {row['Recovery Time']}\n"
    
    # Add summary
    max_loss = impact_df['Loss_Numeric'].max() if 'Loss_Numeric' in impact_df.columns else 0
    avg_loss = impact_df['Loss_Numeric'].mean() if 'Loss_Numeric' in impact_df.columns else 0
    
    report += f"\nSUMMARY:\n"
    report += f"Maximum Potential Loss: ${max_loss:,.0f}\n"
    report += f"Average Potential Loss: ${avg_loss:,.0f}\n"
    report += f"Worst-case Portfolio Value: ${portfolio_size - max_loss:,.0f}\n"
    
    return report

# Initialize session state if not exists
if 'scenarios' not in st.session_state:
    st.session_state.scenarios = []

portfolio_impact_page()

