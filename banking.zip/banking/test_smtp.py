import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from decouple import config

def test_email_connection():
    """Test SMTP connection with current .env settings"""
    print("🔧 Testing SMTP Configuration...")
    
    smtp_server = config('SMTP_SERVER', default='')
    smtp_port = config('SMTP_PORT', default=587, cast=int)
    smtp_username = config('SMTP_USERNAME', default='')
    smtp_password = config('SMTP_PASSWORD', default='')
    from_email = config('FROM_EMAIL', default='')
    
    print(f"SMTP Server: {smtp_server}:{smtp_port}")
    print(f"Username: {smtp_username}")
    print(f"Password: {'*' * len(smtp_password) if smtp_password else 'Not set'}")
    print(f"From Email: {from_email}")
    
    if not all([smtp_server, smtp_username, smtp_password]):
        print("❌ SMTP credentials incomplete in .env file")
        return False
    
    try:
        # Create test email
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "KYC System - Test Email"
        msg['From'] = from_email
        msg['To'] = "test@example.com"
        
        text = "This is a test email from KYC System."
        html = """
        <html>
        <body>
            <h2>KYC System Test Email</h2>
            <p>This is a test email to verify SMTP configuration.</p>
            <p>If you receive this, email notifications are working correctly!</p>
        </body>
        </html>
        """
        
        part1 = MIMEText(text, 'plain')
        part2 = MIMEText(html, 'html')
        msg.attach(part1)
        msg.attach(part2)
        
        # Connect and send
        print("\n🔄 Connecting to SMTP server...")
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_username, smtp_password)
            server.send_message(msg)
        
        print("✅ Test email sent successfully!")
        print("\n📧 Check your email inbox (or Mailtrap dashboard)")
        return True
        
    except Exception as e:
        print(f"❌ SMTP Error: {e}")
        
        # Provide debugging help
        print("\n🔍 Troubleshooting Tips:")
        print("1. Check if SMTP credentials are correct")
        print("2. For Gmail: Enable 'Less secure app access' or use App Password")
        print("3. For Mailtrap: Verify credentials at https://mailtrap.io")
        print("4. Check firewall/network settings")
        print("5. Try using Mailtrap for testing (free signup)")
        
        return False

if __name__ == "__main__":
    test_email_connection()