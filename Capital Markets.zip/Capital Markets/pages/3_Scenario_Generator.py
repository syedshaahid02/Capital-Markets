import streamlit as st
from backend.scenario_agent import ScenarioAgent
from utils.config import Config

def scenario_generator_page():
    st.title("AI Risk Scenario Generator")
    st.markdown("Generate plausible market risk scenarios using AI for stress testing and risk assessment.")
    
    # Initialize scenario agent
    scenario_agent = ScenarioAgent()
    
    # Scenario configuration
    st.subheader("Scenario Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        selected_scenarios = st.multiselect(
            "Select Scenario Types",
            options=Config.SCENARIO_TYPES,
            default=Config.SCENARIO_TYPES[:2],
            help="Choose the types of risk scenarios to generate"
        )
        
        portfolio_type = st.selectbox(
            "Portfolio Type",
            options=Config.PORTFOLIO_TYPES,
            index=2,  # Default to Balanced
            help="Select the type of portfolio for impact analysis"
        )
    
    with col2:
        scenario_count = st.slider(
            "Scenarios per Type",
            min_value=1,
            max_value=5,
            value=2,
            help="Number of variations to generate for each scenario type"
        )
        
        include_historical = st.checkbox(
            "Include Historical Context",
            value=True,
            help="Reference historical crisis events in scenario generation"
        )
        
        detail_level = st.select_slider(
            "Detail Level",
            options=["Basic", "Detailed", "Comprehensive"],
            value="Detailed",
            help="Level of detail in generated scenarios"
        )
    
    # Advanced options
    with st.expander("Advanced Options"):
        col1, col2 = st.columns(2)
        
        with col1:
            severity_focus = st.selectbox(
                "Severity Focus",
                ["All Levels", "High Severity", "Medium+ High", "Stress Test"],
                help="Focus scenario generation on specific severity levels"
            )
            
            time_horizon = st.selectbox(
                "Time Horizon",
                ["Short-term (1-3 months)", "Medium-term (3-12 months)", "Long-term (1+ years)"],
                index=1
            )
        
        with col2:
            region_focus = st.multiselect(
                "Regional Focus",
                ["Global", "North America", "Europe", "Asia", "Emerging Markets"],
                default=["Global"]
            )
            
            correlation_assumption = st.selectbox(
                "Correlation Assumption",
                ["Normal", "Crisis (Increased)", "Decoupled", "Historical Average"]
            )
    
    # Generate scenarios button
    st.markdown("---")
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        if st.button("🚀 Generate Risk Scenarios", type="primary", use_container_width=True):
            if not selected_scenarios:
                st.error("Please select at least one scenario type.")
                return
            
            with st.spinner("Generating AI-powered risk scenarios... This may take a few moments."):
                try:
                    new_scenarios = scenario_agent.generate_multiple_scenarios(
                        selected_scenarios,
                        portfolio_type,
                        scenario_count
                    )
                    
                    # Store in session state
                    if 'scenarios' not in st.session_state:
                        st.session_state.scenarios = []
                    
                    st.session_state.scenarios.extend(new_scenarios)
                    st.success(f"Successfully generated {len(new_scenarios)} scenarios!")
                    
                    # Show generation summary
                    st.balloons()
                    
                except Exception as e:
                    st.error(f"Error generating scenarios: {str(e)}")
                    st.info("Please ensure Ollama is running with the deepseek-r1:latest model")
    
    # Display generated scenarios
    scenarios = st.session_state.get('scenarios', [])
    if scenarios:
        st.subheader(f"Generated Scenarios ({len(scenarios)} total)")
        
        # Filter and search options
        col1, col2 = st.columns(2)
        
        with col1:
            filter_severity = st.multiselect(
                "Filter by Severity",
                options=["High", "Medium", "Low"],
                default=["High", "Medium", "Low"]
            )
        
        with col2:
            filter_type = st.multiselect(
                "Filter by Type",
                options=Config.SCENARIO_TYPES,
                default=Config.SCENARIO_TYPES
            )
        
        # Apply filters
        filtered_scenarios = [
            s for s in scenarios 
            if s.get('severity', 'Unknown') in filter_severity 
            and s['scenario_type'] in filter_type
        ]
        
        if not filtered_scenarios:
            st.warning("No scenarios match the selected filters.")
            return
        
        # Display scenarios
        for i, scenario in enumerate(filtered_scenarios[-len(selected_scenarios)*scenario_count:]):
            # Color code based on severity
            severity_color = {
                "High": "red",
                "Medium": "orange", 
                "Low": "green"
            }.get(scenario.get('severity', 'Unknown'), 'gray')
            
            with st.expander(
                f"**{scenario['scenario_type']}** - "
                f":{severity_color}[**{scenario.get('severity', 'Unknown')} Severity**] - "
                f"{scenario.get('generated_at', '')}"
            ):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("#### 📋 Overview")
                    st.write(scenario.get('scenario_overview', 'No overview provided.'))
                    
                    st.markdown("#### 🌍 Market Context")
                    st.write(scenario.get('market_context', 'No market context provided.'))
                    
                    st.markdown("#### ⏰ Timeline")
                    st.write(scenario.get('timeline', 'No timeline provided.'))
                
                with col2:
                    st.markdown("#### 💼 Portfolio Impact")
                    st.write(scenario.get('portfolio_impact', 'No impact analysis provided.'))
                    
                    st.markdown("#### 📊 Risk Metrics")
                    risk_metrics = scenario.get('risk_metrics', {})
                    if risk_metrics:
                        for metric, value in risk_metrics.items():
                            st.write(f"**{metric}:** {value}")
                    else:
                        st.write("No risk metrics provided.")
                    
                    st.markdown("#### 🛡️ Mitigation Strategies")
                    mitigation = scenario.get('mitigation_strategies', [])
                    if isinstance(mitigation, list):
                        for strategy in mitigation:
                            st.write(f"• {strategy}")
                    else:
                        st.write(mitigation)
                
                # Monitoring indicators
                st.markdown("#### 🔍 Key Monitoring Indicators")
                monitoring = scenario.get('monitoring_indicators', [])
                if isinstance(monitoring, list):
                    cols = st.columns(3)
                    for idx, indicator in enumerate(monitoring):
                        cols[idx % 3].write(f"• {indicator}")
                else:
                    st.write(monitoring)
    
    else:
        st.info(
            "No scenarios generated yet. Configure your scenario parameters above and click "
            "'Generate Risk Scenarios' to create your first AI-powered risk analysis."
        )
    
    # Quick actions footer
    st.markdown("---")
    st.subheader("Quick Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Clear All Scenarios", use_container_width=True):
            st.session_state.scenarios = []
            st.rerun()
    
    with col2:
        if st.button("Export to PDF", use_container_width=True):
            if scenarios:
                st.switch_page("pages/6_Report_Manager.py")
            else:
                st.warning("No scenarios to export.")
    
    with col3:
        if st.button("Back to Dashboard", use_container_width=True):
            st.switch_page("pages/1_Dashboard.py")

# Initialize session state if not exists
if 'scenarios' not in st.session_state:
    st.session_state.scenarios = []

scenario_generator_page()

