# Capital Markets — AI Risk Scenario Generator

This project is a Streamlit application that generates AI-powered risk scenarios and reports.

Key pieces:
- `app.py` — Streamlit UI and page routing
- `backend/` — data fetcher, scenario agent, report generator, and LLM integration
- `utils/config.py` — configuration (model name, base URL, API key placeholder)

Quick start
1. Create a Python venv and install dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Set required environment variables (do not commit keys):

```powershell
# $env:OPENAI_API_BASE = "https://genailab.tcs.in"
# $env:OPENAI_API_KEY = "sk-..."    # set your token without extra spaces
# If your proxy requires a separate verification token/header, set these:
# $env:LITELLM_VERIFY_TOKEN = "<verification-token>"
# $env:LITELLM_VERIFY_HEADER = "X-LiteLLM-Verification"
```

3. Run the app:

```powershell
python -m streamlit run app.py
```

Security notes
- Do NOT hard-code API keys in source. Use environment variables or a secrets manager.
- If the internal endpoint uses a private CA, install the CA into the OS trust store rather than disabling TLS verification.

Diagnostics
- There are helper scripts `test.py` / `test1.py` used for diagnosing connectivity and auth with the LLM proxy. These may output sensitive info; run them only locally.

License
- (Add license or project ownership details here)
