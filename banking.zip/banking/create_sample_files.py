from PIL import Image, ImageDraw, ImageFont
import os

def create_id_proof():
    """Create a sample ID proof image"""
    # Create a blank image
    img = Image.new('RGB', (800, 600), color='white')
    draw = ImageDraw.Draw(img)
    
    # Draw border
    draw.rectangle([10, 10, 790, 590], outline='blue', width=3)
    
    # Add text
    text_lines = [
        "GOVERNMENT OF INDIA",
        "AADHAAR CARD",
        "",
        "Name: JOHN DOE",
        "Aadhaar No: 1234-5678-9012",
        "Date of Birth: 15-06-1990",
        "Gender: Male",
        "",
        "Address: 123 Main Street",
        "       Mumbai, Maharashtra 400001",
        "",
        "Issued by: UIDAI",
        "Issue Date: 01-01-2020"
    ]
    
    y = 50
    for line in text_lines:
        draw.text((50, y), line, fill='black')
        y += 40
    
    # Save the image
    os.makedirs('sample_docs', exist_ok=True)
    img.save('sample_docs/id_proof_sample.jpg')
    print("✅ Created: sample_docs/id_proof_sample.jpg")
    return 'sample_docs/id_proof_sample.jpg'

def create_address_proof():
    """Create a sample address proof image"""
    # Create a blank image
    img = Image.new('RGB', (800, 600), color='white')
    draw = ImageDraw.Draw(img)
    
    # Draw border
    draw.rectangle([10, 10, 790, 590], outline='green', width=3)
    
    # Add text
    text_lines = [
        "MAHARASHTRA STATE ELECTRICITY BOARD",
        "ELECTRICITY BILL",
        "",
        "Consumer Name: JOHN DOE",
        "Consumer No: ELEC-2024-12345",
        "Billing Period: 01-11-2024 to 30-11-2024",
        "",
        "Service Address:",
        "123 Main Street, Apartment 5B",
        "Andheri East, Mumbai",
        "Maharashtra - 400001",
        "",
        "Total Amount: ₹1,248.00",
        "Due Date: 15-12-2024",
        "Bill Date: 01-12-2024"
    ]
    
    y = 50
    for line in text_lines:
        draw.text((50, y), line, fill='black')
        y += 40
    
    # Save the image
    os.makedirs('sample_docs', exist_ok=True)
    img.save('sample_docs/address_proof_sample.jpg')
    print("✅ Created: sample_docs/address_proof_sample.jpg")
    return 'sample_docs/address_proof_sample.jpg'

def create_photo():
    """Create a sample passport photo"""
    # Create a blank image
    img = Image.new('RGB', (400, 500), color='white')
    draw = ImageDraw.Draw(img)
    
    # Draw photo frame
    draw.rectangle([50, 50, 350, 300], outline='black', width=2, fill='lightblue')
    
    # Draw face
    draw.ellipse([150, 100, 250, 200], fill='beige', outline='black')
    
    # Draw eyes
    draw.ellipse([180, 130, 190, 140], fill='black')  # Left eye
    draw.ellipse([210, 130, 220, 140], fill='black')  # Right eye
    
    # Draw smile
    draw.arc([180, 160, 220, 180], start=0, end=180, fill='red', width=3)
    
    # Add text
    draw.text((100, 320), "PASSPORT PHOTOGRAPH", fill='black')
    draw.text((120, 360), "JOHN DOE", fill='black')
    draw.text((100, 400), "Date: December 2024", fill='black')
    
    # Save the image
    os.makedirs('sample_docs', exist_ok=True)
    img.save('sample_docs/photo_sample.jpg')
    print("✅ Created: sample_docs/photo_sample.jpg")
    return 'sample_docs/photo_sample.jpg'

def create_pdf_document():
    """Create a sample PDF document"""
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
        
        os.makedirs('sample_docs', exist_ok=True)
        pdf_path = 'sample_docs/bank_statement_sample.pdf'
        
        c = canvas.Canvas(pdf_path, pagesize=letter)
        width, height = letter
        
        # Title
        c.setFont("Helvetica-Bold", 16)
        c.drawString(100, height - 100, "BANK STATEMENT")
        
        # Bank details
        c.setFont("Helvetica", 12)
        c.drawString(100, height - 150, "Bank: State Bank of India")
        c.drawString(100, height - 180, "Account Holder: JOHN DOE")
        c.drawString(100, height - 210, "Account No: 123456789012")
        c.drawString(100, height - 240, "Statement Period: 01-11-2024 to 30-11-2024")
        
        # Address
        c.drawString(100, height - 280, "Address:")
        c.drawString(120, height - 300, "123 Main Street, Apartment 5B")
        c.drawString(120, height - 320, "Andheri East, Mumbai - 400001")
        
        # Transactions
        c.drawString(100, height - 380, "Recent Transactions:")
        c.drawString(120, height - 410, "15-11-2024: Salary Credit - ₹50,000.00")
        c.drawString(120, height - 430, "20-11-2024: ATM Withdrawal - ₹5,000.00")
        c.drawString(120, height - 450, "25-11-2024: Online Payment - ₹2,500.00")
        
        # Footer
        c.setFont("Helvetica-Oblique", 10)
        c.drawString(100, 100, "This is a computer generated statement.")
        c.drawString(100, 80, "Date: 01-12-2024")
        
        c.save()
        print("✅ Created: sample_docs/bank_statement_sample.pdf")
        return pdf_path
        
    except ImportError:
        print("⚠️ ReportLab not installed. Creating text file instead.")
        # Create a text file as fallback
        text_content = """BANK STATEMENT
Bank: State Bank of India
Account Holder: JOHN DOE
Account No: 123456789012
Statement Period: 01-11-2024 to 30-11-2024

Address:
123 Main Street, Apartment 5B
Andheri East, Mumbai - 400001

Recent Transactions:
15-11-2024: Salary Credit - ₹50,000.00
20-11-2024: ATM Withdrawal - ₹5,000.00
25-11-2024: Online Payment - ₹2,500.00

This is a computer generated statement.
Date: 01-12-2024"""
        
        os.makedirs('sample_docs', exist_ok=True)
        txt_path = 'sample_docs/bank_statement_sample.txt'
        with open(txt_path, 'w') as f:
            f.write(text_content)
        print(f"✅ Created: {txt_path} (rename to .pdf for testing)")
        return txt_path

def main():
    """Create all sample documents"""
    print("📄 Creating sample KYC documents...")
    
    # Create images
    id_proof = create_id_proof()
    address_proof = create_address_proof()
    photo = create_photo()
    pdf_doc = create_pdf_document()
    
    print("\n🎯 Sample documents created in 'sample_docs' folder:")
    print(f"1. ID Proof: {id_proof}")
    print(f"2. Address Proof: {address_proof}")
    print(f"3. Photo: {photo}")
    print(f"4. PDF Document: {pdf_doc}")
    
    print("\n📋 Use these files for testing:")
    print("- For 'ID Proof': Use id_proof_sample.jpg")
    print("- For 'Address Proof': Use address_proof_sample.jpg or bank_statement_sample.pdf")
    print("- For 'Photo': Use photo_sample.jpg")

if __name__ == "__main__":
    main()