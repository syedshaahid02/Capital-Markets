import streamlit as st
import sqlite3
import json
import hashlib
import datetime
import os
import uuid
from enum import Enum
import pandas as pd
import numpy as np
from PIL import Image
import io
import pytesseract
import pymupdf  # PyMuPDF
import cv2
import re
from dataclasses import dataclass, asdict
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any, Optional
from tqdm import tqdm

# ============= AI CONNECTION =============
from langchain_openai import ChatOpenAI
import httpx 
import os

# Configure AI client
client = httpx.Client(verify=False)
llm = ChatOpenAI(
    base_url='https://genailab.tcs.in',
    model='azure_ai/genailab-maas-DeepSeek-V3-0324',
    api_key='sk-J-1Za6zC1-ak3xnF0PfFRw',  # Add your API key here
    http_client=client,
    temperature=0.3,
    max_tokens=2000
)

# ============= CHROMADB CONFIGURATION =============
CHROMA_DB_PATH = "chroma_db"
COLLECTION_NAME = "kyc_documents"

# ============= CONFIGURATION =============
class Config:
    # ⚠️ ADD YOUR API KEY BELOW
    AI_API_KEY = "YOUR_API_KEY_HERE"  # Your API key here
    DB_PATH = "kyc_database.db"
    UPLOAD_FOLDER = "uploads"
    CHROMA_DB_PATH = "chroma_db"
    ALLOWED_EXTENSIONS = {'.pdf', '.jpg', '.jpeg', '.png'}
    
    # Document requirements
    DOCUMENT_REQUIREMENTS = {
        "ID Proof": ["Passport", "Driver's License", "National ID"],
        "Address Proof": ["Utility Bill", "Bank Statement", "Rental Agreement"],
        "Photograph": ["Passport Photo", "Selfie"]
    }

# ============= CHROMADB MANAGER =============
class ChromaDBManager:
    def __init__(self, persist_directory: str = CHROMA_DB_PATH):
        self.persist_directory = persist_directory
        os.makedirs(persist_directory, exist_ok=True)
        
        # Initialize ChromaDB client
        self.client = chromadb.PersistentClient(
            path=persist_directory,
            settings=Settings(anonymized_telemetry=False)
        )
        
        # Initialize embedding model
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Create or get collection
        try:
            self.collection = self.client.get_or_create_collection(
                name=COLLECTION_NAME,
                metadata={"hnsw:space": "cosine"}
            )
        except Exception as e:
            st.error(f"ChromaDB initialization error: {str(e)}")
            self.collection = None
    
    def get_embedding(self, text: str) -> List[float]:
        """Generate embedding for text"""
        if not text or text.strip() == "":
            return [0.0] * 384  # Return zero vector for empty text
        
        try:
            embedding = self.embedding_model.encode(text).tolist()
            return embedding
        except Exception as e:
            st.warning(f"Embedding generation failed: {str(e)}")
            return [0.0] * 384
    
    def add_document(self, 
                    document_id: str,
                    customer_id: str,
                    document_type: str,
                    extracted_text: str,
                    metadata: Dict[str, Any]) -> bool:
        """Add document to ChromaDB"""
        try:
            if not self.collection:
                return False
            
            # Generate embedding
            embedding = self.get_embedding(extracted_text)
            
            # Prepare metadata
            full_metadata = {
                "customer_id": customer_id,
                "document_type": document_type,
                "document_id": document_id,
                "upload_timestamp": datetime.datetime.now().isoformat(),
                **metadata
            }
            
            # Add to collection
            self.collection.add(
                ids=[document_id],
                embeddings=[embedding],
                metadatas=[full_metadata],
                documents=[extracted_text[:10000]]  # Limit text length
            )
            
            return True
        except Exception as e:
            st.error(f"ChromaDB add error: {str(e)}")
            return False
    
    def search_similar_documents(self, 
                                query_text: str, 
                                customer_id: str = None,
                                n_results: int = 5) -> List[Dict]:
        """Search for similar documents"""
        try:
            if not self.collection:
                return []
            
            # Generate query embedding
            query_embedding = self.get_embedding(query_text)
            
            # Prepare where filter
            where_filter = {}
            if customer_id:
                where_filter = {"customer_id": customer_id}
            
            # Search in collection
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=n_results,
                where=where_filter if where_filter else None,
                include=["metadatas", "documents", "distances"]
            )
            
            # Format results
            formatted_results = []
            if results['ids'] and len(results['ids'][0]) > 0:
                for i in range(len(results['ids'][0])):
                    formatted_results.append({
                        "document_id": results['ids'][0][i],
                        "metadata": results['metadatas'][0][i],
                        "text": results['documents'][0][i],
                        "similarity_score": 1 - results['distances'][0][i],
                        "customer_id": results['metadatas'][0][i].get('customer_id', 'unknown')
                    })
            
            return formatted_results
        except Exception as e:
            st.error(f"ChromaDB search error: {str(e)}")
            return []
    
    def get_customer_documents(self, customer_id: str) -> List[Dict]:
        """Get all documents for a customer"""
        try:
            if not self.collection:
                return []
            
            results = self.collection.get(
                where={"customer_id": customer_id},
                include=["metadatas", "documents"]
            )
            
            documents = []
            if results['ids']:
                for i in range(len(results['ids'])):
                    documents.append({
                        "document_id": results['ids'][i],
                        "metadata": results['metadatas'][i],
                        "text": results['documents'][i] if results['documents'] else ""
                    })
            
            return documents
        except Exception as e:
            st.error(f"ChromaDB get error: {str(e)}")
            return []
    
    def analyze_document_patterns(self, customer_id: str = None) -> Dict:
        """Analyze document patterns using vector search"""
        try:
            if not self.collection:
                return {"error": "ChromaDB not initialized"}
            
            # Get all documents or customer-specific documents
            where_filter = {"customer_id": customer_id} if customer_id else None
            
            results = self.collection.get(
                where=where_filter,
                include=["metadatas", "documents"]
            )
            
            if not results['ids']:
                return {"message": "No documents found", "count": 0}
            
            # Analyze document types
            doc_types = {}
            for meta in results['metadatas']:
                doc_type = meta.get('document_type', 'unknown')
                doc_types[doc_type] = doc_types.get(doc_type, 0) + 1
            
            # Find common patterns using embeddings
            patterns = []
            if len(results['ids']) > 1:
                # Sample analysis - in production, use more sophisticated pattern detection
                sample_texts = []
                for i, doc in enumerate(results['documents']):
                    if doc and len(doc) > 100:
                        sample_texts.append(doc[:500])
                
                if sample_texts:
                    # Use AI to analyze patterns
                    analysis_prompt = f"""
                    Analyze these document texts and identify patterns or anomalies:
                    
                    Documents: {json.dumps(sample_texts[:3], indent=2)}
                    
                    Provide analysis in JSON format with:
                    1. common_patterns
                    2. potential_anomalies
                    3. consistency_score (0-1)
                    4. recommendations
                    """
                    
                    try:
                        response = llm.invoke(analysis_prompt)
                        ai_analysis = json.loads(response.content)
                        patterns.append(ai_analysis)
                    except:
                        pass
            
            return {
                "total_documents": len(results['ids']),
                "document_types": doc_types,
                "patterns": patterns,
                "customer_id": customer_id
            }
            
        except Exception as e:
            return {"error": str(e)}
    
    def delete_document(self, document_id: str) -> bool:
        """Delete document from ChromaDB"""
        try:
            if not self.collection:
                return False
            
            self.collection.delete(ids=[document_id])
            return True
        except Exception as e:
            st.error(f"ChromaDB delete error: {str(e)}")
            return False
    
    def get_collection_stats(self) -> Dict:
        """Get ChromaDB collection statistics"""
        try:
            if not self.collection:
                return {"status": "not_initialized"}
            
            count = self.collection.count()
            metadata = self.collection.metadata or {}
            
            return {
                "status": "active",
                "document_count": count,
                "collection_name": COLLECTION_NAME,
                "persist_directory": self.persist_directory,
                "metadata": metadata
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

# ============= DATABASE MODELS =============
class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self.init_database()
        self.chroma_db = ChromaDBManager()
    
    def init_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Customers table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS customers (
                customer_id TEXT PRIMARY KEY,
                full_name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                phone TEXT NOT NULL,
                date_of_birth TEXT,
                nationality TEXT,
                registration_date TEXT,
                kyc_status TEXT DEFAULT 'PENDING',
                created_at TEXT
            )
        ''')
        
        # Documents table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                document_id TEXT PRIMARY KEY,
                customer_id TEXT,
                document_type TEXT NOT NULL,
                file_name TEXT,
                file_path TEXT,
                file_size INTEGER,
                file_hash TEXT,
                upload_timestamp TEXT,
                verification_status TEXT DEFAULT 'PENDING',
                ai_confidence REAL DEFAULT 0.0,
                extracted_data TEXT,
                verified_by TEXT,
                verification_date TEXT,
                rejection_reason TEXT,
                chroma_stored INTEGER DEFAULT 0,
                FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
            )
        ''')
        
        # Audit log table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_log (
                log_id TEXT PRIMARY KEY,
                customer_id TEXT,
                user_id TEXT,
                action TEXT,
                action_details TEXT,
                timestamp TEXT,
                ip_address TEXT,
                user_agent TEXT,
                status TEXT
            )
        ''')
        
        # KYC Process table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS kyc_process (
                process_id TEXT PRIMARY KEY,
                customer_id TEXT,
                current_step TEXT,
                completed_steps TEXT,
                pending_steps TEXT,
                overall_status TEXT,
                last_updated TEXT,
                start_date TEXT,
                estimated_completion TEXT
            )
        ''')
        
        # Document embeddings metadata table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS document_embeddings (
                embedding_id TEXT PRIMARY KEY,
                document_id TEXT,
                customer_id TEXT,
                embedding_model TEXT,
                embedding_size INTEGER,
                created_at TEXT,
                FOREIGN KEY (document_id) REFERENCES documents(document_id)
            )
        ''')
        
        # Insert default rules if not exists
        default_rules = [
            ('RULE001', 'ID Document Validation', 'ID Proof', 
             '{"required_fields": ["name", "id_number", "date_of_birth"], "format_checks": ["clear_image", "valid_dates"]}', 
             0.75, 1, datetime.datetime.now().isoformat()),
            ('RULE002', 'Address Proof Validation', 'Address Proof',
             '{"required_fields": ["name", "address", "date"], "format_checks": ["recent_document", "complete_address"]}',
             0.65, 1, datetime.datetime.now().isoformat()),
            ('RULE003', 'Photo Validation', 'Photograph',
             '{"required_fields": ["face_present", "clear_image"], "format_checks": ["good_lighting", "front_view"]}',
             0.6, 1, datetime.datetime.now().isoformat())
        ]
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS verification_rules (
                rule_id TEXT PRIMARY KEY,
                rule_name TEXT,
                document_type TEXT,
                validation_criteria TEXT,
                min_confidence REAL DEFAULT 0.7,
                is_active INTEGER DEFAULT 1,
                created_at TEXT
            )
        ''')
        
        for rule in default_rules:
            cursor.execute('''
                INSERT OR IGNORE INTO verification_rules 
                (rule_id, rule_name, document_type, validation_criteria, min_confidence, is_active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', rule)
        
        conn.commit()
        conn.close()
    
    def register_customer(self, customer_data):
        customer_id = f"CUST{str(uuid.uuid4())[:8].upper()}"
        timestamp = datetime.datetime.now().isoformat()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO customers 
            (customer_id, full_name, email, phone, date_of_birth, 
             nationality, registration_date, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (customer_id, customer_data['full_name'], customer_data['email'],
              customer_data['phone'], customer_data['date_of_birth'],
              customer_data['nationality'], timestamp, timestamp))
        
        # Initialize KYC process
        cursor.execute('''
            INSERT INTO kyc_process 
            (process_id, customer_id, current_step, completed_steps,
             pending_steps, overall_status, last_updated, start_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (f"PROC{str(uuid.uuid4())[:8].upper()}", customer_id, 
              "REGISTRATION", "REGISTRATION", "DOCUMENT_UPLOAD,VERIFICATION,APPROVAL",
              "IN_PROGRESS", timestamp, timestamp))
        
        conn.commit()
        conn.close()
        
        # Log the action
        self.log_audit(customer_id, "CUSTOMER_REGISTRATION", 
                      f"New customer registered: {customer_data['full_name']}")
        
        return customer_id
    
    def upload_document(self, customer_id, document_type, file_data, file_name, extracted_text=""):
        document_id = f"DOC{str(uuid.uuid4())[:8].upper()}"
        timestamp = datetime.datetime.now().isoformat()
        file_hash = hashlib.sha256(file_data).hexdigest()
        
        # Save file
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
        file_extension = os.path.splitext(file_name)[1]
        file_path = os.path.join(
            Config.UPLOAD_FOLDER, 
            f"{customer_id}_{document_type.replace(' ', '_')}_{document_id}{file_extension}"
        )
        
        with open(file_path, 'wb') as f:
            f.write(file_data)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO documents 
            (document_id, customer_id, document_type, file_name, file_path,
             file_size, file_hash, upload_timestamp, verification_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (document_id, customer_id, document_type, file_name, file_path, 
              len(file_data), file_hash, timestamp, "UPLOADED"))
        
        # Store in ChromaDB if text was extracted
        chroma_stored = 0
        if extracted_text and extracted_text.strip():
            metadata = {
                "file_name": file_name,
                "document_type": document_type,
                "customer_name": self.get_customer_name(customer_id),
                "upload_date": timestamp
            }
            
            if self.chroma_db.add_document(document_id, customer_id, 
                                          document_type, extracted_text, metadata):
                chroma_stored = 1
                
                # Update chroma_stored flag
                cursor.execute('''
                    UPDATE documents SET chroma_stored = ? WHERE document_id = ?
                ''', (chroma_stored, document_id))
        
        # Update KYC process
        cursor.execute('''
            SELECT completed_steps FROM kyc_process WHERE customer_id = ?
        ''', (customer_id,))
        result = cursor.fetchone()
        
        if result:
            completed_steps = result[0]
            if "DOCUMENT_UPLOAD" not in completed_steps:
                cursor.execute('''
                    UPDATE kyc_process 
                    SET completed_steps = completed_steps || ',DOCUMENT_UPLOAD',
                        pending_steps = 'VERIFICATION,APPROVAL',
                        last_updated = ?
                    WHERE customer_id = ?
                ''', (timestamp, customer_id))
        
        conn.commit()
        conn.close()
        
        self.log_audit(customer_id, "DOCUMENT_UPLOAD",
                      f"Uploaded {document_type}: {file_name}")
        
        return document_id, file_path, chroma_stored
    
    def get_customer_name(self, customer_id):
        """Get customer name by ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT full_name FROM customers WHERE customer_id = ?', (customer_id,))
        result = cursor.fetchone()
        conn.close()
        
        return result[0] if result else "Unknown"
    
    def update_document_verification(self, document_id, verification_result):
        timestamp = datetime.datetime.now().isoformat()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE documents 
            SET verification_status = ?,
                ai_confidence = ?,
                extracted_data = ?,
                verification_date = ?,
                rejection_reason = ?
            WHERE document_id = ?
        ''', (
            verification_result['status'],
            verification_result['confidence'],
            json.dumps(verification_result['extracted_data']),
            timestamp,
            verification_result.get('rejection_reason', ''),
            document_id
        ))
        
        # Get customer_id for this document
        cursor.execute('SELECT customer_id FROM documents WHERE document_id = ?', (document_id,))
        result = cursor.fetchone()
        
        if result:
            customer_id = result[0]
            
            # Check if all documents are verified
            cursor.execute('''
                SELECT COUNT(*) as total,
                       SUM(CASE WHEN verification_status = 'VERIFIED' THEN 1 ELSE 0 END) as verified
                FROM documents 
                WHERE customer_id = ?
            ''', (customer_id,))
            
            doc_stats = cursor.fetchone()
            total_docs, verified_docs = doc_stats
            
            # Update KYC process status
            if verified_docs == total_docs and total_docs >= 3:  # All required docs verified
                cursor.execute('''
                    UPDATE kyc_process 
                    SET overall_status = 'COMPLETED',
                        current_step = 'APPROVAL',
                        completed_steps = completed_steps || ',VERIFICATION,APPROVAL',
                        pending_steps = '',
                        last_updated = ?
                    WHERE customer_id = ?
                ''', (timestamp, customer_id))
            elif verified_docs > 0:
                cursor.execute('''
                    UPDATE kyc_process 
                    SET overall_status = 'UNDER_REVIEW',
                        current_step = 'VERIFICATION',
                        completed_steps = completed_steps || ',VERIFICATION',
                        pending_steps = 'APPROVAL',
                        last_updated = ?
                    WHERE customer_id = ?
                ''', (timestamp, customer_id))
        
        conn.commit()
        conn.close()
        
        return True
    
    def search_similar_documents(self, query_text, customer_id=None, n_results=5):
        """Search for similar documents using ChromaDB"""
        return self.chroma_db.search_similar_documents(query_text, customer_id, n_results)
    
    def analyze_document_patterns(self, customer_id=None):
        """Analyze document patterns using ChromaDB"""
        return self.chroma_db.analyze_document_patterns(customer_id)
    
    def get_chroma_stats(self):
        """Get ChromaDB statistics"""
        return self.chroma_db.get_collection_stats()
    
    def log_audit(self, customer_id, action, details, status="SUCCESS"):
        log_id = f"LOG{str(uuid.uuid4())[:8].upper()}"
        timestamp = datetime.datetime.now().isoformat()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO audit_log 
            (log_id, customer_id, action, action_details, timestamp, status)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (log_id, customer_id, action, details, timestamp, status))
        
        conn.commit()
        conn.close()
        
        return log_id
    
    def get_customer_documents(self, customer_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT document_id, document_type, file_name, 
                   upload_timestamp, verification_status, ai_confidence,
                   extracted_data, rejection_reason, chroma_stored
            FROM documents 
            WHERE customer_id = ?
            ORDER BY upload_timestamp DESC
        ''', (customer_id,))
        
        documents = cursor.fetchall()
        conn.close()
        
        return documents
    
    def get_kyc_status(self, customer_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT overall_status, current_step, completed_steps, 
                   pending_steps, last_updated, start_date
            FROM kyc_process 
            WHERE customer_id = ?
        ''', (customer_id,))
        
        result = cursor.fetchone()
        
        # Get document stats
        cursor.execute('''
            SELECT 
                COUNT(*) as total_docs,
                SUM(CASE WHEN verification_status = 'VERIFIED' THEN 1 ELSE 0 END) as verified_docs,
                SUM(CASE WHEN verification_status = 'REJECTED' THEN 1 ELSE 0 END) as rejected_docs,
                SUM(CASE WHEN chroma_stored = 1 THEN 1 ELSE 0 END) as vectorized_docs
            FROM documents 
            WHERE customer_id = ?
        ''', (customer_id,))
        
        doc_stats = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'overall_status': result[0],
                'current_step': result[1],
                'completed_steps': result[2],
                'pending_steps': result[3],
                'last_updated': result[4],
                'start_date': result[5],
                'total_documents': doc_stats[0] if doc_stats else 0,
                'verified_documents': doc_stats[1] if doc_stats else 0,
                'rejected_documents': doc_stats[2] if doc_stats else 0,
                'vectorized_documents': doc_stats[3] if doc_stats else 0
            }
        else:
            return None
    
    def get_audit_logs(self, customer_id=None, limit=50):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if customer_id:
            cursor.execute('''
                SELECT log_id, action, action_details, timestamp, status
                FROM audit_log 
                WHERE customer_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (customer_id, limit))
        else:
            cursor.execute('''
                SELECT log_id, customer_id, action, action_details, timestamp, status
                FROM audit_log 
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (limit,))
        
        logs = cursor.fetchall()
        conn.close()
        
        return logs
    
    def generate_report(self, report_type, start_date=None, end_date=None):
        conn = sqlite3.connect(self.db_path)
        
        if report_type == "verification_summary":
            query = '''
                SELECT 
                    d.document_type,
                    COUNT(*) as total_uploads,
                    SUM(CASE WHEN d.verification_status = 'VERIFIED' THEN 1 ELSE 0 END) as verified,
                    SUM(CASE WHEN d.verification_status = 'REJECTED' THEN 1 ELSE 0 END) as rejected,
                    AVG(d.ai_confidence) as avg_confidence,
                    SUM(d.chroma_stored) as vectorized,
                    MIN(d.upload_timestamp) as first_upload,
                    MAX(d.upload_timestamp) as last_upload
                FROM documents d
                WHERE 1=1
            '''
            
            params = []
            if start_date:
                query += " AND DATE(d.upload_timestamp) >= ?"
                params.append(start_date)
            if end_date:
                query += " AND DATE(d.upload_timestamp) <= ?"
                params.append(end_date)
            
            query += " GROUP BY d.document_type ORDER BY total_uploads DESC"
            
            df = pd.read_sql_query(query, conn, params=params)
        
        elif report_type == "customer_activity":
            query = '''
                SELECT 
                    c.customer_id,
                    c.full_name,
                    c.email,
                    c.registration_date,
                    k.overall_status,
                    COUNT(d.document_id) as documents_uploaded,
                    SUM(CASE WHEN d.verification_status = 'VERIFIED' THEN 1 ELSE 0 END) as documents_verified,
                    SUM(d.chroma_stored) as documents_vectorized,
                    MAX(d.upload_timestamp) as last_activity
                FROM customers c
                LEFT JOIN kyc_process k ON c.customer_id = k.customer_id
                LEFT JOIN documents d ON c.customer_id = d.customer_id
                WHERE 1=1
            '''
            
            params = []
            if start_date:
                query += " AND DATE(c.registration_date) >= ?"
                params.append(start_date)
            if end_date:
                query += " AND DATE(c.registration_date) <= ?"
                params.append(end_date)
            
            query += " GROUP BY c.customer_id, c.full_name, c.email, c.registration_date, k.overall_status"
            
            df = pd.read_sql_query(query, conn, params=params)
        
        elif report_type == "audit_trail":
            query = '''
                SELECT 
                    timestamp,
                    customer_id,
                    action,
                    action_details,
                    status
                FROM audit_log
                WHERE 1=1
            '''
            
            params = []
            if start_date:
                query += " AND DATE(timestamp) >= ?"
                params.append(start_date)
            if end_date:
                query += " AND DATE(timestamp) <= ?"
                params.append(end_date)
            
            query += " ORDER BY timestamp DESC LIMIT 1000"
            
            df = pd.read_sql_query(query, conn, params=params)
        
        conn.close()
        return df

# ============= AI DOCUMENT PROCESSOR =============
class AIDocumentProcessor:
    def __init__(self):
        self.llm = llm
        self.ai_available = True if Config.AI_API_KEY else False
    
    def extract_text_from_pdf(self, file_data):
        """Extract text from PDF using PyMuPDF"""
        try:
            doc = pymupdf.open(stream=file_data, filetype="pdf")
            text = ""
            for page in doc:
                text += page.get_text()
            doc.close()
            return text
        except Exception as e:
            return f"PDF extraction error: {str(e)}"
    
    def extract_text_from_image(self, file_data):
        """Extract text from image using Tesseract"""
        try:
            image = Image.open(io.BytesIO(file_data))
            # Preprocess image for better OCR
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            # Convert to grayscale for better OCR
            gray_image = image.convert('L')
            text = pytesseract.image_to_string(gray_image)
            return text
        except Exception as e:
            return f"Image OCR error: {str(e)}"
    
    def analyze_document_with_ai(self, text_content, document_type, file_type):
        """Analyze document using AI"""
        try:
            prompt = f"""
            Analyze this {document_type} document ({file_type}) and provide a detailed verification report.
            
            Document content (first 3000 characters):
            {text_content[:3000]}
            
            Please provide a JSON response with the following structure:
            {{
                "document_type": "{document_type}",
                "extracted_fields": {{
                    "name": "extracted name if found",
                    "id_number": "extracted ID if found",
                    "date_of_birth": "extracted DOB if found",
                    "address": "extracted address if found",
                    "issue_date": "extracted issue date if found",
                    "expiry_date": "extracted expiry date if found"
                }},
                "validation_checks": {{
                    "is_complete": true/false,
                    "is_legible": true/false,
                    "contains_required_fields": true/false,
                    "dates_valid": true/false
                }},
                "anomalies": ["list any anomalies or issues found"],
                "confidence_score": 0.0 to 1.0,
                "verification_status": "VERIFIED" or "REJECTED",
                "rejection_reason": "reason if rejected, else empty string",
                "ai_notes": "additional AI observations"
            }}
            
            IMPORTANT: Return ONLY valid JSON, no additional text.
            """
            
            response = self.llm.invoke(prompt)
            ai_response = response.content
            
            # Extract JSON from response
            try:
                # Find JSON in the response
                start_idx = ai_response.find('{')
                end_idx = ai_response.rfind('}') + 1
                if start_idx != -1 and end_idx != 0:
                    json_str = ai_response[start_idx:end_idx]
                    result = json.loads(json_str)
                    
                    # Ensure required fields
                    if 'confidence_score' not in result:
                        result['confidence_score'] = 0.5
                    if 'verification_status' not in result:
                        result['verification_status'] = 'REJECTED'
                    
                    return result
            except json.JSONDecodeError as e:
                st.error(f"JSON parsing error: {e}")
                st.write(f"AI Response: {ai_response}")
            
            # Fallback response if JSON parsing fails
            return {
                "document_type": document_type,
                "extracted_fields": {},
                "validation_checks": {
                    "is_complete": False,
                    "is_legible": "unknown",
                    "contains_required_fields": False,
                    "dates_valid": "unknown"
                },
                "anomalies": ["AI response format error"],
                "confidence_score": 0.3,
                "verification_status": "REJECTED",
                "rejection_reason": "AI analysis failed",
                "ai_notes": "Could not parse AI response"
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "confidence_score": 0.0,
                "verification_status": "ERROR",
                "rejection_reason": f"AI processing error: {str(e)}"
            }
    
    def validate_photo_with_ai(self, file_data):
        """Specialized AI validation for photos"""
        try:
            prompt = """
            Analyze this photograph for KYC verification purposes.
            Check for the following:
            1. Is it a clear photo of a person's face?
            2. Is the face clearly visible (not blurred, not obscured)?
            3. Is the lighting adequate?
            4. Is it a recent photo (based on quality/appearance)?
            5. Does it look like a genuine photograph (not a digital copy of a photo)?
            
            Return a JSON response with:
            {
                "is_valid_photo": true/false,
                "face_detected": true/false,
                "image_quality": "poor/acceptable/good/excellent",
                "lighting_condition": "poor/acceptable/good",
                "estimated_recency": "recent/old/unknown",
                "confidence_score": 0.0 to 1.0,
                "issues": ["list any issues found"],
                "verification_status": "VERIFIED" or "REJECTED"
            }
            
            IMPORTANT: Return ONLY valid JSON, no additional text.
            """
            
            response = self.llm.invoke(prompt)
            ai_response = response.content
            
            try:
                start_idx = ai_response.find('{')
                end_idx = ai_response.rfind('}') + 1
                if start_idx != -1 and end_idx != 0:
                    json_str = ai_response[start_idx:end_idx]
                    return json.loads(json_str)
            except:
                pass
            
            return {
                "is_valid_photo": False,
                "face_detected": False,
                "image_quality": "poor",
                "confidence_score": 0.3,
                "verification_status": "REJECTED",
                "rejection_reason": "AI photo analysis failed"
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "verification_status": "ERROR"
            }
    
    def process_document(self, file_data, file_name, document_type):
        """Main document processing pipeline"""
        try:
            # Extract text based on file type
            file_extension = os.path.splitext(file_name)[1].lower()
            
            if file_extension == '.pdf':
                extracted_text = self.extract_text_from_pdf(file_data)
            elif file_extension in ['.jpg', '.jpeg', '.png']:
                extracted_text = self.extract_text_from_image(file_data)
            else:
                extracted_text = f"Unsupported file type: {file_extension}"
            
            # Use AI for analysis
            if self.ai_available:
                if document_type == "Photograph":
                    ai_result = self.validate_photo_with_ai(file_data)
                else:
                    ai_result = self.analyze_document_with_ai(
                        extracted_text, document_type, file_extension
                    )
            else:
                # Basic validation without AI
                ai_result = {
                    "document_type": document_type,
                    "extracted_fields": {},
                    "validation_checks": {
                        "is_complete": False,
                        "is_legible": False
                    },
                    "confidence_score": 0.5,
                    "verification_status": "PENDING",
                    "rejection_reason": "AI not available",
                    "ai_notes": "Basic validation only"
                }
            
            # Prepare result
            result = {
                'extracted_data': {
                    'raw_text': extracted_text,
                    'ai_analysis': ai_result,
                    'file_type': file_extension,
                    'processing_timestamp': datetime.datetime.now().isoformat()
                },
                'confidence': ai_result.get('confidence_score', 0.5),
                'status': ai_result.get('verification_status', 'PENDING'),
                'rejection_reason': ai_result.get('rejection_reason', '')
            }
            
            return result, extracted_text
            
        except Exception as e:
            return {
                'extracted_data': {'error': str(e)},
                'confidence': 0.0,
                'status': 'ERROR',
                'rejection_reason': f'Processing error: {str(e)}'
            }, ""

# ============= STREAMLIT UI =============
class KYCApplication:
    def __init__(self):
        self.db = DatabaseManager(Config.DB_PATH)
        self.ai_processor = AIDocumentProcessor()
        self.setup_page()
    
    def setup_page(self):
        st.set_page_config(
            page_title="AI-Powered KYC Verification with ChromaDB",
            page_icon="🏦",
            layout="wide",
            initial_sidebar_state="expanded"
        )
        
        # Custom CSS
        st.markdown("""
        <style>
        .main-header {
            font-size: 2.5rem;
            color: #1E3A8A;
            text-align: center;
            margin-bottom: 2rem;
        }
        .status-card {
            padding: 1rem;
            border-radius: 10px;
            border-left: 5px solid;
            margin: 0.5rem 0;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .verified { border-left-color: #10B981; }
        .pending { border-left-color: #F59E0B; }
        .rejected { border-left-color: #EF4444; }
        .error { border-left-color: #6B7280; }
        .vectorized { border-left-color: #8B5CF6; }
        .stProgress > div > div > div > div {
            background-color: #1E3A8A;
        }
        .ai-response {
            background-color: #F3F4F6;
            padding: 1rem;
            border-radius: 5px;
            border-left: 4px solid #3B82F6;
            margin: 1rem 0;
        }
        .vector-result {
            background-color: #E0E7FF;
            padding: 0.5rem;
            border-radius: 5px;
            margin: 0.5rem 0;
            border-left: 3px solid #8B5CF6;
        }
        </style>
        """, unsafe_allow_html=True)
    
    def run(self):
        st.markdown('<h1 class="main-header">🏦 AI-Powered KYC with Vector Database</h1>', 
                   unsafe_allow_html=True)
        
        # Check API key status
        if not Config.AI_API_KEY:
            st.warning("""
            ⚠️ **AI Service Not Configured**
            
            Please add your API key to enable AI document analysis.
            Location: `Config.AI_API_KEY` in the code.
            
            Basic OCR will still work, but AI features will be limited.
            """)
        
        # Sidebar navigation
        st.sidebar.title("🔍 Navigation")
        menu = st.sidebar.radio(
            "Select Page",
            ["Home", "Customer Registration", "Document Upload", 
             "KYC Status Dashboard", "Vector Search", 
             "Document Analysis", "Compliance Reports", "Audit Trail"]
        )
        
        # Initialize session state
        if 'customer_id' not in st.session_state:
            st.session_state.customer_id = None
        if 'current_document' not in st.session_state:
            st.session_state.current_document = None
        
        # Route to selected page
        if menu == "Home":
            self.show_home()
        elif menu == "Customer Registration":
            self.show_registration()
        elif menu == "Document Upload":
            self.show_upload()
        elif menu == "KYC Status Dashboard":
            self.show_status()
        elif menu == "Vector Search":
            self.show_vector_search()
        elif menu == "Document Analysis":
            self.show_document_analysis()
        elif menu == "Compliance Reports":
            self.show_reports()
        elif menu == "Audit Trail":
            self.show_audit_trail()
    
    def show_home(self):
        st.subheader("Welcome to AI-Powered KYC with Vector Database")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.info("""
            **🤖 AI + Vector DB**
            - DeepSeek AI document analysis
            - ChromaDB vector storage
            - Semantic search capabilities
            - Pattern detection
            """)
        
        with col2:
            st.info("""
            **🔍 Smart Search**
            - Find similar documents
            - Detect fraud patterns
            - Analyze document consistency
            - Cross-reference verification
            """)
        
        with col3:
            st.info("""
            **📊 Advanced Analytics**
            - Vector-based insights
            - Document clustering
            - Anomaly detection
            - Performance metrics
            """)
        
        st.markdown("---")
        
        # Quick stats
        st.subheader("📊 System Overview")
        
        try:
            # Get database stats
            conn = sqlite3.connect(Config.DB_PATH)
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM customers")
            total_customers = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM documents")
            total_documents = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM documents WHERE verification_status = 'VERIFIED'")
            verified_docs = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM documents WHERE chroma_stored = 1")
            vectorized_docs = cursor.fetchone()[0]
            
            conn.close()
            
            # Get ChromaDB stats
            chroma_stats = self.db.get_chroma_stats()
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Customers", total_customers)
            with col2:
                st.metric("Documents Processed", total_documents)
            with col3:
                st.metric("Verified Documents", verified_docs)
            with col4:
                st.metric("Vectorized Documents", vectorized_docs)
            
            # ChromaDB status
            st.markdown("### 🗄️ ChromaDB Status")
            col1, col2 = st.columns(2)
            
            with col1:
                if chroma_stats.get('status') == 'active':
                    st.success(f"✅ ChromaDB Active")
                    st.write(f"Collection: {chroma_stats.get('collection_name')}")
                    st.write(f"Documents: {chroma_stats.get('document_count', 0)}")
                else:
                    st.warning("⚠️ ChromaDB Not Active")
            
            with col2:
                st.write(f"**Storage Path:** `{chroma_stats.get('persist_directory', 'N/A')}`")
                
        except Exception as e:
            st.error(f"Error loading stats: {str(e)}")
        
        # Quick start buttons
        st.markdown("---")
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("🚀 Start Registration", use_container_width=True):
                st.session_state.menu = "Customer Registration"
                st.rerun()
        with col2:
            if st.button("🔍 Try Vector Search", use_container_width=True):
                st.session_state.menu = "Vector Search"
                st.rerun()
        with col3:
            if st.button("📊 View Dashboard", use_container_width=True):
                st.session_state.menu = "KYC Status Dashboard"
                st.rerun()
    
    def show_registration(self):
        st.subheader("👤 Customer Registration")
        
        with st.form("registration_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                full_name = st.text_input("Full Name *")
                email = st.text_input("Email Address *")
                phone = st.text_input("Phone Number *")
            
            with col2:
                dob = st.date_input("Date of Birth *", 
                                  min_value=datetime.date(1900, 1, 1),
                                  max_value=datetime.date.today())
                nationality = st.selectbox("Nationality *", [
                    "Select Nationality",
                    "United States", "United Kingdom", "India",
                    "Canada", "Australia", "Germany", 
                    "France", "Japan", "Singapore",
                    "United Arab Emirates", "Other"
                ])
            
            terms = st.checkbox("I agree to the terms and conditions *")
            
            submit = st.form_submit_button("Register Now", type="primary")
            
            if submit:
                if any(not field for field in [full_name, email, phone]) or nationality == "Select Nationality":
                    st.error("Please fill all required fields (*)")
                elif not terms:
                    st.error("Please accept the terms and conditions")
                elif not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
                    st.error("Please enter a valid email address")
                else:
                    customer_data = {
                        'full_name': full_name,
                        'email': email,
                        'phone': phone,
                        'date_of_birth': dob.strftime("%Y-%m-%d"),
                        'nationality': nationality
                    }
                    
                    with st.spinner("Registering customer..."):
                        customer_id = self.db.register_customer(customer_data)
                        st.session_state.customer_id = customer_id
                        
                        st.success("✅ Registration Successful!")
                        
                        # Show customer details
                        st.markdown("---")
                        st.subheader("📋 Customer Details")
                        
                        info_col1, info_col2 = st.columns(2)
                        with info_col1:
                            st.info(f"**Customer ID:**\n`{customer_id}`")
                            st.info(f"**Full Name:**\n{full_name}")
                            st.info(f"**Email:**\n{email}")
                        
                        with info_col2:
                            st.info(f"**Phone:**\n{phone}")
                            st.info(f"**Date of Birth:**\n{dob}")
                            st.info(f"**Nationality:**\n{nationality}")
                        
                        # Show next steps
                        st.markdown("---")
                        st.subheader("🎯 Next Steps")
                        steps = [
                            "1. **Upload Required Documents** - Go to 'Document Upload' page",
                            "2. **AI + Vector Analysis** - Documents will be processed and stored in vector DB",
                            "3. **Check Status** - Monitor progress in 'KYC Status Dashboard'",
                            "4. **Use Vector Search** - Find similar documents and patterns"
                        ]
                        
                        for step in steps:
                            st.write(step)
                        
                        # Save to session state
                        st.session_state.registration_complete = True
    
    def show_upload(self):
        st.subheader("📤 Document Upload with Vector Storage")
        
        # Check if registered
        if not st.session_state.get('customer_id'):
            customer_id_input = st.text_input("Enter your Customer ID:", 
                                            placeholder="CUSTXXXXXX")
            
            if customer_id_input:
                # Verify customer exists
                conn = sqlite3.connect(Config.DB_PATH)
                cursor = conn.cursor()
                cursor.execute("SELECT customer_id FROM customers WHERE customer_id = ?", 
                             (customer_id_input,))
                result = cursor.fetchone()
                conn.close()
                
                if result:
                    st.session_state.customer_id = customer_id_input
                    st.success(f"✅ Customer ID verified: {customer_id_input}")
                else:
                    st.error("❌ Customer ID not found. Please register first.")
                    if st.button("Go to Registration"):
                        st.session_state.menu = "Customer Registration"
                        st.rerun()
                    return
            else:
                st.info("Please enter your Customer ID or register first.")
                if st.button("Register New Customer"):
                    st.session_state.menu = "Customer Registration"
                    st.rerun()
                return
        else:
            customer_id = st.session_state.customer_id
            st.info(f"**Customer ID:** {customer_id}")
        
        # Document type selection
        st.markdown("### Select Document Type")
        document_type = st.selectbox(
            "Choose the type of document to upload:",
            ["ID Proof (Passport/Driver's License)", 
             "Address Proof (Utility Bill/Bank Statement)",
             "Photograph (Passport Photo/Selfie)"],
            help="Select the appropriate document category"
        )
        
        # Map selection to internal type
        doc_type_map = {
            "ID Proof (Passport/Driver's License)": "ID Proof",
            "Address Proof (Utility Bill/Bank Statement)": "Address Proof", 
            "Photograph (Passport Photo/Selfie)": "Photograph"
        }
        internal_doc_type = doc_type_map[document_type]
        
        # File uploader
        st.markdown("### Upload Document")
        uploaded_file = st.file_uploader(
            f"Upload {document_type}",
            type=['pdf', 'jpg', 'jpeg', 'png'],
            help="Max file size: 5MB. Supported formats: PDF, JPG, PNG"
        )
        
        if uploaded_file:
            # File preview and info
            st.markdown("### 📄 Document Preview")
            
            col1, col2 = st.columns([2, 1])
            
            with col1:
                if uploaded_file.type.startswith('image/'):
                    st.image(uploaded_file, caption="Document Preview", width=400)
                else:
                    st.info(f"📋 **PDF Document:** {uploaded_file.name}")
                    st.write(f"Size: {uploaded_file.size / 1024:.1f} KB")
            
            with col2:
                file_info = {
                    "Filename": uploaded_file.name,
                    "File Type": uploaded_file.type,
                    "Size (KB)": f"{uploaded_file.size / 1024:.1f}",
                    "Extension": os.path.splitext(uploaded_file.name)[1]
                }
                
                for key, value in file_info.items():
                    st.write(f"**{key}:** {value}")
            
            # Process button
            if st.button("🚀 Process & Vectorize", type="primary"):
                with st.spinner("🤖 AI is analyzing and vectorizing your document..."):
                    # Read file data
                    file_data = uploaded_file.getvalue()
                    
                    # Process with AI
                    result, extracted_text = self.ai_processor.process_document(
                        file_data, uploaded_file.name, internal_doc_type
                    )
                    
                    # Upload to database with vector storage
                    document_id, file_path, chroma_stored = self.db.upload_document(
                        customer_id, internal_doc_type, file_data, 
                        uploaded_file.name, extracted_text
                    )
                    
                    # Update database with AI results
                    self.db.update_document_verification(document_id, result)
                    
                    # Show results
                    st.success("✅ Document processed and vectorized successfully!")
                    
                    # Display processing results
                    st.markdown("---")
                    st.subheader("📊 Processing Results")
                    
                    # Status and confidence
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        status = result['status']
                        status_icon = "🟢" if status == "VERIFIED" else "🔴" if status == "REJECTED" else "🟡"
                        st.metric("Verification Status", f"{status_icon} {status}")
                    
                    with col2:
                        confidence = result['confidence']
                        st.metric("AI Confidence", f"{confidence:.1%}")
                    
                    with col3:
                        st.metric("Document ID", document_id)
                    
                    with col4:
                        vector_status = "✅" if chroma_stored else "❌"
                        st.metric("Vector Storage", vector_status)
                    
                    # Show AI analysis details
                    if result['extracted_data'].get('ai_analysis'):
                        ai_analysis = result['extracted_data']['ai_analysis']
                        
                        with st.expander("📊 View Detailed AI Analysis", expanded=True):
                            # Extracted fields
                            if ai_analysis.get('extracted_fields'):
                                st.markdown("**Extracted Information:**")
                                extracted = ai_analysis['extracted_fields']
                                for field, value in extracted.items():
                                    if value:
                                        st.write(f"- **{field.replace('_', ' ').title()}:** {value}")
                            
                            # Validation checks
                            if ai_analysis.get('validation_checks'):
                                st.markdown("**Validation Checks:**")
                                checks = ai_analysis['validation_checks']
                                for check, result_val in checks.items():
                                    icon = "✅" if result_val == True else "❌" if result_val == False else "⚠️"
                                    st.write(f"{icon} **{check.replace('_', ' ').title()}:** {result_val}")
                    
                    # Show extracted text preview
                    if extracted_text:
                        with st.expander("📝 View Extracted Text", expanded=False):
                            st.text_area("Extracted Text", extracted_text[:2000] + "..." 
                                       if len(extracted_text) > 2000 else extracted_text, 
                                       height=200)
                    
                    # Vector storage info
                    st.markdown("---")
                    st.subheader("🗄️ Vector Storage Information")
                    
                    if chroma_stored:
                        st.success("""
                        ✅ **Document Successfully Vectorized**
                        
                        **What this means:**
                        - Document text converted to vector embeddings
                        - Stored in ChromaDB vector database
                        - Available for semantic search
                        - Can be used for pattern detection
                        - Enables similarity comparisons
                        """)
                        
                        # Show what you can do with vectorized document
                        st.info("""
                        **Now you can:**
                        1. **Search for similar documents** in Vector Search page
                        2. **Analyze document patterns** in Document Analysis page
                        3. **Detect inconsistencies** across documents
                        4. **Find fraud patterns** using vector similarity
                        """)
                    else:
                        st.warning("""
                        ⚠️ **Document Not Vectorized**
                        
                        **Possible reasons:**
                        - No text could be extracted from document
                        - Document was an image without OCR-able text
                        - ChromaDB storage issue
                        
                        **Note:** AI verification still works, but vector features won't be available.
                        """)
                    
                    # Next steps
                    st.markdown("---")
                    st.subheader("🎯 Next Steps")
                    
                    if result['status'] == 'VERIFIED':
                        st.success("""
                        ✅ **Document Verified Successfully!**
                        
                        Next:
                        1. Upload remaining required documents
                        2. Use Vector Search to find similar documents
                        3. Check overall KYC status in dashboard
                        """)
                    elif result['status'] == 'REJECTED':
                        st.warning("""
                        ⚠️ **Document Rejected**
                        
                        Please:
                        1. Review the rejection reasons above
                        2. Upload a corrected/clearer version
                        3. Ensure document meets requirements
                        """)
                    
                    # Store document for reference
                    st.session_state.current_document = {
                        'id': document_id,
                        'type': internal_doc_type,
                        'result': result,
                        'vectorized': chroma_stored
                    }
        
        # Show uploaded documents for this customer
        st.markdown("---")
        st.subheader("📁 Your Uploaded Documents")
        
        documents = self.db.get_customer_documents(customer_id)
        
        if documents:
            for doc in documents:
                doc_id, doc_type, file_name, upload_time, status, confidence, 
                extracted_data, rejection_reason, chroma_stored = doc
                
                # Determine status class
                status_class = {
                    "VERIFIED": "verified",
                    "UPLOADED": "pending",
                    "REJECTED": "rejected",
                    "PENDING": "pending",
                    "ERROR": "error"
                }.get(status, "pending")
                
                # Add vectorized class if stored in ChromaDB
                if chroma_stored:
                    status_class += " vectorized"
                
                # Display document card
                with st.expander(f"{doc_type} - {status}", expanded=False):
                    col1, col2, col3 = st.columns([3, 1, 1])
                    
                    with col1:
                        st.write(f"**File:** {file_name}")
                        st.write(f"**Uploaded:** {upload_time[:16].replace('T', ' ')}")
                        
                        if chroma_stored:
                            st.success("✅ Vectorized")
                    
                    with col2:
                        status_badge = {
                            "VERIFIED": "✅ Verified",
                            "REJECTED": "❌ Rejected", 
                            "PENDING": "⏳ Pending",
                            "UPLOADED": "📤 Uploaded",
                            "ERROR": "⚠️ Error"
                        }.get(status, status)
                        
                        st.write(f"**Status:** {status_badge}")
                        if confidence:
                            st.write(f"**Confidence:** {confidence:.1%}")
                    
                    with col3:
                        if chroma_stored:
                            if st.button("🔍 Search Similar", key=f"search_{doc_id}"):
                                st.session_state.search_query = extracted_data[:500] if extracted_data else ""
                                st.session_state.menu = "Vector Search"
                                st.rerun()
        else:
            st.info("No documents uploaded yet.")
    
    def show_status(self):
        st.subheader("📊 KYC Status Dashboard")
        
        # Customer ID input
        if not st.session_state.get('customer_id'):
            customer_id = st.text_input("Enter Customer ID to check status:")
            if customer_id:
                st.session_state.customer_id = customer_id
            else:
                return
        else:
            customer_id = st.session_state.customer_id
        
        st.info(f"**Tracking Customer:** `{customer_id}`")
        
        # Get KYC status
        status_info = self.db.get_kyc_status(customer_id)
        
        if not status_info:
            st.error("Customer ID not found. Please check the ID or register first.")
            return
        
        # Display overall status
        st.markdown("### 🎯 Overall KYC Status")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            overall_status = status_info['overall_status']
            status_icons = {
                "COMPLETED": "✅",
                "IN_PROGRESS": "🔄", 
                "UNDER_REVIEW": "🔍",
                "PENDING": "⏳",
                "REJECTED": "❌"
            }
            icon = status_icons.get(overall_status, "❓")
            st.metric("Current Status", f"{icon} {overall_status}")
        
        with col2:
            current_step = status_info['current_step']
            st.metric("Current Step", current_step)
        
        with col3:
            progress = status_info['verified_documents'] / 3 if status_info['total_documents'] > 0 else 0
            st.metric("Progress", f"{status_info['verified_documents']}/3 Documents")
        
        with col4:
            vectorized = status_info['vectorized_documents']
            st.metric("Vectorized Docs", f"{vectorized}")
        
        # Progress bar
        st.progress(progress)
        
        # Status details
        st.markdown("### 📋 Status Details")
        
        details_col1, details_col2 = st.columns(2)
        
        with details_col1:
            st.write("**Completed Steps:**")
            completed = status_info['completed_steps'].split(',') if status_info['completed_steps'] else []
            for step in completed:
                if step:
                    st.write(f"✅ {step}")
            
            st.write("**Pending Steps:**")
            pending = status_info['pending_steps'].split(',') if status_info['pending_steps'] else []
            for step in pending:
                if step:
                    st.write(f"⏳ {step}")
        
        with details_col2:
            st.write("**Document Statistics:**")
            st.write(f"📄 Total Uploaded: {status_info['total_documents']}")
            st.write(f"✅ Verified: {status_info['verified_documents']}")
            st.write(f"❌ Rejected: {status_info['rejected_documents']}")
            st.write(f"🗄️ Vectorized: {status_info['vectorized_documents']}")
            st.write(f"📅 Started: {status_info['start_date'][:10]}")
            st.write(f"🕒 Last Updated: {status_info['last_updated'][:16].replace('T', ' ')}")
        
        # Vector database analysis
        st.markdown("---")
        st.subheader("🔍 Vector Database Analysis")
        
        if st.button("Analyze Document Patterns", type="secondary"):
            with st.spinner("Analyzing document patterns using vector DB..."):
                analysis = self.db.analyze_document_patterns(customer_id)
                
                if analysis and 'error' not in analysis:
                    st.success(f"✅ Analyzed {analysis.get('total_documents', 0)} documents")
                    
                    if analysis.get('document_types'):
                        st.write("**Document Types:**")
                        for doc_type, count in analysis['document_types'].items():
                            st.write(f"- {doc_type}: {count}")
                    
                    if analysis.get('patterns'):
                        st.write("**AI Pattern Analysis:**")
                        st.json(analysis['patterns'][0] if analysis['patterns'] else {})
                else:
                    st.warning("No vector analysis available or error occurred")
        
        # Next steps based on status
        st.markdown("### 🎯 Next Actions")
        
        if overall_status == "COMPLETED":
            st.success("""
            🎉 **KYC Process Completed!**
            
            Your account verification is complete. You can now:
            1. Access full banking services
            2. Make transactions
            3. Apply for additional products
            
            **Next:** Wait for final account activation (usually within 24 hours).
            """)
        
        elif overall_status == "UNDER_REVIEW":
            st.info("""
            🔍 **Under Review**
            
            Your documents are being reviewed. Please:
            1. Wait for verification completion
            2. Check back for updates
            3. Upload any requested additional documents
            
            **Estimated completion:** 1-2 business days
            """)
        
        elif status_info['verified_documents'] < 3:
            st.warning("""
            📋 **Documents Required**
            
            Please upload all required documents:
            1. **ID Proof** (Passport/Driver's License)
            2. **Address Proof** (Utility Bill/Bank Statement)
            3. **Photograph** (Passport Photo)
            
            **Current status:** {verified}/3 documents verified
            """.format(verified=status_info['verified_documents']))
        
        elif status_info['rejected_documents'] > 0:
            st.error("""
            ⚠️ **Action Required**
            
            Some documents were rejected. Please:
            1. Check rejection reasons
            2. Re-upload corrected documents
            3. Ensure documents meet requirements
            
            **Rejected documents:** {rejected}
            """.format(rejected=status_info['rejected_documents']))
    
    def show_vector_search(self):
        st.subheader("🔍 Vector Database Search")
        
        # ChromaDB status
        chroma_stats = self.db.get_chroma_stats()
        
        col1, col2 = st.columns(2)
        
        with col1:
            if chroma_stats.get('status') == 'active':
                st.success(f"✅ ChromaDB Active")
                st.write(f"Documents: {chroma_stats.get('document_count', 0)}")
            else:
                st.error("❌ ChromaDB Not Available")
        
        with col2:
            st.write("**Collection:**", chroma_stats.get('collection_name', 'N/A'))
            st.write("**Storage:**", chroma_stats.get('persist_directory', 'N/A'))
        
        # Search options
        st.markdown("---")
        st.subheader("Search Options")
        
        search_tab1, search_tab2, search_tab3 = st.tabs([
            "Text Search", "Customer Documents", "Similarity Analysis"
        ])
        
        with search_tab1:
            # Text-based search
            st.markdown("### 🔤 Text-based Semantic Search")
            
            search_query = st.text_area(
                "Enter search query:",
                placeholder="e.g., 'passport number', 'address verification', 'date of birth'",
                height=100
            )
            
            customer_filter = st.text_input("Filter by Customer ID (optional):", 
                                          placeholder="CUSTXXXXXX")
            
            col1, col2 = st.columns(2)
            with col1:
                n_results = st.slider("Number of results:", 1, 20, 5)
            with col2:
                min_similarity = st.slider("Minimum similarity:", 0.0, 1.0, 0.5)
            
            if st.button("🔍 Search Documents", type="primary"):
                if search_query:
                    with st.spinner("Searching vector database..."):
                        results = self.db.search_similar_documents(
                            search_query, customer_filter, n_results
                        )
                        
                        if results:
                            st.success(f"✅ Found {len(results)} similar documents")
                            
                            for i, result in enumerate(results):
                                with st.expander(f"Result {i+1}: Similarity {result['similarity_score']:.2%}", 
                                               expanded=i==0):
                                    col1, col2 = st.columns([1, 3])
                                    
                                    with col1:
                                        st.write(f"**Document ID:** {result['document_id']}")
                                        st.write(f"**Customer:** {result['customer_id']}")
                                        st.write(f"**Type:** {result['metadata'].get('document_type', 'N/A')}")
                                        st.write(f"**Similarity:** {result['similarity_score']:.2%}")
                                        st.write(f"**Date:** {result['metadata'].get('upload_date', 'N/A')[:10]}")
                                    
                                    with col2:
                                        st.write("**Extracted Text Preview:**")
                                        st.text(result['text'][:500] + "..." 
                                               if len(result['text']) > 500 else result['text'])
                                        
                                        # Show metadata
                                        st.write("**Metadata:**")
                                        for key, value in result['metadata'].items():
                                            if key not in ['customer_id', 'document_id']:
                                                st.write(f"- **{key}:** {value}")
                        else:
                            st.info("No matching documents found.")
                else:
                    st.warning("Please enter a search query.")
        
        with search_tab2:
            # Customer-specific search
            st.markdown("### 👤 Customer Document Analysis")
            
            customer_id = st.text_input("Enter Customer ID:", 
                                      placeholder="CUSTXXXXXX",
                                      key="customer_search")
            
            if customer_id:
                if st.button("Analyze Customer Documents", type="secondary"):
                    with st.spinner("Analyzing customer documents..."):
                        # Get documents from ChromaDB
                        documents = self.db.chroma_db.get_customer_documents(customer_id)
                        
                        if documents:
                            st.success(f"✅ Found {len(documents)} documents for customer {customer_id}")
                            
                            # Show document types distribution
                            doc_types = {}
                            for doc in documents:
                                doc_type = doc['metadata'].get('document_type', 'unknown')
                                doc_types[doc_type] = doc_types.get(doc_type, 0) + 1
                            
                            st.write("**Document Types:**")
                            for doc_type, count in doc_types.items():
                                st.write(f"- {doc_type}: {count}")
                            
                            # Show sample documents
                            st.write("**Sample Documents:**")
                            for i, doc in enumerate(documents[:3]):
                                with st.expander(f"Document {i+1}: {doc['metadata'].get('document_type', 'N/A')}"):
                                    st.write(f"**ID:** {doc['document_id']}")
                                    st.write(f"**Text Preview:**")
                                    st.text(doc['text'][:300] + "..." if len(doc['text']) > 300 else doc['text'])
                        else:
                            st.info(f"No vectorized documents found for customer {customer_id}")
            
            # Find similar customers
            st.markdown("---")
            st.markdown("### 👥 Find Similar Customers")
            
            reference_customer = st.text_input("Reference Customer ID:", 
                                             placeholder="CUSTXXXXXX",
                                             key="ref_customer")
            
            if reference_customer and st.button("Find Similar Customers"):
                with st.spinner("Finding similar customers..."):
                    # Get reference customer documents
                    ref_docs = self.db.chroma_db.get_customer_documents(reference_customer)
                    
                    if ref_docs:
                        # Combine all text from reference customer
                        combined_text = " ".join([doc['text'] for doc in ref_docs if doc['text']])
                        
                        # Search for similar documents excluding the reference customer
                        similar_docs = self.db.search_similar_documents(
                            combined_text, 
                            customer_id=None,  # Search all customers
                            n_results=10
                        )
                        
                        # Group by customer
                        customer_similarity = {}
                        for doc in similar_docs:
                            cust_id = doc['customer_id']
                            if cust_id != reference_customer:
                                if cust_id not in customer_similarity:
                                    customer_similarity[cust_id] = []
                                customer_similarity[cust_id].append(doc['similarity_score'])
                        
                        # Calculate average similarity per customer
                        customer_avg_similarity = {}
                        for cust_id, scores in customer_similarity.items():
                            customer_avg_similarity[cust_id] = sum(scores) / len(scores)
                        
                        # Display results
                        if customer_avg_similarity:
                            st.success(f"✅ Found {len(customer_avg_similarity)} similar customers")
                            
                            for cust_id, avg_score in sorted(customer_avg_similarity.items(), 
                                                           key=lambda x: x[1], reverse=True)[:5]:
                                st.write(f"**Customer {cust_id}**: Similarity {avg_score:.2%}")
                        else:
                            st.info("No similar customers found.")
                    else:
                        st.warning(f"No vectorized documents found for reference customer {reference_customer}")
        
        with search_tab3:
            # Similarity analysis
            st.markdown("### 📊 Document Similarity Analysis")
            
            doc1_text = st.text_area("First document text:", height=150,
                                   placeholder="Paste document text here...")
            doc2_text = st.text_area("Second document text:", height=150,
                                   placeholder="Paste another document text here...")
            
            if st.button("Compare Documents", type="primary"):
                if doc1_text and doc2_text:
                    with st.spinner("Calculating similarity..."):
                        # Get embeddings
                        embedding1 = self.db.chroma_db.get_embedding(doc1_text)
                        embedding2 = self.db.chroma_db.get_embedding(doc2_text)
                        
                        # Calculate cosine similarity
                        from numpy import dot
                        from numpy.linalg import norm
                        
                        cos_sim = dot(embedding1, embedding2) / (norm(embedding1) * norm(embedding2))
                        
                        # Display results
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.metric("Cosine Similarity", f"{cos_sim:.2%}")
                        
                        with col2:
                            similarity_level = "High" if cos_sim > 0.7 else "Medium" if cos_sim > 0.4 else "Low"
                            st.metric("Similarity Level", similarity_level)
                        
                        with col3:
                            recommendation = "Likely Same Source" if cos_sim > 0.8 else "Similar Content" if cos_sim > 0.6 else "Different Content"
                            st.metric("Recommendation", recommendation)
                        
                        # Show analysis
                        st.markdown("#### Analysis")
                        if cos_sim > 0.8:
                            st.success("""
                            **High Similarity Detected**
                            
                            These documents are very similar. This could indicate:
                            - Documents from the same source
                            - Consistent information across documents
                            - Potential template-based documents
                            """)
                        elif cos_sim > 0.5:
                            st.info("""
                            **Moderate Similarity**
                            
                            Documents share some similarities but are not identical.
                            This is typical for KYC documents from the same person.
                            """)
                        else:
                            st.warning("""
                            **Low Similarity**
                            
                            Documents are quite different. This could indicate:
                            - Documents from different sources
                            - Inconsistent information
                            - Potential fraud (if documents should be similar)
                            """)
                else:
                    st.warning("Please provide text for both documents.")
    
    def show_document_analysis(self):
        st.subheader("📊 Document Analysis & Insights")
        
        # Analysis options
        analysis_type = st.selectbox(
            "Select Analysis Type",
            ["Pattern Detection", "Anomaly Detection", "Consistency Check", 
             "Fraud Pattern Analysis", "Document Clustering"]
        )
        
        customer_id = st.text_input("Customer ID (optional for customer-specific analysis):",
                                  placeholder="CUSTXXXXXX")
        
        if st.button("Run Analysis", type="primary"):
            with st.spinner(f"Running {analysis_type}..."):
                # Get analysis from ChromaDB
                analysis = self.db.analyze_document_patterns(customer_id)
                
                if analysis and 'error' not in analysis:
                    st.success(f"✅ Analysis Complete")
                    
                    # Display results based on analysis type
                    if analysis_type == "Pattern Detection":
                        st.markdown("### 🔍 Document Patterns")
                        
                        if analysis.get('document_types'):
                            st.write("**Document Type Distribution:**")
                            for doc_type, count in analysis['document_types'].items():
                                st.write(f"- **{doc_type}**: {count} documents")
                        
                        if analysis.get('patterns'):
                            st.write("**AI-Detected Patterns:**")
                            st.json(analysis['patterns'][0] if analysis['patterns'] else {})
                    
                    elif analysis_type == "Anomaly Detection":
                        st.markdown("### ⚠️ Anomaly Detection")
                        
                        # Use AI to detect anomalies
                        try:
                            prompt = f"""
                            Analyze these document patterns for anomalies:
                            
                            {json.dumps(analysis, indent=2)}
                            
                            Look for:
                            1. Inconsistent information across documents
                            2. Unusual document patterns
                            3. Potential fraud indicators
                            4. Data quality issues
                            
                            Return JSON with:
                            {{
                                "anomalies": ["list of anomalies found"],
                                "risk_level": "low/medium/high",
                                "recommendations": ["list of recommendations"]
                            }}
                            """
                            
                            response = llm.invoke(prompt)
                            anomaly_report = json.loads(response.content)
                            
                            st.write(f"**Risk Level:** {anomaly_report.get('risk_level', 'unknown')}")
                            
                            if anomaly_report.get('anomalies'):
                                st.write("**Detected Anomalies:**")
                                for anomaly in anomaly_report['anomalies']:
                                    st.write(f"⚠️ {anomaly}")
                            
                            if anomaly_report.get('recommendations'):
                                st.write("**Recommendations:**")
                                for rec in anomaly_report['recommendations']:
                                    st.write(f"✅ {rec}")
                                    
                        except Exception as e:
                            st.error(f"Anomaly detection failed: {str(e)}")
                    
                    elif analysis_type == "Consistency Check":
                        st.markdown("### ✅ Consistency Analysis")
                        
                        if customer_id:
                            # Get customer documents
                            documents = self.db.chroma_db.get_customer_documents(customer_id)
                            
                            if documents:
                                # Extract key information from documents
                                key_info = []
                                for doc in documents:
                                    if doc['text']:
                                        # Use AI to extract key info
                                        try:
                                            prompt = f"""
                                            Extract key information from this document text:
                                            
                                            {doc['text'][:1000]}
                                            
                                            Return JSON with:
                                            {{
                                                "names": ["list of names found"],
                                                "dates": ["list of dates found"],
                                                "numbers": ["list of ID numbers found"],
                                                "addresses": ["list of addresses found"]
                                            }}
                                            """
                                            
                                            response = llm.invoke(prompt)
                                            doc_info = json.loads(response.content)
                                            key_info.append({
                                                "document_id": doc['document_id'],
                                                "info": doc_info
                                            })
                                        except:
                                            pass
                                
                                # Analyze consistency
                                if key_info:
                                    st.write("**Extracted Information:**")
                                    for doc_info in key_info:
                                        with st.expander(f"Document {doc_info['document_id']}"):
                                            st.json(doc_info['info'])
                        else:
                            st.info("Please enter a Customer ID for consistency check.")
                    
                    elif analysis_type == "Document Clustering":
                        st.markdown("### 🎯 Document Clustering")
                        
                        # Simple clustering analysis
                        total_docs = analysis.get('total_documents', 0)
                        doc_types = analysis.get('document_types', {})
                        
                        st.write(f"**Total Documents:** {total_docs}")
                        st.write(f"**Unique Document Types:** {len(doc_types)}")
                        
                        # Show clustering suggestions
                        if len(doc_types) > 1:
                            st.success("""
                            **Multiple Document Types Detected**
                            
                            Suggested clustering approach:
                            1. Cluster by document type
                            2. Cluster by customer
                            3. Cluster by date ranges
                            4. Cluster by extracted entities
                            """)
                        
                        # Show document type distribution
                        if doc_types:
                            import plotly.express as px
                            
                            df = pd.DataFrame({
                                'Document Type': list(doc_types.keys()),
                                'Count': list(doc_types.values())
                            })
                            
                            fig = px.pie(df, values='Count', names='Document Type', 
                                       title='Document Type Distribution')
                            st.plotly_chart(fig)
                
                else:
                    st.warning("No analysis data available or error occurred.")
        
        # Quick analysis tools
        st.markdown("---")
        st.subheader("🛠️ Quick Analysis Tools")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 Refresh Vector Index", type="secondary"):
                with st.spinner("Refreshing vector index..."):
                    chroma_stats = self.db.get_chroma_stats()
                    st.info(f"Vector database status: {chroma_stats.get('status', 'unknown')}")
                    st.info(f"Total documents: {chroma_stats.get('document_count', 0)}")
        
        with col2:
            if st.button("📊 Show Database Stats", type="secondary"):
                with st.spinner("Loading statistics..."):
                    try:
                        conn = sqlite3.connect(Config.DB_PATH)
                        
                        # Get SQLite stats
                        cursor = conn.cursor()
                        
                        cursor.execute("SELECT COUNT(*) FROM customers")
                        total_customers = cursor.fetchone()[0]
                        
                        cursor.execute("SELECT COUNT(*) FROM documents")
                        total_documents = cursor.fetchone()[0]
                        
                        cursor.execute("SELECT COUNT(*) FROM documents WHERE chroma_stored = 1")
                        vectorized_docs = cursor.fetchone()[0]
                        
                        conn.close()
                        
                        # Display stats
                        st.write("**SQLite Database:**")
                        st.write(f"- Customers: {total_customers}")
                        st.write(f"- Documents: {total_documents}")
                        st.write(f"- Vectorized: {vectorized_docs}")
                        
                        # ChromaDB stats
                        chroma_stats = self.db.get_chroma_stats()
                        st.write("**ChromaDB Vector Database:**")
                        st.write(f"- Status: {chroma_stats.get('status', 'unknown')}")
                        st.write(f"- Documents: {chroma_stats.get('document_count', 0)}")
                        
                    except Exception as e:
                        st.error(f"Error loading stats: {str(e)}")
    
    def show_reports(self):
        st.subheader("📈 Compliance Reports with Vector Analytics")
        
        # Report configuration
        st.markdown("### Report Configuration")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            report_type = st.selectbox(
                "Select Report Type",
                ["Verification Summary", "Customer Activity", "Audit Trail", 
                 "Vector Database Stats", "Document Analytics"]
            )
        
        with col2:
            start_date = st.date_input("Start Date", 
                                     value=datetime.date.today() - datetime.timedelta(days=30))
        
        with col3:
            end_date = st.date_input("End Date", value=datetime.date.today())
        
        if st.button("Generate Report", type="primary"):
            with st.spinner("Generating report..."):
                if report_type == "Vector Database Stats":
                    # ChromaDB-specific report
                    chroma_stats = self.db.get_chroma_stats()
                    
                    st.markdown("### 🗄️ ChromaDB Vector Database Report")
                    
                    if chroma_stats.get('status') == 'active':
                        st.success("✅ ChromaDB is Active")
                        
                        # Get more detailed stats
                        try:
                            # Get collection info
                            collection = self.db.chroma_db.collection
                            if collection:
                                count = collection.count()
                                
                                st.write(f"**Collection Name:** {COLLECTION_NAME}")
                                st.write(f"**Total Documents:** {count}")
                                st.write(f"**Storage Path:** {CHROMA_DB_PATH}")
                                st.write(f"**Embedding Model:** all-MiniLM-L6-v2 (384 dimensions)")
                                
                                # Get sample documents
                                results = collection.get(limit=5)
                                if results['ids']:
                                    st.write("**Sample Documents:**")
                                    for i, doc_id in enumerate(results['ids'][:3]):
                                        st.write(f"{i+1}. Document ID: {doc_id}")
                                        if results['metadatas']:
                                            meta = results['metadatas'][i]
                                            st.write(f"   - Customer: {meta.get('customer_id', 'N/A')}")
                                            st.write(f"   - Type: {meta.get('document_type', 'N/A')}")
                        
                        except Exception as e:
                            st.error(f"Error getting ChromaDB details: {str(e)}")
                    
                    else:
                        st.error(f"❌ ChromaDB Status: {chroma_stats.get('status', 'unknown')}")
                
                elif report_type == "Document Analytics":
                    # Document analytics report
                    st.markdown("### 📊 Document Analytics Report")
                    
                    # Get analysis for all documents
                    analysis = self.db.analyze_document_patterns()
                    
                    if analysis and 'error' not in analysis:
                        st.write(f"**Total Documents Analyzed:** {analysis.get('total_documents', 0)}")
                        
                        if analysis.get('document_types'):
                            st.write("**Document Type Distribution:**")
                            
                            # Create dataframe for visualization
                            doc_types = analysis['document_types']
                            df_types = pd.DataFrame({
                                'Document Type': list(doc_types.keys()),
                                'Count': list(doc_types.values())
                            })
                            
                            st.dataframe(df_types, use_container_width=True)
                            
                            # Bar chart
                            import plotly.express as px
                            fig = px.bar(df_types, x='Document Type', y='Count', 
                                       title='Document Type Distribution')
                            st.plotly_chart(fig)
                        
                        # AI-powered insights
                        if st.button("Generate AI Insights", type="secondary"):
                            with st.spinner("AI is analyzing document patterns..."):
                                try:
                                    prompt = f"""
                                    Analyze these document analytics and provide business insights:
                                    
                                    {json.dumps(analysis, indent=2)}
                                    
                                    Provide insights in these areas:
                                    1. Document processing trends
                                    2. Potential optimization opportunities
                                    3. Risk assessment
                                    4. Recommendations for improvement
                                    
                                    Return as a structured report.
                                    """
                                    
                                    response = llm.invoke(prompt)
                                    st.markdown("### 🤖 AI-Generated Insights")
                                    st.write(response.content)
                                    
                                except Exception as e:
                                    st.error(f"AI analysis failed: {str(e)}")
                    
                    else:
                        st.info("No document analytics available.")
                
                else:
                    # Map report type to database query type
                    report_map = {
                        "Verification Summary": "verification_summary",
                        "Customer Activity": "customer_activity", 
                        "Audit Trail": "audit_trail"
                    }
                    
                    db_report_type = report_map[report_type]
                    
                    # Generate report
                    df = self.db.generate_report(
                        db_report_type,
                        start_date.strftime("%Y-%m-%d"),
                        end_date.strftime("%Y-%m-%d")
                    )
                    
                    if not df.empty:
                        # Display report
                        st.markdown(f"### 📊 {report_type} Report")
                        st.dataframe(df, use_container_width=True, height=400)
                        
                        # Summary metrics
                        st.markdown("### 📈 Summary Metrics")
                        
                        if report_type == "Verification Summary":
                            metrics_col1, metrics_col2, metrics_col3, metrics_col4 = st.columns(4)
                            
                            with metrics_col1:
                                total = df['total_uploads'].sum()
                                st.metric("Total Documents", total)
                            
                            with metrics_col2:
                                verified = df['verified'].sum()
                                verification_rate = verified / total if total > 0 else 0
                                st.metric("Verified Documents", f"{verified} ({verification_rate:.1%})")
                            
                            with metrics_col3:
                                vectorized = df['vectorized'].sum()
                                vectorization_rate = vectorized / total if total > 0 else 0
                                st.metric("Vectorized Docs", f"{vectorized} ({vectorization_rate:.1%})")
                            
                            with metrics_col4:
                                avg_conf = df['avg_confidence'].mean()
                                st.metric("Avg Confidence", f"{avg_conf:.1%}")
                        
                        elif report_type == "Customer Activity":
                            metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
                            
                            with metrics_col1:
                                total_customers = len(df)
                                st.metric("Total Customers", total_customers)
                            
                            with metrics_col2:
                                active_customers = df[df['documents_uploaded'] > 0].shape[0]
                                st.metric("Active Customers", active_customers)
                            
                            with metrics_col3:
                                vectorized_customers = df[df['documents_vectorized'] > 0].shape[0]
                                st.metric("Vectorized Customers", vectorized_customers)
                        
                        # Download options
                        st.markdown("---")
                        st.markdown("### 📥 Download Report")
                        
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            # CSV Download
                            csv = df.to_csv(index=False)
                            st.download_button(
                                label="Download CSV",
                                data=csv,
                                file_name=f"kyc_{report_type.lower().replace(' ', '_')}_{datetime.date.today()}.csv",
                                mime="text/csv",
                                use_container_width=True
                            )
                        
                        with col2:
                            # Excel Download
                            excel_buffer = io.BytesIO()
                            with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                                df.to_excel(writer, index=False, sheet_name='Report')
                                writer.close()
                            
                            st.download_button(
                                label="Download Excel",
                                data=excel_buffer.getvalue(),
                                file_name=f"kyc_{report_type.lower().replace(' ', '_')}_{datetime.date.today()}.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                use_container_width=True
                            )
                        
                        with col3:
                            # JSON Download
                            json_str = df.to_json(orient='records', indent=2)
                            st.download_button(
                                label="Download JSON",
                                data=json_str,
                                file_name=f"kyc_{report_type.lower().replace(' ', '_')}_{datetime.date.today()}.json",
                                mime="application/json",
                                use_container_width=True
                            )
                    
                    else:
                        st.info("No data found for the selected criteria.")
    
    def show_audit_trail(self):
        st.subheader("📋 System Audit Trail")
        
        # ChromaDB audit trail option
        include_chroma = st.checkbox("Include ChromaDB Operations", value=True)
        
        # Audit trail filters
        col1, col2, col3 = st.columns(3)
        
        with col1:
            customer_filter = st.text_input("Filter by Customer ID (optional):")
        
        with col2:
            action_filter = st.selectbox(
                "Filter by Action",
                ["All Actions", "REGISTRATION", "DOCUMENT_UPLOAD", 
                 "VERIFICATION", "VECTOR_STORAGE", "STATUS_UPDATE", "REPORT_GENERATION"]
            )
        
        with col3:
            status_filter = st.selectbox(
                "Filter by Status",
                ["All", "SUCCESS", "ERROR", "WARNING"]
            )
        
        # Date range
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input("Start Date", 
                                     value=datetime.date.today() - datetime.timedelta(days=7))
        with col2:
            end_date = st.date_input("End Date", value=datetime.date.today())
        
        if st.button("Load Audit Trail", type="primary"):
            with st.spinner("Loading audit trail..."):
                # Get all logs first
                logs = self.db.get_audit_logs(limit=1000)
                
                # Filter by ChromaDB operations if needed
                if not include_chroma:
                    logs = [log for log in logs if "VECTOR" not in str(log)]
                
                # Convert to DataFrame for filtering
                if logs:
                    if customer_filter:
                        # Filter by customer
                        logs = [log for log in logs if len(log) > 1 and 
                               (customer_filter.upper() in str(log[1]) if log[1] else False)]
                    
                    # Convert to DataFrame
                    if logs and len(logs[0]) == 6:  # With customer_id
                        df = pd.DataFrame(logs, columns=['log_id', 'customer_id', 'action', 
                                                        'details', 'timestamp', 'status'])
                    else:  # Without customer_id
                        df = pd.DataFrame(logs, columns=['log_id', 'action', 'details', 
                                                        'timestamp', 'status'])
                    
                    # Apply filters
                    if action_filter != "All Actions":
                        df = df[df['action'] == action_filter]
                    
                    if status_filter != "All":
                        df = df[df['status'] == status_filter]
                    
                    # Filter by date
                    df['date'] = pd.to_datetime(df['timestamp']).dt.date
                    df = df[(df['date'] >= start_date) & (df['date'] <= end_date)]
                    
                    if not df.empty:
                        # Display audit trail
                        st.markdown(f"### 📋 Audit Trail ({len(df)} entries)")
                        
                        # Group by date
                        df_sorted = df.sort_values('timestamp', ascending=False)
                        
                        for idx, row in df_sorted.iterrows():
                            timestamp = pd.to_datetime(row['timestamp'])
                            time_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
                            
                            status_icon = {
                                "SUCCESS": "✅",
                                "ERROR": "❌",
                                "WARNING": "⚠️"
                            }.get(row['status'], "ℹ️")
                            
                            # Color code ChromaDB operations
                            row_class = ""
                            if "VECTOR" in row['action']:
                                row_class = "vector-result"
                            
                            with st.expander(f"{status_icon} {time_str} - {row['action']}", expanded=False):
                                col1, col2 = st.columns([1, 3])
                                
                                with col1:
                                    st.write(f"**Log ID:** {row['log_id']}")
                                    if 'customer_id' in row:
                                        st.write(f"**Customer:** {row['customer_id']}")
                                    st.write(f"**Status:** {row['status']}")
                                
                                with col2:
                                    st.write(f"**Action:** {row['action']}")
                                    st.write(f"**Details:** {row['details']}")
                        
                        # Statistics
                        st.markdown("---")
                        st.markdown("### 📊 Audit Statistics")
                        
                        stat_col1, stat_col2, stat_col3, stat_col4 = st.columns(4)
                        
                        with stat_col1:
                            total_entries = len(df)
                            st.metric("Total Entries", total_entries)
                        
                        with stat_col2:
                            success_count = df[df['status'] == 'SUCCESS'].shape[0]
                            st.metric("Successful", success_count)
                        
                        with stat_col3:
                            error_count = df[df['status'] == 'ERROR'].shape[0]
                            st.metric("Errors", error_count)
                        
                        with stat_col4:
                            vector_ops = df[df['action'].str.contains('VECTOR', case=False)].shape[0]
                            st.metric("Vector Ops", vector_ops)
                        
                        # Action distribution
                        st.markdown("#### Action Distribution")
                        action_counts = df['action'].value_counts()
                        st.bar_chart(action_counts)
                        
                        # Download audit trail
                        st.markdown("---")
                        st.markdown("### 📥 Download Audit Trail")
                        
                        csv = df.to_csv(index=False)
                        st.download_button(
                            label="Download CSV",
                            data=csv,
                            file_name=f"audit_trail_{datetime.date.today()}.csv",
                            mime="text/csv"
                        )
                    
                    else:
                        st.info("No audit entries found for the selected filters.")
                else:
                    st.info("No audit entries found in the system.")

# ============= MAIN EXECUTION =============
def main():
    # Create necessary directories
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(Config.CHROMA_DB_PATH, exist_ok=True)
    
    # Initialize and run application
    app = KYCApplication()
    app.run()

if __name__ == "__main__":
    main()