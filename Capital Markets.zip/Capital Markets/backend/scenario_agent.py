import json
from typing import List, Dict, Any
from .llm_integration import LLMIntegration, Config
import yfinance as yf
import pandas as pd
from datetime import datetime

class MarketDataFetcher:
    def __init__(self):
        self.cache = {}
    
    def get_stock_data(self, symbol, period="1y"):
        """Fetch stock data from Yahoo Finance"""
        try:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period=period)
            return data
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return None
    
    def get_multiple_stocks(self, symbols, period="1y"):
        """Fetch multiple stock data"""
        data = {}
        for symbol in symbols:
            stock_data = self.get_stock_data(symbol, period)
            if stock_data is not None:
                data[symbol] = stock_data
        return data
    
    def get_market_indices(self):
        """Fetch major market indices"""
        indices = {
            "SPY": "S&P 500",
            "QQQ": "NASDAQ 100", 
            "IWM": "Russell 2000"
        }
        return self.get_multiple_stocks(list(indices.keys()), "1mo")
    
    def get_volatility_data(self):
        """Fetch volatility indices"""
        vix_data = self.get_stock_data("^VIX", "1mo")
        return {"VIX": vix_data}
    
    def get_current_market_snapshot(self) -> Dict[str, Any]:
        """Get current market overview"""
        try:
            spy = yf.Ticker("SPY")
            info = spy.info
            current_price = info.get('regularMarketPrice', 4500)
            previous_close = info.get('regularMarketPreviousClose', 4450)
            change = ((current_price - previous_close) / previous_close) * 100
            
            return {
                "sp500_price": current_price,
                "sp500_change": change,
                "market_sentiment": "Bullish" if change > 0 else "Bearish",
                "timestamp": datetime.now().isoformat()  # Convert to string
            }
        except Exception as e:
            print(f"Error getting market snapshot: {e}")
            return {
                "sp500_price": 4500,
                "sp500_change": 1.2,
                "market_sentiment": "Bullish",
                "timestamp": datetime.now().isoformat()  # Convert to string
            }
    
    def get_current_timestamp(self):
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

class ScenarioAgent:
    def __init__(self):
        self.llm = LLMIntegration()
        self.data_fetcher = MarketDataFetcher()
        self.generated_scenarios = []
    
    def generate_multiple_scenarios(self, scenario_types: List[str], portfolio_type: str, count: int = 3) -> List[Dict[str, Any]]:
        """Generate multiple risk scenarios"""
        
        market_context = self._get_current_market_context()
        scenarios = []
        
        for scenario_type in scenario_types:
            for i in range(count):
                try:
                    scenario = self.llm.generate_scenario(
                        scenario_type, 
                        market_context, 
                        portfolio_type
                    )
                    scenario['id'] = f"{scenario_type.lower().replace(' ', '_')}_{i+1}"
                    scenario['portfolio_type'] = portfolio_type
                    scenario['severity'] = self._assess_scenario_severity(scenario)
                    scenarios.append(scenario)
                    
                    # Add to history
                    self.generated_scenarios.append(scenario)
                except Exception as e:
                    print(f"Error generating scenario {scenario_type}: {e}")
                    # Add fallback scenario if generation fails
                    fallback_scenario = self._get_fallback_scenario(scenario_type, portfolio_type)
                    scenarios.append(fallback_scenario)
                    self.generated_scenarios.append(fallback_scenario)
        
        return scenarios
    
    def _get_current_market_context(self) -> Dict[str, Any]:
        """Get current market context for scenario generation"""
        snapshot = self.data_fetcher.get_current_market_snapshot()
        
        # Ensure all values are JSON serializable
        serializable_snapshot = {}
        if snapshot:
            for key, value in snapshot.items():
                if isinstance(value, datetime):
                    serializable_snapshot[key] = value.isoformat()
                else:
                    serializable_snapshot[key] = value
        
        return {
            "market_snapshot": serializable_snapshot,
            "volatility_trend": "Rising" if snapshot and snapshot.get('sp500_change', 0) < -1 else "Stable",
            "market_sentiment": snapshot.get('market_sentiment', 'Neutral') if snapshot else 'Neutral',
            "analysis_timestamp": self.data_fetcher.get_current_timestamp()
        }
    
    def _assess_scenario_severity(self, scenario: Dict[str, Any]) -> str:
        """Assess scenario severity based on content"""
        risk_metrics = scenario.get('risk_metrics', {})
        
        var_estimate = str(risk_metrics.get('var_95', '15-25%')).lower()
        
        # Assess based on VaR
        if any(term in var_estimate for term in ['30', '35', '40', '45', '50']):
            return "High"
        elif any(term in var_estimate for term in ['20', '25']):
            return "Medium"
        else:
            return "Low"
    
    def _get_fallback_scenario(self, scenario_type: str, portfolio_type: str) -> Dict[str, Any]:
        """Create a fallback scenario when generation fails"""
        return {
            "scenario_type": scenario_type,
            "portfolio_type": portfolio_type,
            "scenario_overview": f"Fallback analysis of {scenario_type} risk scenario for {portfolio_type} portfolio.",
            "market_context": "Market experiencing stress conditions with elevated volatility.",
            "timeline": "Event progression over 2-4 weeks",
            "portfolio_impact": f"Potential significant impact on {portfolio_type} portfolio requiring active risk management.",
            "risk_metrics": {
                "var_95": "15-25%",
                "expected_shortfall": "20-30%",
                "volatility_spike": "2-3x normal levels",
                "liquidity_impact": "Medium"
            },
            "mitigation_strategies": [
                "Increase cash positions to 5-10%",
                "Review and adjust asset allocation",
                "Implement basic hedging strategies",
                "Maintain adequate liquidity buffers"
            ],
            "monitoring_indicators": [
                "VIX levels above 20",
                "Credit spread widening",
                "Market liquidity indicators"
            ],
            "generated_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "model_used": Config.LANGCHAIN_MODEL,
            "severity": "Medium",
            "fallback_used": True
        }
    
    def get_scenario_history(self) -> List[Dict[str, Any]]:
        """Get history of generated scenarios"""
        return self.generated_scenarios
    
    def test_llm_connection(self):
        """Test LLM connection"""
        return self.llm.test_connection()
    

    