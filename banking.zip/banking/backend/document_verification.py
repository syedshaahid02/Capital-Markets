"""
Document Verification with AI-powered invalid upload detection
"""
import os
from typing import Dict, List, Optional
import logging
from .models import VerificationResult
from .ai_model_client import AIModelClient
from .ocr_processor import OCRProcessor
from .database import SessionLocal, AuditLog

logger = logging.getLogger(__name__)

class DocumentVerification:
    def __init__(self):
        self.ocr_processor = OCRProcessor()
        self.ai_client = AIModelClient()
        self.allowed_extensions = {'jpg', 'jpeg', 'png', 'pdf'}
    
    def verify_document(self, document_type: str, file_data: bytes, 
                       filename: str, customer_id: int) -> VerificationResult:
        """Verify document with AI-powered invalid upload detection"""
        
        # Step 1: Basic file validation
        file_check = self._validate_file_basic(file_data, filename)
        if not file_check['is_valid']:
            return VerificationResult(
                is_valid=False,
                message=file_check['message'],
                extracted_data={'validation_result': file_check},
                issues=file_check.get('issues', [])
            )
        
        # Step 2: Use AI to detect invalid uploads
        ai_result = self.ai_client.analyze_document(file_data, filename, document_type)
        
        # Step 3: Check if AI says it's invalid
        if not ai_result.get('is_valid', False):
            rejection_reason = ai_result.get('rejection_reason', 'Document verification failed')
            what_is_it = ai_result.get('what_is_it', 'unknown')
            
            # Create clear rejection message
            if 'animal' in what_is_it.lower() or 'cat' in what_is_it.lower() or 'dog' in what_is_it.lower():
                message = f"❌ This appears to be an animal photo, not a {document_type.replace('_', ' ')}"
            elif 'chair' in what_is_it.lower() or 'furniture' in what_is_it.lower():
                message = f"❌ This appears to be furniture, not a {document_type.replace('_', ' ')}"
            elif 'blank' in what_is_it.lower():
                message = "❌ File appears to be blank or empty"
            elif 'blurry' in what_is_it.lower():
                message = "❌ Image is too blurry to read"
            else:
                message = f"❌ {rejection_reason}"
            
            return VerificationResult(
                is_valid=False,
                message=message,
                extracted_data={'ai_analysis': ai_result},
                issues=ai_result.get('issues', []) + [rejection_reason]
            )
        
        # Step 4: If AI says it's valid, do OCR extraction
        extracted_text = ""
        if document_type != 'photo':  # Don't OCR photos
            extracted_text = self.ocr_processor.process_document(file_data, filename)
        
        # Step 5: Validate based on document type
        validation_result = {}
        if document_type == 'id_proof':
            validation_result = self.ocr_processor.validate_id_proof(extracted_text)
        elif document_type == 'address_proof':
            validation_result = self.ocr_processor.validate_address_proof(extracted_text)
        elif document_type == 'photo':
            # For photos, rely on AI validation
            validation_result = {
                'is_valid': ai_result.get('is_valid', False),
                'is_person': ai_result.get('is_person', False),
                'issues': ai_result.get('issues', [])
            }
        
        # Step 6: Combine results
        is_valid = ai_result.get('is_valid', False) and validation_result.get('is_valid', False)
        
        # Create final result
        final_extracted_data = {
            'ai_result': ai_result,
            'ocr_result': validation_result if document_type != 'photo' else {},
            'what_was_uploaded': ai_result.get('what_is_it', 'document'),
            'confidence': ai_result.get('confidence', 0.0)
        }
        
        # Create message based on what was detected
        if is_valid:
            if document_type == 'photo':
                message = "✅ Valid passport photo uploaded"
            else:
                message = f"✅ Valid {document_type.replace('_', ' ')} uploaded"
        else:
            message = ai_result.get('rejection_reason', 'Document verification failed')
        
        result = VerificationResult(
            is_valid=is_valid,
            message=message,
            extracted_data=final_extracted_data,
            issues=ai_result.get('issues', []) + validation_result.get('issues', [])
        )
        
        # Log the verification
        self._log_verification(customer_id, document_type, is_valid, 
                             ai_result.get('what_is_it', 'document'))
        
        return result
    
    def _validate_file_basic(self, file_data: bytes, filename: str) -> Dict:
        """Basic file validation"""
        issues = []
        
        # Check file extension
        file_ext = filename.split('.')[-1].lower()
        if file_ext not in self.allowed_extensions:
            issues.append(f"Invalid file type. Allowed: {', '.join(self.allowed_extensions)}")
            return {
                'is_valid': False,
                'message': f"Invalid file type: .{file_ext}",
                'issues': issues
            }
        
        # Check file size (5MB limit)
        file_size_mb = len(file_data) / (1024 * 1024)
        if file_size_mb > 5:
            issues.append(f"File size {file_size_mb:.1f}MB exceeds 5MB limit")
            return {
                'is_valid': False,
                'message': f"File too large: {file_size_mb:.1f}MB > 5MB",
                'issues': issues
            }
        
        # Check if file is empty
        if len(file_data) < 100:
            issues.append("File appears to be empty or corrupted")
            return {
                'is_valid': False,
                'message': "File appears to be empty or corrupted",
                'issues': issues
            }
        
        return {
            'is_valid': True,
            'message': "File validation passed",
            'issues': issues
        }
    
    def _log_verification(self, customer_id: int, document_type: str, 
                         is_valid: bool, what_was_it: str):
        """Log verification attempt"""
        db = SessionLocal()
        try:
            details = f"Verified {document_type}: {'valid' if is_valid else 'invalid'} ({what_was_it})"
            audit_log = AuditLog(
                customer_id=customer_id,
                action=f"document_verification_{document_type}",
                details=details,
                created_at=datetime.utcnow()
            )
            db.add(audit_log)
            db.commit()
        except Exception as e:
            logger.error(f"Error logging verification: {e}")
            db.rollback()
        finally:
            db.close()