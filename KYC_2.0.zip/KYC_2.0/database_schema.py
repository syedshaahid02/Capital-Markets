import sqlite3
import streamlit as st
import pandas as pd
import json
import io
from datetime import datetime

# ============= AI CONNECTION =============
from langchain_openai import ChatOpenAI
import httpx 
import os

# Configure AI client
client = httpx.Client(verify=False)
llm = ChatOpenAI(
    base_url='https://genailab.tcs.in',
    model='azure_ai/genailab-maas-DeepSeek-V3-0324',
    api_key='sk-J-1Za6zC1-ak3xnF0PfFRw',  # Add your API key here
    http_client=client,
    temperature=0.1,
    max_tokens=2000
)

class DatabaseSchema:
    def __init__(self, db_path="kyc_database.db"):
        self.db_path = db_path
        self.llm = llm
        self.schema = self.get_schema_definition()
    
    def get_schema_definition(self):
        """Define complete database schema with ChromaDB integration"""
        return {
            "database_name": "kyc_verification_db",
            "version": "3.0",
            "description": "Database for AI-Powered KYC Document Verification System with ChromaDB Vector Storage",
            "ai_integration": "DeepSeek-V3 via TCS GenAILab",
            "vector_database": "ChromaDB with SentenceTransformer embeddings",
            "tables": {
                "customers": {
                    "description": "Stores customer registration information with AI verification tracking",
                    "columns": [
                        {"name": "customer_id", "type": "TEXT", "primary_key": True, 
                         "description": "Unique AI-generated customer identifier", "nullable": False},
                        {"name": "full_name", "type": "TEXT", "description": "Customer full name validated by AI"},
                        {"name": "email", "type": "TEXT", "unique": True, 
                         "description": "Email address for communication and login"},
                        {"name": "phone", "type": "TEXT", "description": "Phone number for OTP and alerts"},
                        {"name": "date_of_birth", "type": "TEXT", 
                         "description": "Date of birth extracted from ID documents"},
                        {"name": "nationality", "type": "TEXT", 
                         "description": "Nationality from registration"},
                        {"name": "registration_date", "type": "TEXT", 
                         "description": "Timestamp of customer registration"},
                        {"name": "kyc_status", "type": "TEXT", "default": "PENDING", 
                         "description": "Overall KYC status determined by AI analysis"},
                        {"name": "ai_confidence", "type": "REAL", "default": 0.0,
                         "description": "Overall AI confidence score for customer verification"},
                        {"name": "vector_documents_count", "type": "INTEGER", "default": 0,
                         "description": "Number of documents stored in ChromaDB for this customer"},
                        {"name": "created_at", "type": "TEXT", 
                         "description": "Record creation timestamp"},
                        {"name": "updated_at", "type": "TEXT", 
                         "description": "Last update timestamp"}
                    ],
                    "indexes": [
                        "CREATE INDEX idx_customers_email ON customers(email)",
                        "CREATE INDEX idx_customers_status ON customers(kyc_status)",
                        "CREATE INDEX idx_customers_ai_confidence ON customers(ai_confidence)",
                        "CREATE INDEX idx_customers_vector_count ON customers(vector_documents_count)"
                    ],
                    "chroma_integration": "Customer documents stored as vectors in ChromaDB collection"
                },
                "documents": {
                    "description": "Stores uploaded KYC documents and AI verification results with ChromaDB linkage",
                    "columns": [
                        {"name": "document_id", "type": "TEXT", "primary_key": True, 
                         "description": "Unique AI-processed document identifier, also used as ChromaDB ID"},
                        {"name": "customer_id", "type": "TEXT", "foreign_key": "customers(customer_id)",
                         "description": "Reference to customer, validated by AI"},
                        {"name": "document_type", "type": "TEXT", 
                         "description": "Type of document (ID, Address, Photo) classified by AI"},
                        {"name": "file_name", "type": "TEXT", "description": "Original file name"},
                        {"name": "file_path", "type": "TEXT", "description": "Secure storage path"},
                        {"name": "file_size", "type": "INTEGER", "description": "File size in bytes"},
                        {"name": "file_hash", "type": "TEXT", "description": "SHA-256 hash for integrity check"},
                        {"name": "upload_timestamp", "type": "TEXT", "description": "Upload timestamp"},
                        {"name": "verification_status", "type": "TEXT", "default": "PENDING",
                         "description": "AI-determined verification status"},
                        {"name": "ai_confidence", "type": "REAL", "default": 0.0,
                         "description": "AI confidence score (0-1) for document verification"},
                        {"name": "extracted_text", "type": "TEXT", 
                         "description": "Text extracted from document for ChromaDB vectorization"},
                        {"name": "extracted_data", "type": "TEXT", 
                         "description": "JSON with AI-extracted information and analysis"},
                        {"name": "verified_by", "type": "TEXT", "default": "AI_SYSTEM",
                         "description": "Who verified (AI_SYSTEM/MANUAL_REVIEW/ADMIN)"},
                        {"name": "verification_date", "type": "TEXT", 
                         "description": "Timestamp of AI verification"},
                        {"name": "rejection_reason", "type": "TEXT", 
                         "description": "AI-generated rejection reason if applicable"},
                        {"name": "chroma_stored", "type": "INTEGER", "default": 0,
                         "description": "Flag indicating if document is stored in ChromaDB (1=yes, 0=no)"},
                        {"name": "chroma_collection", "type": "TEXT", "default": "kyc_documents",
                         "description": "ChromaDB collection name where vector is stored"},
                        {"name": "embedding_model", "type": "TEXT", "default": "all-MiniLM-L6-v2",
                         "description": "Model used for generating document embeddings"},
                        {"name": "vector_dimension", "type": "INTEGER", "default": 384,
                         "description": "Dimension of the document vector embedding"},
                        {"name": "processing_time_ms", "type": "INTEGER",
                         "description": "Total processing time including vectorization"}
                    ],
                    "indexes": [
                        "CREATE INDEX idx_documents_customer ON documents(customer_id)",
                        "CREATE INDEX idx_documents_status ON documents(verification_status)",
                        "CREATE INDEX idx_documents_type ON documents(document_type)",
                        "CREATE INDEX idx_documents_ai_confidence ON documents(ai_confidence)",
                        "CREATE INDEX idx_documents_chroma ON documents(chroma_stored)",
                        "CREATE INDEX idx_documents_upload_time ON documents(upload_timestamp)"
                    ],
                    "chroma_integration": {
                        "vector_storage": "Document text converted to embeddings in ChromaDB",
                        "search_capability": "Enables semantic search and similarity analysis",
                        "metadata_linkage": "SQLite metadata linked to ChromaDB vectors",
                        "sync_mechanism": "Automatic synchronization between SQLite and ChromaDB"
                    }
                },
                "vector_searches": {
                    "description": "Tracks vector search operations and results from ChromaDB",
                    "columns": [
                        {"name": "search_id", "type": "TEXT", "primary_key": True,
                         "description": "Unique search operation identifier"},
                        {"name": "customer_id", "type": "TEXT", 
                         "foreign_key": "customers(customer_id)", "description": "Customer who initiated search"},
                        {"name": "query_text", "type": "TEXT", 
                         "description": "Text query used for vector search"},
                        {"name": "search_type", "type": "TEXT", 
                         "description": "Type of search (semantic, similarity, customer)"},
                        {"name": "results_count", "type": "INTEGER", 
                         "description": "Number of results returned"},
                        {"name": "avg_similarity", "type": "REAL", 
                         "description": "Average similarity score of results"},
                        {"name": "search_timestamp", "type": "TEXT", 
                         "description": "When search was performed"},
                        {"name": "response_time_ms", "type": "INTEGER",
                         "description": "Time taken for vector search"},
                        {"name": "chroma_collection", "type": "TEXT", 
                         "description": "ChromaDB collection searched"},
                        {"name": "search_results", "type": "TEXT", 
                         "description": "JSON array of search results with document IDs and scores"}
                    ],
                    "indexes": [
                        "CREATE INDEX idx_searches_customer ON vector_searches(customer_id)",
                        "CREATE INDEX idx_searches_timestamp ON vector_searches(search_timestamp)",
                        "CREATE INDEX idx_searches_type ON vector_searches(search_type)"
                    ],
                    "chroma_integration": "Logs all ChromaDB search operations for audit and analytics"
                },
                "document_similarity": {
                    "description": "Stores document similarity analysis results from ChromaDB",
                    "columns": [
                        {"name": "similarity_id", "type": "TEXT", "primary_key": True,
                         "description": "Unique similarity analysis identifier"},
                        {"name": "document1_id", "type": "TEXT", 
                         "foreign_key": "documents(document_id)", "description": "First document"},
                        {"name": "document2_id", "type": "TEXT", 
                         "foreign_key": "documents(document_id)", "description": "Second document"},
                        {"name": "customer_id", "type": "TEXT", 
                         "foreign_key": "customers(customer_id)", "description": "Customer owning documents"},
                        {"name": "similarity_score", "type": "REAL", 
                         "description": "Cosine similarity score between document vectors"},
                        {"name": "similarity_type", "type": "TEXT", 
                         "description": "Type of similarity (intra-customer, inter-customer, cross-type)"},
                        {"name": "analysis_date", "type": "TEXT", 
                         "description": "When similarity was calculated"},
                        {"name": "is_anomaly", "type": "INTEGER", "default": 0,
                         "description": "Flag for anomaly detection (1=anomaly, 0=normal)"},
                        {"name": "anomaly_reason", "type": "TEXT", 
                         "description": "Reason if marked as anomaly"},
                        {"name": "ai_notes", "type": "TEXT", 
                         "description": "AI-generated notes about similarity"}
                    ],
                    "indexes": [
                        "CREATE INDEX idx_similarity_doc1 ON document_similarity(document1_id)",
                        "CREATE INDEX idx_similarity_doc2 ON document_similarity(document2_id)",
                        "CREATE INDEX idx_similarity_customer ON document_similarity(customer_id)",
                        "CREATE INDEX idx_similarity_score ON document_similarity(similarity_score)",
                        "CREATE INDEX idx_similarity_anomaly ON document_similarity(is_anomaly)"
                    ],
                    "chroma_integration": "Uses ChromaDB vector distances to calculate document similarities"
                },
                "chroma_collections": {
                    "description": "Tracks ChromaDB collections and their metadata",
                    "columns": [
                        {"name": "collection_id", "type": "TEXT", "primary_key": True,
                         "description": "Unique collection identifier"},
                        {"name": "collection_name", "type": "TEXT", "unique": True,
                         "description": "ChromaDB collection name"},
                        {"name": "description", "type": "TEXT", 
                         "description": "Collection description and purpose"},
                        {"name": "embedding_model", "type": "TEXT", 
                         "description": "Embedding model used for this collection"},
                        {"name": "vector_dimension", "type": "INTEGER", 
                         "description": "Dimension of vectors in this collection"},
                        {"name": "document_count", "type": "INTEGER", "default": 0,
                         "description": "Number of documents/vectors in collection"},
                        {"name": "created_date", "type": "TEXT", 
                         "description": "When collection was created"},
                        {"name": "last_updated", "type": "TEXT", 
                         "description": "When collection was last updated"},
                        {"name": "is_active", "type": "INTEGER", "default": 1,
                         "description": "Whether collection is active (1/0)"},
                        {"name": "metadata_schema", "type": "TEXT", 
                         "description": "JSON schema for collection metadata"},
                        {"name": "performance_metrics", "type": "TEXT", 
                         "description": "JSON with collection performance metrics"}
                    ],
                    "indexes": [
                        "CREATE INDEX idx_collections_name ON chroma_collections(collection_name)",
                        "CREATE INDEX idx_collections_active ON chroma_collections(is_active)",
                        "CREATE INDEX idx_collections_count ON chroma_collections(document_count)"
                    ],
                    "chroma_integration": "Manages ChromaDB collections and tracks their usage"
                }
            },
            "relationships": [
                {
                    "from": "documents",
                    "to": "customers",
                    "type": "many-to-one",
                    "on": "documents.customer_id = customers.customer_id",
                    "description": "Multiple documents belong to one customer, stored in ChromaDB as vectors"
                },
                {
                    "from": "vector_searches",
                    "to": "customers", 
                    "type": "many-to-one",
                    "on": "vector_searches.customer_id = customers.customer_id",
                    "description": "Multiple vector searches can be performed per customer"
                },
                {
                    "from": "document_similarity",
                    "to": "documents",
                    "type": "many-to-many",
                    "on": "document_similarity.document1_id = documents.document_id OR document_similarity.document2_id = documents.document_id",
                    "description": "Similarity relationships between documents based on ChromaDB vectors"
                }
            ],
            "chroma_db_schema": {
                "collection_structure": {
                    "name": "kyc_documents",
                    "embedding_function": "SentenceTransformer('all-MiniLM-L6-v2')",
                    "metadata_schema": {
                        "customer_id": "TEXT",
                        "document_type": "TEXT",
                        "document_id": "TEXT",
                        "upload_timestamp": "TIMESTAMP",
                        "verification_status": "TEXT",
                        "ai_confidence": "FLOAT",
                        "file_name": "TEXT",
                        "file_type": "TEXT"
                    },
                    "index_type": "HNSW",
                    "distance_metric": "cosine"
                },
                "collections": [
                    {
                        "name": "kyc_documents",
                        "purpose": "Main document vector storage",
                        "expected_size": "100K-1M vectors",
                        "retention_policy": "7 years minimum"
                    },
                    {
                        "name": "customer_profiles",
                        "purpose": "Customer profile embeddings",
                        "expected_size": "10K-100K vectors",
                        "retention_policy": "Indefinite"
                    },
                    {
                        "name": "fraud_patterns",
                        "purpose": "Known fraud pattern embeddings",
                        "expected_size": "1K-10K vectors",
                        "retention_policy": "Indefinite"
                    }
                ]
            },
            "data_dictionary": {
                "status_codes": {
                    "KYC_STATUS": {
                        "PENDING": "Initial state after registration",
                        "DOCUMENTS_UPLOADED": "All documents uploaded, awaiting AI analysis",
                        "AI_ANALYSIS": "AI is analyzing documents",
                        "UNDER_REVIEW": "Documents being verified by AI and vector analysis",
                        "VECTOR_STORED": "Documents stored in ChromaDB as vectors",
                        "VERIFIED": "All documents AI-verified with vector consistency",
                        "REJECTED": "Documents AI-rejected or vector anomaly detected",
                        "COMPLETED": "KYC process completed with vector audit trail"
                    },
                    "CHROMA_STATUS": {
                        "NOT_STORED": "Document not in ChromaDB",
                        "VECTORIZED": "Document stored as vector embedding",
                        "INDEXED": "Vector indexed for fast search",
                        "ERROR": "Vector storage error"
                    }
                },
                "similarity_thresholds": {
                    "VERY_HIGH_SIMILARITY": "0.9-1.0: Likely duplicate or template document",
                    "HIGH_SIMILARITY": "0.7-0.89: Strong similarity, consistent information",
                    "MEDIUM_SIMILARITY": "0.5-0.69: Moderate similarity, typical for same customer",
                    "LOW_SIMILARITY": "0.3-0.49: Low similarity, may need review",
                    "VERY_LOW_SIMILARITY": "0.0-0.29: Very different, potential anomaly"
                }
            }
        }
    
    def display_schema_ui(self):
        """Display database schema in Streamlit UI"""
        st.title("🗄️ Dual Database Schema: SQLite + ChromaDB")
        st.subheader("KYC Verification System with Vector Database Integration")
        
        # Tabs for different views
        tabs = st.tabs([
            "Architecture Overview", "SQLite Schema", "ChromaDB Schema",
            "Integration Design", "SQL Scripts", "Test Data"
        ])
        
        with tabs[0]:
            self.display_architecture_overview()
        
        with tabs[1]:
            self.display_sqlite_schema()
        
        with tabs[2]:
            self.display_chromadb_schema()
        
        with tabs[3]:
            self.display_integration_design()
        
        with tabs[4]:
            self.display_sql_scripts()
        
        with tabs[5]:
            self.display_test_data()
    
    def display_architecture_overview(self):
        """Display dual database architecture"""
        st.header("🏗️ Dual Database Architecture")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📊 SQLite Database")
            st.info("""
            **Purpose:** Structured data storage
            **Tables:** 5 core tables
            **Data Types:** Structured, transactional
            **Use Cases:**
            - Customer registration
            - Document metadata
            - Audit trails
            - Process tracking
            - Reports and analytics
            """)
            
            # SQLite stats
            sqlite_stats = {
                "Total Tables": len(self.schema["tables"]),
                "Total Columns": sum(len(table["columns"]) for table in self.schema["tables"].values()),
                "Vector-linked Tables": sum(1 for table in self.schema["tables"].values() 
                                          if table.get("chroma_integration")),
                "Foreign Keys": len(self.schema["relationships"])
            }
            
            for key, value in sqlite_stats.items():
                st.metric(key, value)
        
        with col2:
            st.subheader("🗄️ ChromaDB Vector Database")
            st.info("""
            **Purpose:** Vector embeddings & semantic search
            **Collections:** 3 main collections
            **Data Types:** Unstructured, vector embeddings
            **Use Cases:**
            - Document similarity search
            - Semantic document retrieval
            - Fraud pattern detection
            - Anomaly detection
            - Customer clustering
            """)
            
            # ChromaDB stats
            chroma_stats = self.schema.get("chroma_db_schema", {})
            if chroma_stats.get("collections"):
                st.write(f"**Collections:** {len(chroma_stats['collections'])}")
                st.write(f"**Embedding Model:** {chroma_stats.get('collection_structure', {}).get('embedding_function', 'N/A')}")
                st.write(f"**Vector Dimension:** 384")
                st.write(f"**Distance Metric:** {chroma_stats.get('collection_structure', {}).get('distance_metric', 'cosine')}")
        
        # Integration diagram
        st.markdown("---")
        st.subheader("🔗 Integration Flow")
        
        st.code("""
        Data Flow: SQLite ↔ ChromaDB
        
        1. Document Upload → SQLite (metadata) + ChromaDB (vector)
        2. AI Processing → Updates both databases
        3. Search Query → ChromaDB (vector search) → SQLite (metadata join)
        4. Analytics → Combined query from both databases
        5. Audit Trail → SQLite (operations) + ChromaDB (search logs)
        """)
    
    def display_sqlite_schema(self):
        """Display SQLite schema details"""
        st.header("📊 SQLite Database Schema")
        
        table_choice = st.selectbox(
            "Select SQLite Table",
            list(self.schema["tables"].keys())
        )
        
        if table_choice:
            table_def = self.schema["tables"][table_choice]
            
            st.subheader(f"Table: {table_choice}")
            st.write(f"**Description:** {table_def['description']}")
            
            # ChromaDB integration info
            if table_def.get("chroma_integration"):
                st.success("🔗 **ChromaDB Integrated**")
                if isinstance(table_def["chroma_integration"], dict):
                    for key, value in table_def["chroma_integration"].items():
                        st.write(f"**{key.replace('_', ' ').title()}:** {value}")
                else:
                    st.write(f"**Integration:** {table_def['chroma_integration']}")
            
            # Columns table
            st.markdown("### Columns")
            columns_data = []
            for col in table_def["columns"]:
                columns_data.append({
                    "Column Name": col["name"],
                    "Data Type": col["type"],
                    "Primary Key": "✅" if col.get("primary_key") else "",
                    "Foreign Key": col.get("foreign_key", ""),
                    "Nullable": "✅" if col.get("nullable") != False else "❌",
                    "Default": col.get("default", ""),
                    "Description": col.get("description", "")
                })
            
            df_columns = pd.DataFrame(columns_data)
            st.dataframe(df_columns, use_container_width=True)
            
            # Indexes
            if table_def.get("indexes"):
                st.markdown("### Indexes")
                for idx in table_def["indexes"]:
                    st.code(idx, language="sql")
    
    def display_chromadb_schema(self):
        """Display ChromaDB schema"""
        st.header("🗄️ ChromaDB Vector Database Schema")
        
        chroma_schema = self.schema.get("chroma_db_schema", {})
        
        # Collection structure
        if chroma_schema.get("collection_structure"):
            st.subheader("Main Collection Structure")
            collection = chroma_schema["collection_structure"]
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write(f"**Collection Name:** {collection.get('name', 'N/A')}")
                st.write(f"**Embedding Function:** {collection.get('embedding_function', 'N/A')}")
                st.write(f"**Distance Metric:** {collection.get('distance_metric', 'N/A')}")
                st.write(f"**Index Type:** {collection.get('index_type', 'N/A')}")
            
            with col2:
                if collection.get("metadata_schema"):
                    st.write("**Metadata Schema:**")
                    for field, dtype in collection["metadata_schema"].items():
                        st.write(f"- {field}: {dtype}")
        
        # Collections list
        if chroma_schema.get("collections"):
            st.subheader("Collections")
            
            for collection in chroma_schema["collections"]:
                with st.expander(f"{collection.get('name', 'Unnamed')} - {collection.get('purpose', '')}"):
                    st.write(f"**Purpose:** {collection.get('purpose', 'N/A')}")
                    st.write(f"**Expected Size:** {collection.get('expected_size', 'N/A')}")
                    st.write(f"**Retention Policy:** {collection.get('retention_policy', 'N/A')}")
                    
                    # Sample data structure
                    if collection["name"] == "kyc_documents":
                        st.write("**Sample Document Structure:**")
                        st.json({
                            "id": "DOC12345",
                            "embedding": "[0.1, 0.2, ..., 0.384]",
                            "metadata": {
                                "customer_id": "CUST001",
                                "document_type": "ID Proof",
                                "document_id": "DOC12345",
                                "upload_timestamp": "2024-01-15T10:30:00Z",
                                "verification_status": "VERIFIED",
                                "ai_confidence": 0.92,
                                "file_name": "passport.jpg",
                                "file_type": "image/jpeg"
                            },
                            "document": "Extracted text from document..."
                        })
        
        # Vector operations
        st.subheader("🔍 Vector Operations")
        
        operations = [
            ("Add Document", "Add document text as vector embedding with metadata"),
            ("Query Similar", "Find similar documents using vector similarity"),
            ("Get by ID", "Retrieve specific document vector by ID"),
            ("Update Metadata", "Update metadata for existing vector"),
            ("Delete Document", "Remove document vector from collection"),
            ("Collection Stats", "Get statistics about collection"),
            ("Similarity Analysis", "Calculate similarity between documents")
        ]
        
        for op_name, op_desc in operations:
            st.write(f"**{op_name}:** {op_desc}")
    
    def display_integration_design(self):
        """Display integration design between SQLite and ChromaDB"""
        st.header("🔗 SQLite + ChromaDB Integration Design")
        
        # Integration patterns
        st.subheader("Integration Patterns")
        
        patterns = [
            {
                "pattern": "Metadata + Vector Storage",
                "description": "Store structured data in SQLite, vectors in ChromaDB",
                "example": "Document metadata in SQLite, document embeddings in ChromaDB"
            },
            {
                "pattern": "Dual Write",
                "description": "Write to both databases transactionally",
                "example": "Document upload → SQLite record + ChromaDB vector"
            },
            {
                "pattern": "Query Joining",
                "description": "Join SQLite metadata with ChromaDB search results",
                "example": "Vector search in ChromaDB → Join with SQLite for details"
            },
            {
                "pattern": "Sync Validation",
                "description": "Validate data consistency between databases",
                "example": "Check document count matches between SQLite and ChromaDB"
            }
        ]
        
        for pattern in patterns:
            with st.expander(f"📋 {pattern['pattern']}"):
                st.write(f"**Description:** {pattern['description']}")
                st.write(f"**Example:** {pattern['example']}")
        
        # Data flow diagram
        st.subheader("📊 Data Flow Diagram")
        
        st.code("""
        ┌─────────────────┐    ┌─────────────────┐
        │   Document      │    │    SQLite       │
        │    Upload       │───▶│   Database      │
        └─────────────────┘    └─────────────────┘
                │                       │
                ▼                       ▼
        ┌─────────────────┐    ┌─────────────────┐
        │   AI Processing │    │  ChromaDB       │
        │   & OCR         │───▶│  Vector DB      │
        └─────────────────┘    └─────────────────┘
                │                       │
                ▼                       ▼
        ┌─────────────────┐    ┌─────────────────┐
        │   Verification  │◀───│   Combined      │
        │   & Analysis    │    │   Query Results │
        └─────────────────┘    └─────────────────┘
        """)
        
        # Integration code example
        st.subheader("💻 Integration Code Example")
        
        integration_code = """
        # Example: Document upload with dual database storage
        def upload_document_with_vectors(customer_id, document_data, extracted_text):
            # 1. Generate unique IDs
            document_id = generate_document_id()
            
            # 2. Store in SQLite (metadata)
            sqlite_cursor.execute('''
                INSERT INTO documents 
                (document_id, customer_id, document_type, file_name, 
                 file_path, file_size, extracted_text, chroma_stored)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (document_id, customer_id, document_data['type'], 
                  document_data['name'], document_data['path'], 
                  document_data['size'], extracted_text, 0))
            
            # 3. Generate and store vector in ChromaDB
            embedding = embedding_model.encode(extracted_text).tolist()
            
            chroma_collection.add(
                ids=[document_id],
                embeddings=[embedding],
                metadatas=[{
                    'customer_id': customer_id,
                    'document_type': document_data['type'],
                    'document_id': document_id,
                    'upload_timestamp': datetime.now().isoformat()
                }],
                documents=[extracted_text[:10000]]
            )
            
            # 4. Update SQLite with ChromaDB status
            sqlite_cursor.execute('''
                UPDATE documents SET chroma_stored = 1 WHERE document_id = ?
            ''', (document_id,))
            
            return document_id
        """
        
        st.code(integration_code, language="python")
    
    def display_sql_scripts(self):
        """Display SQL scripts for setup"""
        st.header("💾 Database Setup Scripts")
        
        # Generate complete SQL script
        sql_script = self.generate_complete_sql()
        
        st.subheader("Complete SQLite Schema")
        st.code(sql_script, language="sql", line_numbers=True)
        
        # Download option
        st.download_button(
            label="📥 Download SQL Script",
            data=sql_script,
            file_name="kyc_dual_database_schema.sql",
            mime="text/sql"
        )
        
        # ChromaDB setup script
        st.subheader("ChromaDB Setup Script")
        
        chroma_script = """
        # ChromaDB setup for KYC system
        import chromadb
        from chromadb.config import Settings
        from sentence_transformers import SentenceTransformer
        
        # Initialize ChromaDB client
        chroma_client = chromadb.PersistentClient(
            path='chroma_db',
            settings=Settings(anonymized_telemetry=False)
        )
        
        # Initialize embedding model
        embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Create main collection
        collection = chroma_client.get_or_create_collection(
            name='kyc_documents',
            metadata={"hnsw:space": "cosine"}
        )
        
        # Create customer profiles collection
        customer_collection = chroma_client.get_or_create_collection(
            name='customer_profiles',
            metadata={"hnsw:space": "cosine"}
        )
        
        # Create fraud patterns collection
        fraud_collection = chroma_client.get_or_create_collection(
            name='fraud_patterns',
            metadata={"hnsw:space": "cosine"}
        )
        
        print("ChromaDB setup completed successfully!")
        print(f"Collections created: {chroma_client.list_collections()}")
        """
        
        st.code(chroma_script, language="python")
        
        # Sample queries
        st.subheader("🔍 Sample Dual Database Queries")
        
        sample_queries = {
            "Find Similar Documents with Metadata": """
            -- Step 1: Vector search in ChromaDB
            -- (Python code would handle this part)
            
            -- Step 2: Join with SQLite for metadata
            SELECT d.document_id, d.document_type, d.verification_status,
                   d.ai_confidence, c.full_name, c.email,
                   vs.similarity_score
            FROM documents d
            JOIN customers c ON d.customer_id = c.customer_id
            JOIN vector_searches vs ON d.document_id IN (:document_ids)
            WHERE d.document_id IN (:document_ids)
            ORDER BY vs.similarity_score DESC;
            """,
            
            "Customer Document Analysis": """
            -- Get customer's documents with vector storage status
            SELECT 
                c.customer_id,
                c.full_name,
                COUNT(d.document_id) as total_documents,
                SUM(CASE WHEN d.chroma_stored = 1 THEN 1 ELSE 0 END) as vectorized_docs,
                AVG(d.ai_confidence) as avg_confidence,
                MAX(d.upload_timestamp) as last_upload
            FROM customers c
            LEFT JOIN documents d ON c.customer_id = d.customer_id
            WHERE c.customer_id = :customer_id
            GROUP BY c.customer_id, c.full_name;
            """,
            
            "Vector Search Analytics": """
            -- Analyze vector search patterns
            SELECT 
                DATE(search_timestamp) as search_date,
                search_type,
                COUNT(*) as search_count,
                AVG(response_time_ms) as avg_response_time,
                AVG(avg_similarity) as avg_result_similarity
            FROM vector_searches
            WHERE search_timestamp >= DATE('now', '-30 days')
            GROUP BY DATE(search_timestamp), search_type
            ORDER BY search_date DESC, search_count DESC;
            """
        }
        
        query_choice = st.selectbox("Select Sample Query", list(sample_queries.keys()))
        if query_choice:
            st.code(sample_queries[query_choice], language="sql")
    
    def display_test_data(self):
        """Display test data generation"""
        st.header("🧪 Test Data Generation")
        
        # Generate test data with AI
        if st.button("🤖 Generate Test Data with AI", type="primary"):
            with st.spinner("AI is generating realistic test data..."):
                try:
                    prompt = """
                    Generate realistic test data for a KYC verification system with SQLite and ChromaDB integration.
                    
                    Include:
                    1. 5 sample customers with realistic data
                    2. 10 sample documents with metadata
                    3. Sample vector search operations
                    4. Document similarity records
                    5. ChromaDB collection configurations
                    
                    Return as JSON with separate sections for each table.
                    Make it realistic for testing dual database operations.
                    """
                    
                    response = self.llm.invoke(prompt)
                    test_data = response.content
                    
                    st.subheader("Generated Test Data")
                    st.code(test_data, language="json")
                    
                    # Download test data
                    st.download_button(
                        label="📥 Download Test Data",
                        data=test_data,
                        file_name="kyc_test_data_dual_db.json",
                        mime="application/json"
                    )
                    
                except Exception as e:
                    st.error(f"AI test data generation failed: {str(e)}")
        
        # Manual test data for specific table
        st.subheader("Manual Test Data Entry")
        
        test_table = st.selectbox(
            "Select Table for Test Data",
            ["customers", "documents", "vector_searches", "document_similarity"]
        )
        
        if test_table and test_table in self.schema["tables"]:
            table_def = self.schema["tables"][test_table]
            
            # Generate sample INSERT statement
            sample_data = self.generate_sample_data(test_table)
            
            st.code(sample_data, language="sql")
            
            if st.button("Generate More Samples", type="secondary"):
                new_samples = self.generate_sample_data(test_table, count=3)
                st.code(new_samples, language="sql")
    
    def generate_complete_sql(self):
        """Generate complete SQL script"""
        sql = """-- KYC Verification System Dual Database Schema
-- SQLite Database Schema with ChromaDB Integration
-- Generated on: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + """
-- Vector Database: ChromaDB with SentenceTransformer embeddings

"""
        
        for table_name, table_def in self.schema["tables"].items():
            sql += f"\n-- Table: {table_name}\n"
            sql += f"-- {table_def['description']}\n"
            
            if table_def.get("chroma_integration"):
                sql += f"-- ChromaDB Integration: {table_def['chroma_integration'] if isinstance(table_def['chroma_integration'], str) else 'Integrated'}\n"
            
            sql += f"CREATE TABLE IF NOT EXISTS {table_name} (\n"
            
            columns = []
            for col in table_def["columns"]:
                col_def = f"    {col['name']} {col['type']}"
                
                if col.get("primary_key"):
                    col_def += " PRIMARY KEY"
                if col.get("unique"):
                    col_def += " UNIQUE"
                if col.get("default") is not None:
                    if isinstance(col['default'], str):
                        col_def += f" DEFAULT '{col['default']}'"
                    else:
                        col_def += f" DEFAULT {col['default']}"
                if col.get("nullable") == False:
                    col_def += " NOT NULL"
                
                columns.append(col_def)
            
            sql += ",\n".join(columns)
            sql += "\n);\n"
            
            # Add indexes
            if table_def.get("indexes"):
                sql += "\n"
                for idx in table_def["indexes"]:
                    sql += f"{idx};\n"
        
        # Add foreign key constraints
        sql += "\n-- Foreign Key Constraints\n"
        for rel in self.schema["relationships"]:
            if "on" in rel:
                # Parse the relationship to create FK constraints
                # This is simplified - in production, you'd parse the 'on' clause
                sql += f"-- Relationship: {rel['from']} -> {rel['to']}\n"
        
        return sql
    
    def generate_sample_data(self, table_name, count=1):
        """Generate sample data for a table"""
        samples = {
            "customers": """
            INSERT INTO customers 
            (customer_id, full_name, email, phone, date_of_birth, nationality, 
             registration_date, kyc_status, ai_confidence, vector_documents_count)
            VALUES 
            ('CUST001', 'John Smith', 'john.smith@example.com', '+1234567890', 
             '1990-05-15', 'United States', '2024-01-15T10:30:00Z', 
             'UNDER_REVIEW', 0.85, 3);
            """,
            
            "documents": """
            INSERT INTO documents 
            (document_id, customer_id, document_type, file_name, file_path,
             file_size, file_hash, upload_timestamp, verification_status,
             ai_confidence, extracted_text, chroma_stored, embedding_model)
            VALUES 
            ('DOC001', 'CUST001', 'ID Proof', 'passport.jpg', '/uploads/passport.jpg',
             2048000, 'a1b2c3d4e5f6', '2024-01-15T10:35:00Z', 'VERIFIED',
             0.92, 'PASSPORT\\nName: John Smith\\nDOB: 1990-05-15\\n...', 
             1, 'all-MiniLM-L6-v2');
            """,
            
            "vector_searches": """
            INSERT INTO vector_searches
            (search_id, customer_id, query_text, search_type, results_count,
             avg_similarity, search_timestamp, response_time_ms, chroma_collection)
            VALUES 
            ('SRCH001', 'CUST001', 'passport verification', 'semantic', 5,
             0.78, '2024-01-15T11:00:00Z', 150, 'kyc_documents');
            """,
            
            "document_similarity": """
            INSERT INTO document_similarity
            (similarity_id, document1_id, document2_id, customer_id, similarity_score,
             similarity_type, analysis_date, is_anomaly)
            VALUES 
            ('SIM001', 'DOC001', 'DOC002', 'CUST001', 0.85,
             'intra-customer', '2024-01-15T11:30:00Z', 0);
            """
        }
        
        if table_name in samples:
            return samples[table_name] * count
        else:
            return f"-- No sample data template for table: {table_name}"

# Run database schema generator
if __name__ == "__main__":
    schema = DatabaseSchema()
    schema.display_schema_ui()