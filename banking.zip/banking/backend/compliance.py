"""
Compliance reporting and audit exports
"""
import csv
import json
from datetime import datetime, timedelta
from typing import List, Dict
import pandas as pd
from backend.database import SessionLocal, AuditLog, KYCDocument, Customer

class ComplianceManager:
    """Generate compliance reports and audit trails"""
    
    def generate_kyc_report(self, start_date: datetime = None, 
                           end_date: datetime = None) -> Dict:
        """Generate comprehensive KYC compliance report"""
        db = SessionLocal()
        
        try:
            # Default to last 30 days
            if not start_date:
                start_date = datetime.now() - timedelta(days=30)
            if not end_date:
                end_date = datetime.now()
            
            # Get KYC statistics
            total_customers = db.query(Customer).count()
            verified_customers = db.query(Customer).filter_by(is_verified=True).count()
            pending_customers = total_customers - verified_customers
            
            # Get document statistics
            total_documents = db.query(KYCDocument).count()
            verified_documents = db.query(KYCDocument).filter_by(status='verified').count()
            rejected_documents = db.query(KYCDocument).filter_by(status='rejected').count()
            pending_documents = total_documents - verified_documents - rejected_documents
            
            # Get audit logs for period
            audit_logs = db.query(AuditLog).filter(
                AuditLog.created_at >= start_date,
                AuditLog.created_at <= end_date
            ).all()
            
            # Calculate compliance metrics
            verification_rate = (verified_documents / total_documents * 100) if total_documents > 0 else 0
            avg_verification_time = self._calculate_avg_verification_time(db)
            
            report = {
                'report_period': {
                    'start_date': start_date.isoformat(),
                    'end_date': end_date.isoformat(),
                    'generated_date': datetime.now().isoformat()
                },
                'kyc_statistics': {
                    'total_customers': total_customers,
                    'verified_customers': verified_customers,
                    'pending_customers': pending_customers,
                    'verification_rate_percentage': round(verification_rate, 2)
                },
                'document_statistics': {
                    'total_documents': total_documents,
                    'verified_documents': verified_documents,
                    'rejected_documents': rejected_documents,
                    'pending_documents': pending_documents,
                    'verification_success_rate': f"{verification_rate:.2f}%"
                },
                'performance_metrics': {
                    'average_verification_time_hours': avg_verification_time,
                    'documents_per_day': len(audit_logs) / 30,  # Assuming 30 days
                    'automation_rate': '95%'  # Placeholder
                },
                'compliance_indicators': {
                    'rbi_guidelines_followed': True,
                    'aml_checks_performed': True,
                    'audit_trail_maintained': True,
                    'data_encryption_enabled': True
                },
                'risk_indicators': {
                    'high_risk_documents': rejected_documents,
                    'suspicious_activities': self._count_suspicious_activities(audit_logs),
                    'tampering_cases': self._count_tampering_cases(db)
                }
            }
            
            return report
            
        finally:
            db.close()
    
    def export_audit_trail_csv(self, filepath: str) -> bool:
        """Export audit trail to CSV for compliance"""
        db = SessionLocal()
        
        try:
            audit_logs = db.query(AuditLog).order_by(AuditLog.created_at.desc()).all()
            
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['timestamp', 'customer_id', 'action', 'details', 
                            'ip_address', 'user_agent']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for log in audit_logs:
                    writer.writerow({
                        'timestamp': log.created_at.isoformat(),
                        'customer_id': log.customer_id,
                        'action': log.action,
                        'details': log.details or '',
                        'ip_address': log.ip_address or '',
                        'user_agent': log.user_agent or ''
                    })
            
            return True
            
        except Exception as e:
            print(f"Export failed: {e}")
            return False
        finally:
            db.close()
    
    def export_kyc_report_excel(self, filepath: str) -> bool:
        """Export KYC report to Excel format"""
        try:
            report = self.generate_kyc_report()
            
            # Create Excel writer
            with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
                # Summary sheet
                summary_data = {
                    'Metric': ['Total Customers', 'Verified Customers', 'Verification Rate'],
                    'Value': [
                        report['kyc_statistics']['total_customers'],
                        report['kyc_statistics']['verified_customers'],
                        report['kyc_statistics']['verification_rate_percentage']
                    ]
                }
                pd.DataFrame(summary_data).to_excel(writer, sheet_name='Summary', index=False)
                
                # Document statistics sheet
                doc_data = {
                    'Document Status': ['Verified', 'Rejected', 'Pending', 'Total'],
                    'Count': [
                        report['document_statistics']['verified_documents'],
                        report['document_statistics']['rejected_documents'],
                        report['document_statistics']['pending_documents'],
                        report['document_statistics']['total_documents']
                    ]
                }
                pd.DataFrame(doc_data).to_excel(writer, sheet_name='Documents', index=False)
                
                # Compliance sheet
                compliance_data = {
                    'Compliance Check': list(report['compliance_indicators'].keys()),
                    'Status': list(report['compliance_indicators'].values())
                }
                pd.DataFrame(compliance_data).to_excel(writer, sheet_name='Compliance', index=False)
            
            return True
            
        except Exception as e:
            print(f"Excel export failed: {e}")
            return False
    
    def _calculate_avg_verification_time(self, db) -> float:
        """Calculate average verification time in hours"""
        try:
            documents = db.query(KYCDocument).filter(
                KYCDocument.verified_at.isnot(None)
            ).all()
            
            if not documents:
                return 0.0
            
            total_hours = 0
            count = 0
            
            for doc in documents:
                if doc.uploaded_at and doc.verified_at:
                    time_diff = (doc.verified_at - doc.uploaded_at).total_seconds() / 3600
                    total_hours += time_diff
                    count += 1
            
            return round(total_hours / count, 2) if count > 0 else 0.0
            
        except:
            return 0.0
    
    def _count_suspicious_activities(self, audit_logs: List) -> int:
        """Count suspicious activities from audit logs"""
        suspicious_keywords = ['rejected', 'failed', 'suspicious', 'tampering', 
                              'fraud', 'invalid', 'error']
        count = 0
        
        for log in audit_logs:
            if log.details and any(keyword in log.details.lower() 
                                 for keyword in suspicious_keywords):
                count += 1
        
        return count
    
    def _count_tampering_cases(self, db) -> int:
        """Count tampering cases from documents"""
        try:
            documents = db.query(KYCDocument).filter(
                KYCDocument.verification_result.contains('tampering')
            ).count()
            return documents
        except:
            return 0