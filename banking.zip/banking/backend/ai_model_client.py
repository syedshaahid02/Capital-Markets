"""
AI Model Client for KYC Document Verification
"""
import openai
from decouple import config
import json
from typing import Dict, Any, List
import logging
import base64

logger = logging.getLogger(__name__)

class AIModelClient:
    def __init__(self):
        # Configure OpenAI client
        self.client = openai.OpenAI(
            base_url=config('BASE_URL', 'https://genailab.tcs.in'),
            api_key=config('API_KEY')
        )
        self.model = config('MODEL_NAME', 'azure_ai/genailab-maas-DeepSeek-V3-0324')
    
    def analyze_document(self, file_data: bytes, filename: str, document_type: str) -> Dict[str, Any]:
        """Analyze document using AI to detect invalid uploads"""
        try:
            # Prepare image for analysis
            if document_type == 'photo':
                analysis = self._analyze_photo(file_data, filename)
            else:
                analysis = self._analyze_document(file_data, filename, document_type)
            
            return analysis
            
        except Exception as e:
            logger.error(f"AI analysis error: {e}")
            return {
                'is_valid': False,
                'confidence': 0.0,
                'analysis': f"AI analysis failed: {str(e)}",
                'issues': ['AI service unavailable'],
                'document_type': 'unknown'
            }
    
    def _analyze_document(self, file_data: bytes, filename: str, expected_type: str) -> Dict[str, Any]:
        """Analyze document for validity"""
        
        # Encode image to base64
        encoded_image = base64.b64encode(file_data).decode('utf-8')
        
        prompt = f"""
        You are a banking KYC document verification AI. Analyze this image and determine:
        
        1. Is this a valid {expected_type} document? (ID proof, address proof, etc.)
        2. If not valid, what is it? (animal photo, object, blank, blurry, etc.)
        3. Provide rejection reasons if invalid
        
        Expected document type: {expected_type}
        
        Return JSON format:
        {{
            "is_valid": boolean,
            "confidence": float (0.0 to 1.0),
            "what_is_it": "description of what was uploaded",
            "is_document": boolean,
            "document_type": "actual document type if valid",
            "rejection_reason": "if not valid, why?",
            "issues": ["list of issues found"],
            "analysis": "detailed analysis"
        }}
        
        Common rejection reasons:
        - "This appears to be an animal/object photo, not a document"
        - "Image is blank or empty"
        - "Image is too blurry to read"
        - "This is a chair/furniture photo"
        - "No readable text found"
        - "Wrong document type uploaded"
        - "Image quality too poor"
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a strict KYC document verifier. Reject invalid documents clearly."
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{encoded_image}"
                                }
                            }
                        ]
                    }
                ],
                temperature=0.1,
                max_tokens=500
            )
            
            result_text = response.choices[0].message.content
            print(f"This is my llm output {result_text} ")
            
            # Parse the response
            return self._parse_ai_response(result_text)
            
        except Exception as e:
            logger.error(f"AI API error: {e}")
            # Fallback to basic analysis
            return self._basic_analysis(file_data, filename, expected_type)
    
    def _analyze_photo(self, file_data: bytes, filename: str) -> Dict[str, Any]:
        """Analyze if uploaded photo is a valid passport photo"""
        
        encoded_image = base64.b64encode(file_data).decode('utf-8')
        
        prompt = """
        You are a passport photo verification AI. Analyze this image:
        
        1. Is this a valid passport/identity photo of a person?
        2. If not, what is it? (animal, object, multiple people, etc.)
        3. Check requirements:
           - Single person clearly visible
           - Face centered and clear
           - White/light background
           - Neutral expression
           - No other objects/people
        
        Return JSON format:
        {
            "is_valid": boolean,
            "confidence": float,
            "is_person": boolean,
            "what_is_it": "description",
            "rejection_reason": "if not valid",
            "issues": ["list of issues"],
            "analysis": "detailed analysis"
        }
        
        Common rejection reasons:
        - "This is an animal photo, not a person"
        - "Multiple people detected"
        - "No face clearly visible"
        - "Not a passport photo (object/furniture)"
        - "Photo quality too poor"
        - "Background not appropriate"
        """
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system", 
                        "content": "You verify passport photos. Strictly reject non-person photos."
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{encoded_image}"
                                }
                            }
                        ]
                    }
                ],
                temperature=0.1,
                max_tokens=500
            )
            
            result_text = response.choices[0].message.content
            return self._parse_ai_response(result_text)
            
        except Exception as e:
            logger.error(f"Photo analysis error: {e}")
            return {
                'is_valid': False,
                'confidence': 0.0,
                'is_person': False,
                'what_is_it': 'unknown',
                'rejection_reason': 'AI analysis failed',
                'issues': ['Could not analyze photo'],
                'analysis': 'Analysis failed'
            }
    
    def _parse_ai_response(self, response_text: str) -> Dict[str, Any]:
        """Parse AI response into structured data"""
        try:
            # Try to extract JSON from response
            import re
            
            # Find JSON pattern
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                json_str = json_match.group()
                result = json.loads(json_str)
            else:
                # If no JSON, create from text analysis
                result = self._parse_text_response(response_text)
            
            # Ensure required fields
            if 'is_valid' not in result:
                result['is_valid'] = False
            
            if 'confidence' not in result:
                result['confidence'] = 0.0
            
            if 'issues' not in result:
                result['issues'] = []
            
            if 'analysis' not in result:
                result['analysis'] = response_text[:200]
            
            return result
            
        except json.JSONDecodeError:
            logger.error(f"Failed to parse AI response: {response_text[:200]}")
            return {
                'is_valid': False,
                'confidence': 0.0,
                'issues': ['Could not parse AI response'],
                'analysis': response_text[:200]
            }
    
    def _parse_text_response(self, text: str) -> Dict[str, Any]:
        """Parse text response when JSON not found"""
        text_lower = text.lower()
        
        # Detect common issues from text
        issues = []
        is_valid = True
        what_is_it = "document"
        rejection_reason = ""
        
        # Check for animal photos
        animal_keywords = ['cat', 'dog', 'animal', 'pet', 'bird', 'fish']
        for keyword in animal_keywords:
            if keyword in text_lower:
                issues.append(f"This is a {keyword} photo")
                what_is_it = f"{keyword} photo"
                is_valid = False
                rejection_reason = f"This appears to be a {keyword} photo, not a document"
                break
        
        # Check for objects/furniture
        object_keywords = ['chair', 'table', 'furniture', 'object', 'thing', 'item']
        for keyword in object_keywords:
            if keyword in text_lower:
                issues.append(f"This is a {keyword}")
                what_is_it = f"{keyword}"
                is_valid = False
                rejection_reason = f"This appears to be a {keyword}, not a document"
                break
        
        # Check for blurry/quality issues
        quality_keywords = ['blurry', 'unclear', 'fuzzy', 'poor quality', 'cannot read']
        for keyword in quality_keywords:
            if keyword in text_lower:
                issues.append("Image quality too poor")
                is_valid = False
                rejection_reason = "Image is too blurry to read"
                break
        
        # Check for blank/empty
        blank_keywords = ['blank', 'empty', 'white', 'black', 'no content']
        for keyword in blank_keywords:
            if keyword in text_lower:
                issues.append("Image appears blank/empty")
                what_is_it = "blank image"
                is_valid = False
                rejection_reason = "Image appears to be blank or empty"
                break
        
        # Check if it's a document
        document_keywords = ['document', 'id', 'passport', 'aadhaar', 'pan', 'license', 'bill']
        is_document = any(keyword in text_lower for keyword in document_keywords)
        
        if not is_document and is_valid:
            issues.append("Not a recognizable document")
            is_valid = False
            rejection_reason = "This does not appear to be a valid document"
        
        return {
            'is_valid': is_valid,
            'confidence': 0.5 if is_valid else 0.1,
            'what_is_it': what_is_it,
            'is_document': is_document,
            'rejection_reason': rejection_reason,
            'issues': issues,
            'analysis': text[:200]
        }
    
    def _basic_analysis(self, file_data: bytes, filename: str, expected_type: str) -> Dict[str, Any]:
        """Basic analysis when AI fails"""
        try:
            # Try OCR to see if there's text
            import pytesseract
            from PIL import Image
            import io
            
            # Check file size first
            if len(file_data) > 5 * 1024 * 1024:
                return {
                    'is_valid': False,
                    'confidence': 0.0,
                    'what_is_it': 'large file',
                    'rejection_reason': 'File size exceeds 5MB limit',
                    'issues': ['File too large'],
                    'analysis': 'File exceeds size limit'
                }
            
            # Check if it's an image
            try:
                image = Image.open(io.BytesIO(file_data))
                # Try OCR
                text = pytesseract.image_to_string(image)
                
                if len(text.strip()) < 10:
                    return {
                        'is_valid': False,
                        'confidence': 0.1,
                        'what_is_it': 'image with no text',
                        'rejection_reason': 'No readable text found in document',
                        'issues': ['OCR extracted no text'],
                        'analysis': 'Image appears to have no readable text'
                    }
                else:
                    return {
                        'is_valid': True,
                        'confidence': 0.7,
                        'what_is_it': 'document with text',
                        'is_document': True,
                        'rejection_reason': '',
                        'issues': [],
                        'analysis': f'Found text: {text[:100]}...'
                    }
                    
            except:
                return {
                    'is_valid': False,
                    'confidence': 0.0,
                    'what_is_it': 'invalid image',
                    'rejection_reason': 'Could not read image file',
                    'issues': ['Invalid image format'],
                    'analysis': 'Failed to process image'
                }
                
        except Exception as e:
            return {
                'is_valid': False,
                'confidence': 0.0,
                'what_is_it': 'unknown',
                'rejection_reason': f'Analysis failed: {str(e)}',
                'issues': ['Analysis error'],
                'analysis': 'Failed to analyze'
            }