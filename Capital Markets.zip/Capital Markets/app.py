import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json
import os

# Import backend modules
from backend.data_fetcher import MarketDataFetcher
from backend.scenario_agent import ScenarioAgent
from backend.report_generator import PDFReportGenerator
from utils.config import Config

# Page configuration
st.set_page_config(
    page_title="AI Risk Scenario Generator",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

class RiskScenarioApp:
    def __init__(self):
        self.data_fetcher = MarketDataFetcher()
        self.scenario_agent = ScenarioAgent()
        self.report_generator = PDFReportGenerator()
        self.config = Config()
        
        # Initialize session state
        if 'scenarios' not in st.session_state:
            st.session_state.scenarios = []
        if 'market_data' not in st.session_state:
            st.session_state.market_data = None
    
    def run(self):
        # Sidebar
        st.sidebar.title("AI Risk Scenario Generator")
        st.sidebar.markdown("---")
        
        # Model info
        st.sidebar.info(f"Model: {Config.LANGCHAIN_MODEL}")
        
        # Navigation
        pages = {
            "Dashboard": self.dashboard_page,
            "Market Data": self.market_data_page,
            "Scenario Generator": self.scenario_generator_page,
            "Historical Analysis": self.historical_analysis_page,
            "Portfolio Impact": self.portfolio_impact_page,
            "Report Manager": self.report_manager_page,
            "Settings": self.settings_page
        }
        
        selection = st.sidebar.radio("Navigate", list(pages.keys()))
        pages[selection]()
        
        # Footer
        st.sidebar.markdown("---")
        st.sidebar.info(
            "AI-Powered Risk Management System\n\n"
            f"Using: {Config.LANGCHAIN_MODEL}"
        )
    
    def dashboard_page(self):
        st.title("Risk Management Dashboard")
        
        # Market Overview
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="S&P 500",
                value="4,500.00",
                delta="+1.2%"
            )
        
        with col2:
            st.metric(
                label="VIX Index",
                value="15.2",
                delta="-0.8"
            )
        
        with col3:
            st.metric(
                label="Generated Scenarios",
                value=len(st.session_state.scenarios)
            )
        
        with col4:
            high_risk = len([s for s in st.session_state.scenarios if s.get('severity') == 'High'])
            st.metric(
                label="High Risk Scenarios",
                value=high_risk
            )
        
        # Recent Scenarios
        st.subheader("Recent Risk Scenarios")
        if st.session_state.scenarios:
            scenario_df = pd.DataFrame([
                {
                    'Type': s['scenario_type'],
                    'Portfolio': s.get('portfolio_type', 'N/A'),
                    'Severity': s.get('severity', 'Unknown'),
                    'Generated': s.get('generated_at', 'N/A'),
                    'Model': s.get('model_used', 'N/A')
                }
                for s in st.session_state.scenarios[-5:]
            ])
            st.dataframe(scenario_df, use_container_width=True)
        else:
            st.info("No scenarios generated yet. Visit the Scenario Generator page to create scenarios.")
        
        # Risk Distribution Chart
        if st.session_state.scenarios:
            st.subheader("Risk Scenario Distribution")
            severity_counts = pd.DataFrame([
                {'Severity': s.get('severity', 'Unknown'), 'Count': 1}
                for s in st.session_state.scenarios
            ]).groupby('Severity').count().reset_index()
            
            fig = px.pie(severity_counts, values='Count', names='Severity', 
                        title="Scenario Severity Distribution")
            st.plotly_chart(fig, use_container_width=True)
    
    def market_data_page(self):
        st.title("Market Data Analysis")
        
        # Fetch market data
        if st.button("Refresh Market Data"):
            with st.spinner("Fetching latest market data..."):
                st.session_state.market_data = self.data_fetcher.get_market_indices()
        
        if st.session_state.market_data:
            # Display market indices
            st.subheader("Major Market Indices")
            
            for symbol, data in st.session_state.market_data.items():
                if not data.empty:
                    col1, col2 = st.columns([1, 2])
                    
                    with col1:
                        latest_price = data['Close'].iloc[-1]
                        prev_price = data['Close'].iloc[-2] if len(data) > 1 else latest_price
                        change_pct = ((latest_price - prev_price) / prev_price) * 100
                        
                        st.metric(
                            label=symbol,
                            value=f"${latest_price:.2f}",
                            delta=f"{change_pct:.2f}%"
                        )
                    
                    with col2:
                        fig = go.Figure()
                        fig.add_trace(go.Scatter(
                            x=data.index,
                            y=data['Close'],
                            mode='lines',
                            name=symbol
                        ))
                        fig.update_layout(
                            title=f"{symbol} Price Trend",
                            height=200,
                            showlegend=False
                        )
                        st.plotly_chart(fig, use_container_width=True)
        
        # Volatility Analysis
        st.subheader("Volatility Analysis")
        vix_data = self.data_fetcher.get_volatility_data()
        
        if vix_data and 'VIX' in vix_data and not vix_data['VIX'].empty:
            vix_df = vix_data['VIX']
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=vix_df.index,
                y=vix_df['Close'],
                mode='lines',
                name='VIX',
                line=dict(color='red')
            ))
            fig.update_layout(
                title="VIX Volatility Index",
                height=300
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Volatility data not available. Using simulated data.")
            
            # Simulated VIX data
            dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
            simulated_vix = [15 + 5 * abs(i % 20 - 10) / 10 for i in range(100)]
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=dates,
                y=simulated_vix,
                mode='lines',
                name='VIX (Simulated)',
                line=dict(color='red')
            ))
            fig.update_layout(
                title="VIX Volatility Index (Simulated)",
                height=300
            )
            st.plotly_chart(fig, use_container_width=True)
    
    def scenario_generator_page(self):
        st.title("AI Risk Scenario Generator")
        st.markdown(f"Using **{Config.LANGCHAIN_MODEL}** for AI-powered risk analysis")
        
        # Add debug button
        if st.button("Test Connection First"):
            try:
                success, response = self.scenario_agent.test_llm_connection()
                if success:
                    st.success(f"✅ Connection successful! Response: {response}")
                else:
                    st.error(f"❌ Connection failed: {response}")
            except Exception as e:
                st.error(f"❌ Test failed: {e}")
        
        # Scenario configuration
        col1, col2 = st.columns(2)
        
        with col1:
            selected_scenarios = st.multiselect(
                "Select Scenario Types",
                options=Config.SCENARIO_TYPES,
                default=Config.SCENARIO_TYPES[:2]
            )
            
            portfolio_type = st.selectbox(
                "Portfolio Type",
                options=Config.PORTFOLIO_TYPES
            )
        
        with col2:
            scenario_count = st.slider(
                "Scenarios per Type",
                min_value=1,
                max_value=5,
                value=2
            )
            
            include_historical = st.checkbox(
                "Include Historical Context",
                value=True
            )
        
        # Generate scenarios
        if st.button("Generate Risk Scenarios", type="primary"):
            if not selected_scenarios:
                st.error("Please select at least one scenario type.")
                return
            
            with st.spinner(f"Generating AI-powered risk scenarios using {Config.LANGCHAIN_MODEL}..."):
                try:
                    new_scenarios = self.scenario_agent.generate_multiple_scenarios(
                        selected_scenarios,
                        portfolio_type,
                        scenario_count
                    )
                    
                    st.session_state.scenarios.extend(new_scenarios)
                    st.success(f"Successfully generated {len(new_scenarios)} scenarios using {Config.LANGCHAIN_MODEL}!")
                    
                except Exception as e:
                    st.error(f"Error generating scenarios: {e}")
        
        # Display generated scenarios
        if st.session_state.scenarios:
            st.subheader("Generated Scenarios")
            
            for i, scenario in enumerate(st.session_state.scenarios[-len(selected_scenarios)*scenario_count:]):
                with st.expander(f"Scenario {i+1}: {scenario['scenario_type']} ({scenario.get('severity', 'Unknown')} Severity)"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.write("**Overview**")
                        st.write(scenario.get('scenario_overview', 'N/A'))
                        
                        st.write("**Market Context**")
                        st.write(scenario.get('market_context', 'N/A'))
                        
                        st.write("**Timeline**")
                        st.write(scenario.get('timeline', 'N/A'))
                    
                    with col2:
                        st.write("**Portfolio Impact**")
                        st.write(scenario.get('portfolio_impact', 'N/A'))
                        
                        st.write("**Risk Metrics**")
                        risk_metrics = scenario.get('risk_metrics', {})
                        for metric, value in risk_metrics.items():
                            st.write(f"- {metric}: {value}")
                        
                        st.write("**Mitigation Strategies**")
                        mitigation = scenario.get('mitigation_strategies', [])
                        if isinstance(mitigation, list):
                            for strategy in mitigation:
                                st.write(f"- {strategy}")
                        else:
                            st.write(mitigation)
                    
                    st.write("**Monitoring Indicators**")
                    monitoring = scenario.get('monitoring_indicators', [])
                    if isinstance(monitoring, list):
                        for indicator in monitoring:
                            st.write(f"- {indicator}")
                    else:
                        st.write(monitoring)
        else:
            st.info("No scenarios generated yet. Configure your scenario parameters above and click 'Generate Risk Scenarios' to create your first AI-powered risk analysis.")
    
    def historical_analysis_page(self):
        st.title("Historical Crisis Analysis")
        
        st.subheader("Major Historical Financial Crises")
        crises_df = pd.DataFrame(Config.HISTORICAL_CRISES)
        st.dataframe(crises_df, use_container_width=True)
        
        # Crisis comparison
        st.subheader("Crisis Impact Analysis")
        selected_crisis = st.selectbox(
            "Select Crisis for Detailed Analysis",
            options=[crisis['name'] for crisis in Config.HISTORICAL_CRISES]
        )
        
        if selected_crisis:
            crisis_data = next((c for c in Config.HISTORICAL_CRISES if c['name'] == selected_crisis), None)
            
            if crisis_data:
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Crisis Details**")
                    st.write(f"Name: {crisis_data['name']}")
                    st.write(f"Year: {crisis_data['year']}")
                    st.write(f"Severity: {crisis_data['severity']}")
                
                with col2:
                    st.write("**Key Learning**")
                    if "2008" in crisis_data['name']:
                        st.write("Systemic risk from interconnected financial institutions")
                    elif "COVID" in crisis_data['name']:
                        st.write("Global supply chain disruptions and liquidity crises")
                    elif "Dot-com" in crisis_data['name']:
                        st.write("Valuation bubbles in technology sectors")
                    else:
                        st.write("Important lessons in risk management and regulatory oversight")
    
    def portfolio_impact_page(self):
        st.title("Portfolio Impact Analysis")
        
        if not st.session_state.scenarios:
            st.info("Generate some scenarios first to analyze portfolio impacts.")
            return
        
        st.subheader("Scenario Impact Comparison")
        
        # Create impact comparison table
        impact_data = []
        for scenario in st.session_state.scenarios:
            impact_data.append({
                'Scenario Type': scenario['scenario_type'],
                'Portfolio': scenario.get('portfolio_type', 'N/A'),
                'Severity': scenario.get('severity', 'Unknown'),
                'VaR Estimate': scenario.get('risk_metrics', {}).get('var_95', 'N/A'),
                'Expected Shortfall': scenario.get('risk_metrics', {}).get('expected_shortfall', 'N/A')
            })
        
        impact_df = pd.DataFrame(impact_data)
        st.dataframe(impact_df, use_container_width=True)
        
        # Impact visualization
        st.subheader("Risk Impact Visualization")
        
        if len(impact_data) > 0:
            # Convert VaR estimates to numerical values for plotting
            var_values = []
            for item in impact_data:
                var_str = item['VaR Estimate']
                if var_str != 'N/A' and '-' in var_str:
                    try:
                        # Extract average of range
                        low, high = var_str.replace('%', '').split('-')
                        avg_var = (float(low) + float(high)) / 2
                        var_values.append(avg_var)
                    except:
                        var_values.append(0)
                else:
                    var_values.append(0)
            
            impact_df['VaR_Numeric'] = var_values
            
            fig = px.bar(impact_df, x='Scenario Type', y='VaR_Numeric', 
                        color='Severity', title="Value at Risk by Scenario")
            st.plotly_chart(fig, use_container_width=True)
    
    def report_manager_page(self):
        st.title("Report Manager")
        
        if not st.session_state.scenarios:
            st.info("No scenarios available for reporting. Generate scenarios first.")
            return
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Individual Scenario Reports")
            selected_scenario = st.selectbox(
                "Select Scenario for PDF Report",
                options=[f"{s['scenario_type']} ({s.get('severity', 'Unknown')})" 
                        for s in st.session_state.scenarios],
                key="scenario_select"
            )
            
            if st.button("Generate Individual Report"):
                scenario_index = [f"{s['scenario_type']} ({s.get('severity', 'Unknown')})" 
                                for s in st.session_state.scenarios].index(selected_scenario)
                selected_scenario_data = st.session_state.scenarios[scenario_index]
                
                with st.spinner("Generating PDF report..."):
                    try:
                        report_path = self.report_generator.generate_scenario_report(selected_scenario_data)
                        
                        with open(report_path, "rb") as file:
                            st.download_button(
                                label="Download Scenario Report",
                                data=file,
                                file_name=os.path.basename(report_path),
                                mime="application/pdf"
                            )
                        st.success("Report generated successfully!")
                    except Exception as e:
                        st.error(f"Error generating report: {e}")
        
        with col2:
            st.subheader("Comprehensive Report")
            st.write("Generate a comprehensive report with all scenarios")
            
            if st.button("Generate Comprehensive Report", type="primary"):
                with st.spinner("Generating comprehensive report..."):
                    try:
                        report_path = self.report_generator.generate_comprehensive_report(
                            st.session_state.scenarios
                        )
                        
                        with open(report_path, "rb") as file:
                            st.download_button(
                                label="Download Comprehensive Report",
                                data=file,
                                file_name=os.path.basename(report_path),
                                mime="application/pdf"
                            )
                        st.success("Comprehensive report generated successfully!")
                    except Exception as e:
                        st.error(f"Error generating comprehensive report: {e}")
        
        # Report history
        st.subheader("Generated Reports")
        reports_dir = "reports"
        if os.path.exists(reports_dir):
            reports = [f for f in os.listdir(reports_dir) if f.endswith('.pdf')]
            if reports:
                for report in sorted(reports, reverse=True)[:5]:  # Show last 5 reports
                    report_path = os.path.join(reports_dir, report)
                    with open(report_path, "rb") as file:
                        st.download_button(
                            label=f"Download: {report}",
                            data=file,
                            file_name=report,
                            mime="application/pdf",
                            key=f"dl_{report}"
                        )
            else:
                st.info("No reports generated yet.")
    
    def settings_page(self):
        st.title("System Settings")
        
        st.subheader("LangChain Configuration")
        st.write(f"Model: {Config.LANGCHAIN_MODEL}")
        st.write(f"Base URL: {Config.LANGCHAIN_BASE_URL}")
        st.write(f"API Key: {'*' * 20}{Config.LANGCHAIN_API_KEY[-4:] if Config.LANGCHAIN_API_KEY else ''}")
        
        # Model testing
        st.subheader("Model Connection Test")
        if st.button("Test DeepSeek-V3 Connection"):
            try:
                success, response = self.scenario_agent.test_llm_connection()
                if success:
                    st.success(f"Connection successful! Response: {response}")
                else:
                    st.error(f"Connection failed: {response}")
                    
            except Exception as e:
                st.error(f"Connection test failed: {e}")
        
        # Data management
        st.subheader("Data Management")
        if st.button("Clear Scenario Cache"):
            st.session_state.scenarios = []
            st.success("Scenario cache cleared!")
        
        if st.button("Clear Market Data Cache"):
            st.session_state.market_data = None
            st.success("Market data cache cleared!")

# Run the app
if __name__ == "__main__":
    app = RiskScenarioApp()
    app.run()


    