import streamlit as st
import os
import sys
from datetime import datetime
import hashlib
from typing import Optional, Dict, List, Tuple
import traceback

# Add the current directory to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def safe_import():
    """Safely import all required modules"""
    imports = {}
    
    # Import backend modules
    try:
        from backend.database import init_db, SessionLocal, Customer, KYCDocument, RequiredDocument, AuditLog
        imports.update({
            'init_db': init_db,
            'SessionLocal': SessionLocal,
            'Customer': Customer,
            'KYCDocument': KYCDocument,
            'RequiredDocument': RequiredDocument,
            'AuditLog': AuditLog
        })
        st.success("✅ Database imports successful")
    except ImportError as e:
        st.error(f"❌ Database import error: {e}")
        st.code(traceback.format_exc())
        return None
    
    try:
        from backend.document_verification import DocumentVerification
        imports['DocumentVerification'] = DocumentVerification
        st.success("✅ Document verification import successful")
    except ImportError as e:
        st.error(f"❌ Document verification import error: {e}")
        st.code(traceback.format_exc())
    
    try:
        from backend.chroma_manager import ChromaManager
        imports['ChromaManager'] = ChromaManager
        st.success("✅ ChromaDB import successful")
    except ImportError as e:
        st.warning(f"⚠️ ChromaDB import warning: {e}")
    
    try:
        from frontend.ui_components import (
            setup_page_config, show_header, login_form, 
            registration_form, show_dashboard, document_upload_form,
            show_document_status, show_verification_result, show_audit_logs
        )
        imports.update({
            'setup_page_config': setup_page_config,
            'show_header': show_header,
            'login_form': login_form,
            'registration_form': registration_form,
            'show_dashboard': show_dashboard,
            'document_upload_form': document_upload_form,
            'show_document_status': show_document_status,
            'show_verification_result': show_verification_result,
            'show_audit_logs': show_audit_logs
        })
        st.success("✅ Frontend imports successful")
    except ImportError as e:
        st.error(f"❌ Frontend import error: {e}")
        st.code(traceback.format_exc())
    
    try:
        from utils.file_handler import FileHandler
        imports['FileHandler'] = FileHandler
        st.success("✅ Utils imports successful")
    except ImportError as e:
        st.error(f"❌ Utils import error: {e}")
        st.code(traceback.format_exc())
    
    return imports

# Import modules
imports = safe_import()
if imports is None:
    st.error("❌ Critical import failure. Cannot start application.")
    st.stop()

# Assign imports to variables
init_db = imports['init_db']
SessionLocal = imports['SessionLocal']
Customer = imports['Customer']
KYCDocument = imports['KYCDocument']
RequiredDocument = imports['RequiredDocument']
AuditLog = imports['AuditLog']
DocumentVerification = imports.get('DocumentVerification')
ChromaManager = imports.get('ChromaManager')
FileHandler = imports.get('FileHandler')
setup_page_config = imports['setup_page_config']
show_header = imports['show_header']
login_form = imports['login_form']
registration_form = imports['registration_form']
show_dashboard = imports['show_dashboard']
document_upload_form = imports['document_upload_form']
show_document_status = imports['show_document_status']
show_verification_result = imports['show_verification_result']
show_audit_logs = imports['show_audit_logs']

# Initialize components
def init_app():
    """Initialize application components"""
    try:
        # Initialize database
        init_db()
        st.success("✅ Database initialized successfully")
    except Exception as e:
        st.error(f"❌ Database initialization error: {e}")
        st.code(traceback.format_exc())
    
    # Initialize services
    try:
        if DocumentVerification:
            st.session_state.verifier = DocumentVerification()
            st.success("✅ Document verification service initialized")
    except Exception as e:
        st.error(f"❌ Document verification initialization error: {e}")
        st.session_state.verifier = None
    
    try:
        if FileHandler:
            st.session_state.file_handler = FileHandler()
            st.success("✅ File handler initialized")
    except Exception as e:
        st.error(f"❌ File handler initialization error: {e}")
        st.session_state.file_handler = None
    
    try:
        if ChromaManager:
            st.session_state.chroma_manager = ChromaManager()
            st.success("✅ ChromaDB initialized")
    except Exception as e:
        st.warning(f"⚠️ ChromaDB initialization warning: {e}")
        st.session_state.chroma_manager = None
    
    # Initialize session state variables
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'customer_id' not in st.session_state:
        st.session_state.customer_id = None
    if 'customer_name' not in st.session_state:
        st.session_state.customer_name = None
    if 'kyc_complete' not in st.session_state:
        st.session_state.kyc_complete = False
    if 'ai_enabled' not in st.session_state:
        st.session_state.ai_enabled = True

# ... rest of your app.py code ...

# ... rest of the app.py code remains the same ...

def hash_password(password: str) -> str:
    """Simple password hashing"""
    return hashlib.sha256(password.encode()).hexdigest()

def authenticate_user(email: str, password: str) -> Optional[Dict]:
    """Authenticate user"""
    db = SessionLocal()
    try:
        hashed_password = hash_password(password)
        customer = db.query(Customer).filter_by(email=email, password=hashed_password).first()
        
        if customer:
            return {
                'id': customer.id,
                'email': customer.email,
                'full_name': customer.full_name,
                'is_verified': customer.is_verified
            }
        return None
    finally:
        db.close()

def register_user(user_data: Dict) -> Tuple[bool, str]:
    """Register new user"""
    db = SessionLocal()
    try:
        # Check if email exists
        existing = db.query(Customer).filter_by(email=user_data['email']).first()
        if existing:
            return False, "Email already registered"
        
        # Create new customer
        new_customer = Customer(
            email=user_data['email'],
            password=hash_password(user_data['password']),
            full_name=user_data['full_name'],
            phone=user_data.get('phone'),
            created_at=datetime.utcnow()
        )
        
        db.add(new_customer)
        db.commit()
        
        # Add to audit log
        audit_log = AuditLog(
            customer_id=new_customer.id,
            action="user_registration",
            details=f"New user registered: {user_data['email']}",
            created_at=datetime.utcnow()
        )
        db.add(audit_log)
        db.commit()
        
        return True, "Registration successful"
        
    except Exception as e:
        db.rollback()
        return False, f"Registration failed: {str(e)}"
    finally:
        db.close()

def get_required_documents() -> List[Dict]:
    """Get list of required documents"""
    db = SessionLocal()
    try:
        docs = db.query(RequiredDocument).filter_by(is_required=True).all()
        return [
            {
                'document_type': doc.document_type,
                'description': doc.description,
                'allowed_formats': doc.allowed_formats,
                'max_size_mb': doc.max_size_mb
            }
            for doc in docs
        ]
    finally:
        db.close()

def get_customer_documents(customer_id: int) -> List[Dict]:
    """Get customer's uploaded documents"""
    db = SessionLocal()
    try:
        documents = db.query(KYCDocument).filter_by(customer_id=customer_id).all()
        return [
            {
                'document_type': doc.document_type,
                'status': doc.status,
                'uploaded_at': doc.uploaded_at,
                'verification_result': doc.verification_result,
                'extracted_data': doc.extracted_data
            }
            for doc in documents
        ]
    finally:
        db.close()

def save_document_upload(customer_id: int, document_type: str, filepath: str, 
                        filename: str, verification_result: Dict) -> bool:
    """Save document upload to database"""
    db = SessionLocal()
    try:
        # Check if document already exists for this type
        existing = db.query(KYCDocument).filter_by(
            customer_id=customer_id, 
            document_type=document_type
        ).first()
        
        if existing:
            # Update existing
            existing.file_path = filepath
            existing.status = 'verified' if verification_result['is_valid'] else 'pending'
            existing.verification_result = verification_result['message']
            existing.extracted_data = str(verification_result.get('extracted_data', {}))
            existing.verified_at = datetime.utcnow() if verification_result['is_valid'] else None
        else:
            # Create new
            new_doc = KYCDocument(
                customer_id=customer_id,
                document_type=document_type,
                file_path=filepath,
                original_filename=filename,
                status='verified' if verification_result['is_valid'] else 'pending',
                verification_result=verification_result['message'],
                extracted_data=str(verification_result.get('extracted_data', {})),
                uploaded_at=datetime.utcnow(),
                verified_at=datetime.utcnow() if verification_result['is_valid'] else None
            )
            db.add(new_doc)
        
        # Update customer verification status if all documents are verified
        if verification_result['is_valid']:
            check_kyc_completion(customer_id)
        
        # Add to audit log
        audit_log = AuditLog(
            customer_id=customer_id,
            action=f"document_upload_{document_type}",
            details=f"Uploaded {document_type}: {'verified' if verification_result['is_valid'] else 'pending'}",
            created_at=datetime.utcnow()
        )
        db.add(audit_log)
        
        db.commit()
        return True
        
    except Exception as e:
        db.rollback()
        print(f"Error saving document: {e}")
        return False
    finally:
        db.close()

def check_kyc_completion(customer_id: int):
    """Check and update KYC completion status"""
    db = SessionLocal()
    try:
        # Check if all required documents are verified
        required_docs = db.query(RequiredDocument).filter_by(is_required=True).all()
        required_types = [doc.document_type for doc in required_docs]
        
        customer_docs = db.query(KYCDocument).filter_by(customer_id=customer_id).all()
        
        all_verified = True
        for req_type in required_types:
            doc = next((d for d in customer_docs if d.document_type == req_type), None)
            if not doc or doc.status != 'verified':
                all_verified = False
                break
        
        # Update customer status
        if all_verified:
            customer = db.query(Customer).filter_by(id=customer_id).first()
            if customer and not customer.is_verified:
                customer.is_verified = True
                db.commit()
                
                # Log KYC completion
                audit_log = AuditLog(
                    customer_id=customer_id,
                    action="kyc_completed",
                    details="All KYC documents verified successfully",
                    created_at=datetime.utcnow()
                )
                db.add(audit_log)
                db.commit()
                
                st.session_state.kyc_complete = True
                
    finally:
        db.close()

def get_audit_logs(customer_id: int, limit: int = 10) -> List[Dict]:
    """Get audit logs for customer"""
    db = SessionLocal()
    try:
        logs = db.query(AuditLog).filter_by(customer_id=customer_id).order_by(AuditLog.created_at.desc()).limit(limit).all()
        return [
            {
                'action': log.action,
                'details': log.details,
                'created_at': log.created_at
            }
            for log in logs
        ]
    finally:
        db.close()

def check_document_consistency(customer_id: int) -> Dict[str, Any]:
    """Check consistency between uploaded documents"""
    return st.session_state.verifier.verify_kyc_consistency(customer_id)

def main():
    """Main application function"""
    # Setup page config
    setup_page_config()
    show_header()
    
    # Initialize app
    init_app()
    
    # Check if user is logged in
    if not st.session_state.logged_in:
        # Show login/register tabs
        tab1, tab2 = st.tabs(["Login", "Register"])
        
        with tab1:
            login_data = login_form()
            if login_data:
                user = authenticate_user(login_data['email'], login_data['password'])
                if user:
                    st.session_state.logged_in = True
                    st.session_state.customer_id = user['id']
                    st.session_state.customer_name = user['full_name']
                    st.session_state.kyc_complete = user['is_verified']
                    st.rerun()
                else:
                    st.error("Invalid email or password")
        
        with tab2:
            reg_data = registration_form()
            if reg_data:
                success, message = register_user(reg_data)
                if success:
                    st.success(message)
                    st.info("Please login with your credentials")
                else:
                    st.error(message)
        
        # Show information about KYC process
        st.markdown("---")
        st.subheader("🚀 AI-Powered KYC Verification")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.info("""
            **🤖 AI Verification:**
            - Uses DeepSeek-V3 AI Model
            - Advanced document analysis
            - Tampering detection
            - Consistency checking
            """)
        
        with col2:
            st.info("""
            **📄 Required Documents:**
            1. ID Proof (Aadhaar/Passport)
            2. Address Proof
            3. Photograph
            - All documents verified by AI
            """)
        
        with col3:
            st.info("""
            **⚡ Fast Processing:**
            - Real-time verification
            - Instant feedback
            - Secure uploads
            - Complete audit trail
            """)
        
        return
    
    # User is logged in - Show dashboard
    show_dashboard(
        st.session_state.customer_name,
        {
            'is_verified': st.session_state.kyc_complete,
            'uploaded_docs': len(get_customer_documents(st.session_state.customer_id)),
            'total_required': len(get_required_documents()),
            'is_complete': st.session_state.kyc_complete
        }
    )
    
    # Create tabs for different sections
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📄 Upload Documents", 
        "📋 Document Status", 
        "🤖 AI Analysis",
        "📊 KYC Progress",
        "📜 Activity Log"
    ])
    
    with tab1:
        # Document upload section
        required_docs = get_required_documents()
        customer_docs = get_customer_documents(st.session_state.customer_id)
        uploaded_types = [doc['document_type'] for doc in customer_docs]
        
        # Filter out already uploaded and verified documents
        pending_docs = [doc for doc in required_docs if doc['document_type'] not in uploaded_types]
        
        if pending_docs:
            st.info(f"📝 You have {len(pending_docs)} document(s) remaining to upload.")
            
            # AI mode toggle
            st.session_state.ai_enabled = st.checkbox("Enable AI Verification", value=st.session_state.ai_enabled)
            
            if st.session_state.ai_enabled:
                st.success("🤖 AI verification enabled - Using DeepSeek-V3 model for advanced analysis")
            else:
                st.warning("⚠️ Basic OCR verification only")
            
            # Show upload form
            selected_doc_type, uploaded_file, upload_button = document_upload_form(pending_docs)
            
            if upload_button and uploaded_file:
                with st.spinner("🔍 Verifying document with AI..." if st.session_state.ai_enabled else "Processing document..."):
                    # Read file data
                    file_data = uploaded_file.getvalue()
                    
                    # Verify document
                    result = st.session_state.verifier.verify_document(
                        selected_doc_type,
                        file_data,
                        uploaded_file.name,
                        st.session_state.customer_id
                    )
                    
                    # Show verification result
                    show_verification_result(result.dict())
                    
                    if result.is_valid:
                        # Save file
                        success, filepath, error = st.session_state.file_handler.save_uploaded_file(
                            file_data,
                            uploaded_file.name,
                            st.session_state.customer_id
                        )
                        
                        if success:
                            # Save to database
                            save_document_upload(
                                st.session_state.customer_id,
                                selected_doc_type,
                                filepath,
                                uploaded_file.name,
                                result.dict()
                            )
                            
                            # Add to ChromaDB
                            if result.extracted_data:
                                extracted_text = ""
                                if 'ocr_result' in result.extracted_data:
                                    # Try to get text from OCR result
                                    ocr_result = result.extracted_data['ocr_result']
                                    if 'extracted_text' in ocr_result:
                                        extracted_text = ocr_result['extracted_text']
                                
                                if extracted_text:
                                    st.session_state.chroma_manager.add_document_embedding(
                                        st.session_state.customer_id,
                                        selected_doc_type,
                                        extracted_text,
                                        result.extracted_data
                                    )
                            
                            st.success("✅ Document uploaded and verified successfully!")
                            st.balloons()
                            st.rerun()
                        else:
                            st.error(f"Failed to save file: {error}")
        else:
            st.success("✅ All required documents have been uploaded!")
            
            # Check consistency
            if len(customer_docs) >= 2:
                with st.spinner("Checking document consistency..."):
                    consistency_result = check_document_consistency(st.session_state.customer_id)
                
                if consistency_result.get('is_consistent', False):
                    st.success(f"✅ Documents are consistent (Confidence: {consistency_result.get('confidence', 0.0):.2%})")
                else:
                    st.warning(f"⚠️ Document consistency check: {consistency_result.get('analysis', 'Check failed')}")
            
            if st.session_state.kyc_complete:
                st.balloons()
                st.success("🎉 Your KYC verification is complete! You can now proceed with account opening.")
                
                if st.button("Proceed to Account Opening"):
                    st.info("Account opening feature coming soon!")
            else:
                st.info("📋 All documents uploaded. Verification is in progress.")
    
    with tab2:
        # Document status section
        documents = get_customer_documents(st.session_state.customer_id)
        show_document_status(documents)
        
        # Show verification details if available
        if documents:
            selected_doc = st.selectbox(
                "Select document to view details",
                options=[doc['document_type'].replace('_', ' ').title() for doc in documents],
                key="doc_details_select"
            )
            
            if selected_doc:
                doc_type = selected_doc.lower().replace(' ', '_')
                doc_info = next((doc for doc in documents if doc['document_type'] == doc_type), None)
                
                if doc_info and doc_info.get('verification_result'):
                    st.info(f"**Verification Result:** {doc_info['verification_result']}")
                    
                    # Show extracted data if available
                    if doc_info.get('extracted_data'):
                        try:
                            import ast
                            extracted_data = ast.literal_eval(doc_info['extracted_data'])
                            
                            if 'ai_result' in extracted_data:
                                with st.expander("View AI Analysis Details"):
                                    ai_result = extracted_data['ai_result']
                                    if 'confidence' in ai_result:
                                        st.metric("AI Confidence", f"{ai_result['confidence']:.2%}")
                                    if 'analysis' in ai_result:
                                        st.write("**Analysis:**", ai_result['analysis'])
                                    if 'extracted_info' in ai_result:
                                        st.write("**Extracted Information:**")
                                        for key, value in ai_result['extracted_info'].items():
                                            if value:
                                                st.write(f"- {key.replace('_', ' ').title()}: {value}")
                        except:
                            pass
    
    with tab3:
        # AI Analysis section
        st.subheader("🤖 AI-Powered Document Analysis")
        
        documents = get_customer_documents(st.session_state.customer_id)
        
        if documents:
            # Show AI insights
            col1, col2 = st.columns(2)
            
            with col1:
                # Count verified documents
                verified_count = sum(1 for doc in documents if doc['status'] == 'verified')
                st.metric("AI-Verified Documents", verified_count)
            
            with col2:
                # Average confidence
                total_confidence = 0
                count = 0
                for doc in documents:
                    if doc.get('extracted_data'):
                        try:
                            import ast
                            data = ast.literal_eval(doc['extracted_data'])
                            if 'ai_result' in data and 'confidence' in data['ai_result']:
                                total_confidence += data['ai_result']['confidence']
                                count += 1
                        except:
                            pass
                
                avg_confidence = total_confidence / count if count > 0 else 0
                st.metric("Average AI Confidence", f"{avg_confidence:.2%}")
            
            # Document insights
            st.markdown("### Document Insights")
            
            for doc in documents:
                if doc.get('extracted_data'):
                    try:
                        import ast
                        data = ast.literal_eval(doc['extracted_data'])
                        
                        if 'ai_result' in data:
                            ai_result = data['ai_result']
                            
                            with st.expander(f"{doc['document_type'].replace('_', ' ').title()} - AI Analysis"):
                                cols = st.columns(2)
                                with cols[0]:
                                    if 'confidence' in ai_result:
                                        st.progress(ai_result['confidence'])
                                        st.caption(f"Confidence: {ai_result['confidence']:.2%}")
                                
                                with cols[1]:
                                    status = "✅ Valid" if ai_result.get('is_valid', False) else "❌ Issues"
                                    st.write(f"**Status:** {status}")
                                
                                if 'analysis' in ai_result:
                                    st.write("**Analysis:**")
                                    st.info(ai_result['analysis'])
                                
                                if 'issues' in ai_result and ai_result['issues']:
                                    st.write("**Issues Found:**")
                                    for issue in ai_result['issues']:
                                        st.error(f"- {issue}")
                    except:
                        pass
            
            # Test AI query
            st.markdown("### Test AI Query")
            query = st.text_input("Ask about your documents:", placeholder="e.g., What information was extracted from my ID proof?")
            
            if query and st.button("Ask AI"):
                # Get document texts
                doc_texts = []
                for doc in documents:
                    if doc.get('extracted_data'):
                        try:
                            import ast
                            data = ast.literal_eval(doc['extracted_data'])
                            if 'extracted_text_preview' in data:
                                doc_texts.append(data['extracted_text_preview'])
                        except:
                            pass
                
                if doc_texts:
                    # Combine texts for context
                    context = "\n\n".join(doc_texts)
                    
                    # Use AI to answer query
                    try:
                        from backend.ai_model_client import AIModelClient
                        ai_client = AIModelClient()
                        
                        prompt = f"""
                        Based on the following KYC document extracts, answer the user's question:
                        
                        DOCUMENT EXTRACTS:
                        {context}
                        
                        USER QUESTION: {query}
                        
                        Provide a helpful and accurate response based only on the extracted document information.
                        """
                        
                        response = ai_client.client.chat.completions.create(
                            model=ai_client.model,
                            messages=[
                                {
                                    "role": "system",
                                    "content": "You are a banking KYC assistant. Help users understand their document verification results."
                                },
                                {
                                    "role": "user",
                                    "content": prompt
                                }
                            ],
                            temperature=0.3,
                            max_tokens=500
                        )
                        
                        answer = response.choices[0].message.content
                        st.success("🤖 AI Response:")
                        st.write(answer)
                    except Exception as e:
                        st.error(f"AI query failed: {e}")
                else:
                    st.warning("No document extracts available for querying.")
        else:
            st.info("No documents uploaded yet. Upload documents to see AI analysis.")
    
    with tab4:
        # KYC progress section
        required_docs = get_required_documents()
        customer_docs = get_customer_documents(st.session_state.customer_id)
        
        st.subheader("📊 KYC Progress Tracker")
        
        progress_data = []
        for req_doc in required_docs:
            doc_type = req_doc['document_type']
            customer_doc = next((doc for doc in customer_docs if doc['document_type'] == doc_type), None)
            
            progress_data.append({
                "Document": doc_type.replace('_', ' ').title(),
                "Status": "✅ Verified" if customer_doc and customer_doc['status'] == 'verified' 
                         else "📤 Uploaded" if customer_doc 
                         else "📭 Not Uploaded",
                "Progress": 100 if customer_doc and customer_doc['status'] == 'verified' 
                          else 50 if customer_doc 
                          else 0
            })
        
        # Display progress bars
        for item in progress_data:
            st.write(f"**{item['Document']}** - {item['Status']}")
            st.progress(item['Progress'] / 100)
            st.write("")
        
        # Overall progress
        total_progress = sum(item['Progress'] for item in progress_data) / len(progress_data)
        st.metric("Overall Progress", f"{total_progress:.0f}%")
        
        if total_progress == 100:
            st.success("🎉 All documents verified! Your KYC is complete.")
            
            # Show next steps
            st.markdown("### Next Steps")
            st.info("""
            1. **Account Activation**: Your account will be activated within 24 hours
            2. **Welcome Kit**: Digital welcome kit will be sent to your email
            3. **Banking Services**: Full access to online banking, debit card, and mobile app
            """)
            
            if st.button("Activate Account Now"):
                st.success("Account activation request submitted!")
    
    with tab5:
        # Activity log section
        logs = get_audit_logs(st.session_state.customer_id, limit=20)
        show_audit_logs(logs)
        
        # AI usage statistics
        st.markdown("### 🤖 AI Usage Statistics")
        
        ai_logs = [log for log in logs if 'ai' in log['action'].lower() or 'verification' in log['action'].lower()]
        
        if ai_logs:
            col1, col2 = st.columns(2)
            with col1:
                st.metric("AI Verifications", len(ai_logs))
            with col2:
                successful = sum(1 for log in ai_logs if 'passed' in log['details'].lower())
                st.metric("Successful", successful)
        else:
            st.info("No AI verification logs yet.")
    
    # Sidebar controls
    st.sidebar.markdown("---")
    st.sidebar.subheader("⚙️ Settings")
    
    # AI toggle
    st.session_state.ai_enabled = st.sidebar.checkbox("Enable AI Verification", value=st.session_state.ai_enabled)
    
    # Model info
    with st.sidebar.expander("AI Model Info"):
        from decouple import config
        st.write(f"**Model:** {config('MODEL_NAME', default='DeepSeek-V3')}")
        st.write(f"**Provider:** TCS GenAI Lab")
        st.write("**Capabilities:** Document analysis, verification, consistency checking")
    
    # Logout button
    st.sidebar.markdown("---")
    if st.sidebar.button("Logout", type="primary"):
        st.session_state.logged_in = False
        st.session_state.customer_id = None
        st.session_state.customer_name = None
        st.session_state.kyc_complete = False
        st.rerun()

if __name__ == "__main__":
    main()