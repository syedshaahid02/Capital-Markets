import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from backend.data_fetcher import MarketDataFetcher

def market_data_page():
    st.title("Market Data Analysis")
    
    # Initialize data fetcher
    data_fetcher = MarketDataFetcher()
    
    # Fetch market data section
    st.subheader("Live Market Data")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Refresh Market Data", type="primary", use_container_width=True):
            with st.spinner("Fetching latest market data..."):
                st.session_state.market_data = data_fetcher.get_market_indices()
                st.session_state.volatility_data = data_fetcher.get_volatility_data()
                st.session_state.economic_data = data_fetcher.get_economic_indicators()
    
    with col2:
        if st.button("Get Market Snapshot", use_container_width=True):
            snapshot = data_fetcher.get_current_market_snapshot()
            if snapshot:
                st.session_state.market_snapshot = snapshot
                st.success("Market snapshot updated!")
    
    # Display market snapshot
    if hasattr(st.session_state, 'market_snapshot'):
        snapshot = st.session_state.market_snapshot
        st.subheader("Current Market Snapshot")
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("S&P 500", f"${snapshot.get('sp500_price', 0):.2f}", 
                     f"{snapshot.get('sp500_change', 0):.2f}%")
        with col2:
            st.metric("VIX Level", f"{snapshot.get('vix_level', 0):.2f}")
        with col3:
            st.metric("Market Sentiment", snapshot.get('market_sentiment', 'Neutral'))
        with col4:
            st.metric("Last Updated", snapshot.get('timestamp', 'N/A').strftime('%H:%M'))
    
    # Display market indices
    if st.session_state.get('market_data'):
        st.subheader("Major Market Indices")
        
        for symbol, data in st.session_state.market_data.items():
            if not data.empty:
                col1, col2 = st.columns([1, 2])
                
                with col1:
                    latest_price = data['Close'].iloc[-1]
                    prev_price = data['Close'].iloc[-2] if len(data) > 1 else latest_price
                    change_pct = ((latest_price - prev_price) / prev_price) * 100
                    
                    st.metric(
                        label=symbol,
                        value=f"${latest_price:.2f}",
                        delta=f"{change_pct:.2f}%"
                    )
                
                with col2:
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=data.index,
                        y=data['Close'],
                        mode='lines',
                        name=symbol,
                        line=dict(width=2)
                    ))
                    fig.update_layout(
                        title=f"{symbol} Price Trend",
                        height=200,
                        showlegend=False,
                        margin=dict(l=0, r=0, t=30, b=0)
                    )
                    st.plotly_chart(fig, use_container_width=True)
    
    # Volatility Analysis
    st.subheader("Volatility Analysis")
    
    if st.session_state.get('volatility_data') and 'VIX' in st.session_state.volatility_data:
        vix_data = st.session_state.volatility_data['VIX']
        if not vix_data.empty:
            col1, col2 = st.columns([2, 1])
            
            with col1:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=vix_data.index,
                    y=vix_data['Close'],
                    mode='lines',
                    name='VIX',
                    line=dict(color='red', width=2)
                ))
                fig.update_layout(
                    title="VIX Volatility Index (Last 6 Months)",
                    height=300,
                    xaxis_title="Date",
                    yaxis_title="VIX Level"
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                current_vix = vix_data['Close'].iloc[-1]
                st.metric("Current VIX", f"{current_vix:.2f}")
                
                if current_vix < 15:
                    st.success("Low Volatility Environment")
                elif current_vix < 25:
                    st.warning("Moderate Volatility")
                else:
                    st.error("High Volatility Environment")
    
    # Economic Indicators
    st.subheader("Economic Indicators")
    
    if st.session_state.get('economic_data') is not None:
        econ_data = st.session_state.economic_data
        
        # Create tabs for different economic indicators
        tab1, tab2, tab3, tab4 = st.tabs(["GDP Growth", "Inflation", "Unemployment", "Interest Rates"])
        
        with tab1:
            if 'GDP_Growth' in econ_data.columns:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=econ_data.index,
                    y=econ_data['GDP_Growth'],
                    mode='lines+markers',
                    name='GDP Growth',
                    line=dict(color='green', width=3)
                ))
                fig.update_layout(title="GDP Growth Rate (%)", height=300)
                st.plotly_chart(fig, use_container_width=True)
        
        with tab2:
            if 'Inflation' in econ_data.columns:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=econ_data.index,
                    y=econ_data['Inflation'],
                    mode='lines+markers',
                    name='Inflation',
                    line=dict(color='orange', width=3)
                ))
                fig.update_layout(title="Inflation Rate (%)", height=300)
                st.plotly_chart(fig, use_container_width=True)
        
        with tab3:
            if 'Unemployment' in econ_data.columns:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=econ_data.index,
                    y=econ_data['Unemployment'],
                    mode='lines+markers',
                    name='Unemployment',
                    line=dict(color='blue', width=3)
                ))
                fig.update_layout(title="Unemployment Rate (%)", height=300)
                st.plotly_chart(fig, use_container_width=True)
        
        with tab4:
            if 'Interest_Rate' in econ_data.columns:
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=econ_data.index,
                    y=econ_data['Interest_Rate'],
                    mode='lines+markers',
                    name='Interest Rate',
                    line=dict(color='purple', width=3)
                ))
                fig.update_layout(title="Interest Rate (%)", height=300)
                st.plotly_chart(fig, use_container_width=True)
    
    # Market Data Summary
    st.subheader("Data Quality & Coverage")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.info("Market Indices: Real-time")
    with col2:
        st.info("Volatility Data: VIX Index")
    with col3:
        st.info("Economic Data: Simulated")

market_data_page()

