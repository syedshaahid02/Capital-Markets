import streamlit as st
import os
from utils.config import Config

def settings_page():
    st.title("System Settings & Configuration")
    
    # LangChain Configuration
    st.subheader("LangChain Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write(f"**Current Model:** {Config.LANGCHAIN_MODEL}")
        st.write(f"**Base URL:** {Config.LANGCHAIN_BASE_URL}")
        st.write(f"**API Key:** {'*' * 20}{Config.LANGCHAIN_API_KEY[-4:] if Config.LANGCHAIN_API_KEY else ''}")
    
    with col2:
        if st.button("Test LangChain Connection", use_container_width=True):
            test_langchain_connection()
    
    # Model Management
    st.subheader("Scenario Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Available Scenario Types:**")
        for scenario in Config.SCENARIO_TYPES:
            st.write(f"- {scenario}")
    
    with col2:
        st.write("**Available Portfolio Types:**")
        for portfolio in Config.PORTFOLIO_TYPES:
            st.write(f"- {portfolio}")
    
    # System Settings
    st.subheader("System Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        auto_refresh = st.checkbox("Auto-refresh Market Data", value=False)
        cache_scenarios = st.checkbox("Cache Generated Scenarios", value=True)
        enable_analytics = st.checkbox("Enable Usage Analytics", value=False)
    
    with col2:
        default_scenario_count = st.slider("Default Scenarios per Type", 1, 5, 2)
        report_auto_save = st.checkbox("Auto-save Generated Reports", value=True)
        data_retention_days = st.selectbox("Data Retention Period", [30, 90, 180, 365], index=1)
    
    # Data Management
    st.subheader("Data Management")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("Clear Scenario Cache", use_container_width=True):
            if 'scenarios' in st.session_state:
                st.session_state.scenarios = []
            st.success("Scenario cache cleared!")
    
    with col2:
        if st.button("Clear Market Data Cache", use_container_width=True):
            if 'market_data' in st.session_state:
                st.session_state.market_data = None
            st.success("Market data cache cleared!")
    
    with col3:
        if st.button("Clear All Session Data", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.success("All session data cleared!")
    
    # Risk Model Settings
    st.subheader("Risk Model Parameters")
    
    col1, col2 = st.columns(2)
    
    with col1:
        confidence_level = st.selectbox(
            "VaR Confidence Level",
            ["95%", "99%", "99.5%", "99.9%"],
            index=0
        )
        
        time_horizon = st.selectbox(
            "Default Time Horizon",
            ["1 day", "1 week", "1 month", "3 months", "1 year"],
            index=2
        )
    
    with col2:
        monte_carlo_sims = st.number_input(
            "Monte Carlo Simulations",
            min_value=1000,
            max_value=100000,
            value=10000,
            step=1000
        )
        
        correlation_period = st.selectbox(
            "Correlation Calculation Period",
            ["1 month", "3 months", "1 year", "3 years"],
            index=2
        )
    
    # API Configuration
    st.subheader("Data Source Configuration")
    
    with st.expander("Market Data Sources"):
        st.write("**Current Data Sources:**")
        st.write("- Yahoo Finance (Primary)")
        st.write("- Alpha Vantage (Backup)")
        
        if st.button("Test Data Source Connections"):
            test_data_sources()
    
    # System Information
    st.subheader("System Information")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Application Version:** 2.0.0")
        st.write("**Python Version:** 3.8+")
        st.write("**Streamlit Version:** 1.28.0+")
        st.write(f"**AI Model:** {Config.LANGCHAIN_MODEL}")
    
    with col2:
        st.write("**Last Updated:** 2024-01-15")
        st.write("**Framework:** LangChain")
        st.write("**Data Sources:** Yahoo Finance, Alpha Vantage")
        st.write("**Report Format:** PDF")
    
    # Save Settings
    st.markdown("---")
    if st.button("Save All Settings", type="primary"):
        st.success("Settings saved successfully!")
    
    # Danger Zone
    st.subheader("Danger Zone")
    
    with st.expander("Advanced System Operations"):
        st.warning("These operations cannot be undone.")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Reset All Settings to Default", use_container_width=True):
                st.info("This will reset all settings to their default values.")
        
        with col2:
            if st.button("Clear All Generated Reports", use_container_width=True):
                clear_generated_reports()

def test_langchain_connection():
    """Test the LangChain connection"""
    try:
        from backend.scenario_agent import ScenarioAgent
        agent = ScenarioAgent()
        success, response = agent.test_llm_connection()
        
        if success:
            st.success(f"✅ Connection successful! Response: {response}")
        else:
            st.error(f"❌ Connection failed: {response}")
            
    except Exception as e:
        st.error(f"❌ Connection test failed: {e}")
        st.info("Please check your API key and network connection.")

def test_data_sources():
    """Test data source connections"""
    try:
        import yfinance as yf
        
        # Test Yahoo Finance
        with st.spinner("Testing Yahoo Finance..."):
            data = yf.download('SPY', period='1d', progress=False)
            if not data.empty:
                st.success("✅ Yahoo Finance connection successful!")
            else:
                st.warning("⚠️ Yahoo Finance returned empty data")
        
        # Test basic market data
        with st.spinner("Testing market data fetcher..."):
            from backend.data_fetcher import MarketDataFetcher
            fetcher = MarketDataFetcher()
            snapshot = fetcher.get_current_market_snapshot()
            if snapshot:
                st.success("✅ Market data fetcher working!")
            else:
                st.warning("⚠️ Market data fetcher returned no data")
                
    except Exception as e:
        st.error(f"❌ Data source test failed: {e}")

def clear_generated_reports():
    """Clear all generated reports"""
    try:
        reports_dir = "reports"
        if os.path.exists(reports_dir):
            report_count = 0
            for file in os.listdir(reports_dir):
                if file.endswith('.pdf'):
                    os.remove(os.path.join(reports_dir, file))
                    report_count += 1
            st.success(f"✅ Cleared {report_count} generated reports!")
        else:
            st.info("No reports directory found.")
    except Exception as e:
        st.error(f"Error clearing reports: {e}")

# Initialize session state if not exists
if 'scenarios' not in st.session_state:
    st.session_state.scenarios = []
if 'market_data' not in st.session_state:
    st.session_state.market_data = None

settings_page()

